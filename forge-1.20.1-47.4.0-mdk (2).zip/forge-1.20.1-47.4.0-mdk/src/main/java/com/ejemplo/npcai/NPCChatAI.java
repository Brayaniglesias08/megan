package com.ejemplo.npcai;

import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.event.entity.player.PlayerInteractEvent.EntityInteract;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;

public class NPCChatAI {

    public NPCChatAI(IEventBus modEventBus) {
        modEventBus.addListener(this::onServerStarting);
        MinecraftForge.EVENT_BUS.addListener(this::onPlayerInteract);
    }

    private void onServerStarting(final FMLCommonSetupEvent event) {
        // Inicialización si necesitás algo
    }

    public void onPlayerInteract(EntityInteract event) {
        Player jugador = event.getEntity();
        Entity npc = event.getTarget();

        if (!jugador.level().isClientSide && npc instanceof Villager) {
            String pregunta = npc.getName().getString();

            try {
                java.util.UUID uuid = jugador.getUUID();
                // Añadir mensaje del usuario al historial
                MeganConversationManager.agregarMensaje(uuid, "user", pregunta);
                // Obtener historial actual
                java.util.List<MeganConversationManager.MensajeTurno> historial = MeganConversationManager.obtenerHistorial(uuid);
                String respuesta = ChatGPTIntegration.obtenerRespuestaDeChatGPT(historial, "Jugador", "");
                // Añadir respuesta de Megan al historial
                MeganConversationManager.agregarMensaje(uuid, "assistant", respuesta);
                jugador.displayClientMessage(Component.literal(respuesta), false);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    } // <- cierre del método onPlayerInteract
}     // <- cierre de la clase
