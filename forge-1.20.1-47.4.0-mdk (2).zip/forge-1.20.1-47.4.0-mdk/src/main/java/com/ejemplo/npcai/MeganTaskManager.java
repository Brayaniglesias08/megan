package com.ejemplo.npcai;

/**
 * MeganTaskManager: Gestiona la cola de tareas y el estado de Megan.
 * Arquitectura limpia y modular, lista para integración IA.
 */
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MeganTaskManager {
    private final Queue<Runnable> tareas = new LinkedList<>();
    private boolean ocupada = false;
    private final MeganEntity megan;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    public MeganTaskManager(MeganEntity megan) {
        this.megan = megan;
    }

    public synchronized void agregarTarea(Runnable tarea) {
        tareas.add(tarea);
        procesarSiguiente();
    }

    private synchronized void procesarSiguiente() {
        if (!ocupada && !tareas.isEmpty()) {
            ocupada = true;
            Runnable tarea = tareas.poll();
            executor.submit(() -> {
                try {
                    tarea.run();
                } finally {
                    onTareaTerminada();
                }
            });
        }
    }

    private synchronized void onTareaTerminada() {
        ocupada = false;
        // Notifica a Megan que terminó la tarea (puedes agregar hooks aquí)
        procesarSiguiente();
    }

    public synchronized boolean isOcupada() {
        return ocupada;
    }

    public synchronized void limpiarTareas() {
        tareas.clear();
    }

    public synchronized int tareasPendientes() {
        return tareas.size();
    }

    public void shutdown() {
        executor.shutdown();
    }
}
