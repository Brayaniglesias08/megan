package com.ejemplo.npcai;

import net.minecraftforge.event.entity.item.ItemTossEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.Vec3;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import java.util.List;

@Mod.EventBusSubscriber(modid = "meganai")
public class ItemDropLogger {
    @SubscribeEvent
    public static void onItemToss(ItemTossEvent event) {
        ItemEntity itemEntity = (ItemEntity) event.getEntity();
        ItemStack stack = itemEntity.getItem();
        String itemId = stack.getItem().getDescriptionId();
        Vec3 itemPos = itemEntity.position();
        Player player = event.getPlayer();
        String playerName = player.getName().getString();
        
        // Buscar a Megan en el mundo
        double minDist = Double.MAX_VALUE;
        Vec3 meganPos = null;
        String meganName = null;
        if (player.level() instanceof ServerLevel serverLevel) {
            List<MeganEntity> megans = serverLevel.getEntitiesOfClass(MeganEntity.class, itemEntity.getBoundingBox().inflate(30));
            for (MeganEntity megan : megans) {
                double dist = megan.position().distanceTo(itemPos);
                if (dist < minDist) {
                    minDist = dist;
                    meganPos = megan.position();
                    meganName = megan.getName().getString();
                }
            }
        }
        String log = "[MEGAN][DROP-LOG] Jugador '" + playerName + "' soltó objeto '" + itemId + "' en " + itemPos + ". ";
        if (meganPos != null) {
            log += "Megan ('" + meganName + "') está a " + String.format("%.2f", minDist) + " bloques.";
        } else {
            log += "No se encontró a Megan cerca.";
        }
        System.out.println(log);
    }
}
