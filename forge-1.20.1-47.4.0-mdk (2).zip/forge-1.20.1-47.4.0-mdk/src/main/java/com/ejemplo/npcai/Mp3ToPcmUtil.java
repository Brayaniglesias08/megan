package com.ejemplo.npcai;

import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.SampleBuffer;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.AudioFormat;

public class Mp3ToPcmUtil {
    /**
     * Decodifica un MP3 (array de bytes) a un array de shorts PCM lineal.
     * Devuelve un objeto PCMResult con los datos PCM, sampleRate y canales.
     */
    public static byte[] skipID3v2(byte[] mp3Bytes) {
        if (mp3Bytes.length < 10) return mp3Bytes;
        if (mp3Bytes[0] == 'I' && mp3Bytes[1] == 'D' && mp3Bytes[2] == '3') {
            int size = ((mp3Bytes[6] & 0x7F) << 21) | ((mp3Bytes[7] & 0x7F) << 14) | ((mp3Bytes[8] & 0x7F) << 7) | (mp3Bytes[9] & 0x7F);
            int skip = 10 + size;
            if (skip < mp3Bytes.length) {
                System.out.println("[MEGAN][JLAYER] Saltando encabezado ID3v2 de " + skip + " bytes");
                return java.util.Arrays.copyOfRange(mp3Bytes, skip, mp3Bytes.length);
            }
        }
        return mp3Bytes;
    }

    public static PCMResult decodeMp3ToPCM(byte[] mp3Bytes, String textoDebug) throws Exception {
        System.out.println("[MEGAN][DEBUG] CLASSPATH: " + System.getProperty("java.class.path"));
        System.out.println("[MEGAN][MP3SPI] Decodificando MP3 usando Java Sound (mp3spi)...");
        java.util.ServiceLoader<javax.sound.sampled.spi.AudioFileReader> loader = java.util.ServiceLoader.load(javax.sound.sampled.spi.AudioFileReader.class);
        for (javax.sound.sampled.spi.AudioFileReader reader : loader) {
            System.out.println("[MEGAN][DEBUG] AudioFileReader: " + reader.getClass().getName());
        }
        try {
            // Primer intento: Java Sound (mp3spi)
            ByteArrayInputStream bais = new ByteArrayInputStream(mp3Bytes);
            AudioInputStream mp3Stream = AudioSystem.getAudioInputStream(bais);
            AudioFormat baseFormat = mp3Stream.getFormat();
            AudioFormat decodedFormat = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    baseFormat.getSampleRate(),
                    16,
                    baseFormat.getChannels(),
                    baseFormat.getChannels() * 2,
                    baseFormat.getSampleRate(),
                    false
            );
            AudioInputStream pcmStream = AudioSystem.getAudioInputStream(decodedFormat, mp3Stream);
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = pcmStream.read(buffer)) != -1) {
                baos.write(buffer, 0, bytesRead);
            }
            byte[] pcmBytes = baos.toByteArray();
            short[] pcmShorts = new short[pcmBytes.length / 2];
            for (int i = 0; i < pcmShorts.length; i++) {
                pcmShorts[i] = (short) ((pcmBytes[2 * i + 1] << 8) | (pcmBytes[2 * i] & 0xff));
            }
            System.out.println("[MEGAN][MP3SPI] Decodificación completada. Frames: " + pcmShorts.length + " SampleRate: " + (int)decodedFormat.getSampleRate() + " Channels: " + decodedFormat.getChannels());
            return new PCMResult(pcmShorts, (int)decodedFormat.getSampleRate(), decodedFormat.getChannels());
        } catch (Exception mp3spiEx) {
            System.out.println("[MEGAN][MP3SPI] Falló la decodificación con Java Sound: " + mp3spiEx.getMessage());
            // Segundo intento: JLayer
            try {
                System.out.println("[MEGAN][JLAYER] Intentando decodificar con JLayer...");
                Bitstream bitstream = new Bitstream(new ByteArrayInputStream(mp3Bytes));
                Decoder decoder = new Decoder();
                List<Short> pcmList = new ArrayList<>();
                int sampleRate = 44100;
                int channels = 2;
                while (true) {
                    javazoom.jl.decoder.Header frameHeader = bitstream.readFrame();
                    if (frameHeader == null) break;
                    SampleBuffer output = (SampleBuffer) decoder.decodeFrame(frameHeader, bitstream);
                    if (output != null) {
                        short[] pcm = output.getBuffer();
                        for (short s : pcm) pcmList.add(s);
                        sampleRate = output.getSampleFrequency();
                        channels = output.getChannelCount();
                    }
                    bitstream.closeFrame();
                }
                short[] pcmShorts = new short[pcmList.size()];
                for (int i = 0; i < pcmList.size(); i++) pcmShorts[i] = pcmList.get(i);
                System.out.println("[MEGAN][JLAYER] Decodificación completada. Frames: " + pcmShorts.length + " SampleRate: " + sampleRate + " Channels: " + channels);
                return new PCMResult(pcmShorts, sampleRate, channels);
            } catch (Exception jlayerEx) {
                // Guardar el MP3 en debug_audio/ solo si ambos métodos fallan
                try {
                    java.io.File debugDir = new java.io.File("debug_audio");
                    if (!debugDir.exists()) debugDir.mkdirs();
                    String safeText = textoDebug != null ? textoDebug.replaceAll("[^a-zA-Z0-9-_]", "_") : "audio";
                    String fileName = "debug_audio/failed_" + System.currentTimeMillis() + "_" + safeText.substring(0, Math.min(safeText.length(), 20)) + ".mp3";
                    java.nio.file.Files.write(new java.io.File(fileName).toPath(), mp3Bytes);
                    System.err.println("[MEGAN][DEBUG] MP3 guardado por error en: " + fileName);
                } catch (Exception e2) {
                    System.err.println("[MEGAN][DEBUG] No se pudo guardar el MP3 problemático: " + e2.getMessage());
                }
                throw jlayerEx;
            }
        }
    }

    public static class PCMResult {
        public final short[] pcm;
        public final int sampleRate;
        public final int channels;
        public PCMResult(short[] pcm, int sampleRate, int channels) {
            this.pcm = pcm;
            this.sampleRate = sampleRate;
            this.channels = channels;
        }
    }
}
