package com.ejemplo.npcai;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import java.util.List;
import java.util.UUID;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Mod.EventBusSubscriber(modid = "megan")
public class ComandoIA {

    private static final ExecutorService executor = Executors.newFixedThreadPool(2);

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        System.out.println("📦 [ComandoIA] Registrando /testia...");

        dispatcher.register(Commands.literal("testia")
                .requires(cs -> cs.hasPermission(2))
                .then(Commands.argument("mensaje", StringArgumentType.greedyString())
                        .executes(ctx -> {
                            String mensaje = StringArgumentType.getString(ctx, "mensaje");
                            CommandSourceStack source = ctx.getSource();
                            ServerPlayer player = source.getPlayer();

                            executor.submit(() -> {
                                try {
                                    UUID uuid = player != null ? player.getUUID() : UUID.randomUUID();
                                    MeganConversationManager.agregarMensaje(uuid, "user", mensaje);
                                    List<MeganConversationManager.MensajeTurno> historial = MeganConversationManager.obtenerHistorial(uuid);
                                    String respuesta = ChatGPTIntegration.obtenerRespuestaDeChatGPT(historial, "Jugador", "");
                                    MeganConversationManager.agregarMensaje(uuid, "assistant", respuesta);
                                    if (player != null) {
                                        player.sendSystemMessage(Component.literal("[IA] " + respuesta));
                                        ElevenLabsPlayer.reproducirEnTiempoReal(respuesta);
                                    } else {
                                        source.sendSuccess(() -> Component.literal("[IA] " + respuesta), false);
                                        ElevenLabsPlayer.reproducirEnTiempoReal(respuesta);
                                    }
                                } catch (Exception e) {
                                    source.sendFailure(Component.literal(" Error al contactar a la IA."));
                                    e.printStackTrace();
                                }
                            });

                            source.sendSuccess(() -> Component.literal("🧠 Procesando respuesta de la IA..."), false);
                            return 1;
                        }))
                .executes(ctx -> {
                    ctx.getSource().sendFailure(Component.literal("Por favor, proporciona un mensaje. Uso: /testia <mensaje>"));
                    return 0;
                }));
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        shutdown();
    }

    private static void shutdown() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(5, TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }
    }
}