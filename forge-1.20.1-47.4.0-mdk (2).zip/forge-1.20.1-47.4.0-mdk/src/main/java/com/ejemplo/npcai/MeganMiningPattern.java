package com.ejemplo.npcai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

public interface MeganMiningPattern {
    // Devuelve la siguiente posición a minar, o null si terminó
    BlockPos getNextBlockToMine(MeganEntity megan, Level level);
    // Reinicia el patrón (opcional, para empezar desde cero)
    void reset(BlockPos start, Direction direction);
}
