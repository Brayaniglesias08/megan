package com.ejemplo.npcai;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;

public class MeganTunnelPattern implements MeganMiningPattern {
    private BlockPos start;
    private Direction direction;
    private int length;
    private int mined;

    public MeganTunnelPattern(BlockPos start, Direction direction, int length) {
        this.start = start;
        this.direction = direction;
        this.length = length;
        this.mined = 0;
    }

    @Override
    public BlockPos getNextBlockToMine(MeganEntity megan, Level level) {
        if (mined >= length) return null;
        BlockPos target = start.relative(direction, mined);
        mined++;
        return target;
    }

    @Override
    public void reset(BlockPos start, Direction direction) {
        this.start = start;
        this.direction = direction;
        this.mined = 0;
    }
}
