package com.ejemplo.npcai;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Registra los atributos de Megan. ¡No duplicar este evento!
 */
@Mod.EventBusSubscriber(modid = "meganai", bus = Mod.EventBusSubscriber.Bus.MOD)
public class ModEventSubscriber {
    @SubscribeEvent
    public static void onEntityAttributeCreation(EntityAttributeCreationEvent event) {
        if (!ModEntities.MEGAN.isPresent()) {
            throw new IllegalStateException("¡La entidad Megan NO está registrada!");
        }
        event.put(ModEntities.MEGAN.get(), MeganEntity.createAttributes().build());
    }
}
