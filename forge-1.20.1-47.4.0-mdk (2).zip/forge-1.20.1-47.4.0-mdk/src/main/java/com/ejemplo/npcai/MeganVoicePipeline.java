package com.ejemplo.npcai;

import java.io.*;

/**
 * Pipeline para que Megan hable con voz posicional.
 * Solo el servidor/host necesita ffmpeg. Los clientes solo reproducen OGG.
 */
public class MeganVoicePipeline {
    /**
     * Genera, convierte y envía audio OGG para voz posicional de Megan.
     * @param texto Texto a sintetizar
     * @param x Posición X
     * @param y Posición Y
     * @param z Posición Z
     * @param ttsClient Cliente TTS (debes implementar la llamada a ElevenLabs)
     * @param audioSender Método para enviar el byte[] OGG y la posición al cliente
     */
    public static void meganSpeak(String texto, double x, double y, double z, TTSClient ttsClient, AudioSender audioSender) {
        try {
            // 1. Genera el audio MP3 usando tu cliente TTS (debes implementar esto)
            File mp3File = ttsClient.synthesizeToMp3(texto);

            // 2. Convierte MP3 a OGG (solo en el servidor)
            File oggFile = File.createTempFile("megan_voice", ".ogg");
            AudioConversionUtil.convertToOgg(mp3File, oggFile);

            // 3. Lee el OGG como byte[]
            byte[] oggBytes = readAllBytes(oggFile);

            // 4. Envía el audio al cliente junto con la posición
            audioSender.sendOggToClient(oggBytes, x, y, z);

            // Limpieza
            mp3File.delete();
            oggFile.delete();
        } catch (Exception e) {
            System.out.println("[MeganVoicePipeline] Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static byte[] readAllBytes(File file) throws IOException {
        try (FileInputStream fis = new FileInputStream(file)) {
            return fis.readAllBytes();
        }
    }

    // Interfaces para desacoplar la lógica del TTS y del envío de audio
    public interface TTSClient {
        File synthesizeToMp3(String texto) throws Exception;
    }

    public interface AudioSender {
        void sendOggToClient(byte[] ogg, double x, double y, double z);
    }
}
