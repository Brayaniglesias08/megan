package com.ejemplo.npcai;

import org.lwjgl.openal.AL;
import org.lwjgl.openal.AL10;
import org.lwjgl.BufferUtils;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import java.io.ByteArrayInputStream;
import java.nio.ByteBuffer;
import java.nio.ShortBuffer;

/**
 * Reproduce audio PCM usando OpenAL, permitiendo audio posicional como en Simple Voice Chat.
 * El audio debe estar decodificado a PCM (por ejemplo, usando AudioInputStream de Java Sound).
 * Comentarios en español.
 */
public class OpenALPlayer {
    /**
     * Reproduce un audio PCM (16bit, 44100Hz, mono o estéreo) usando OpenAL y sigue a una entidad.
     * @param oggData  Bytes del archivo OGG
     * @param entity   Entidad a seguir (por ejemplo, Megan)
     * @return Instancia de SoundFollowEntity para actualizar la posición en cada tick
     */
    public static SoundFollowEntity playFollowEntity(byte[] oggData, net.minecraft.world.entity.Entity entity) {
        try (AudioInputStream ais = AudioSystem.getAudioInputStream(new ByteArrayInputStream(oggData))) {
            AudioFormat baseFormat = ais.getFormat();
            AudioFormat decodedFormat = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    baseFormat.getSampleRate(),
                    16,
                    baseFormat.getChannels(),
                    baseFormat.getChannels() * 2,
                    baseFormat.getSampleRate(),
                    false
            );
            try (AudioInputStream decodedAis = AudioSystem.getAudioInputStream(decodedFormat, ais)) {
                byte[] pcmBytes = decodedAis.readAllBytes();
                // Determina el formato de OpenAL
                int alFormat;
                if (decodedFormat.getChannels() == 1) {
                    alFormat = decodedFormat.getSampleSizeInBits() == 16 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_MONO8;
                } else {
                    alFormat = decodedFormat.getSampleSizeInBits() == 16 ? AL10.AL_FORMAT_STEREO16 : AL10.AL_FORMAT_STEREO8;
                }
                // Crea un buffer de OpenAL
                int bufferId = AL10.alGenBuffers();
                ByteBuffer buffer = BufferUtils.createByteBuffer(pcmBytes.length);
                buffer.put(pcmBytes);
                buffer.flip();
                AL10.alBufferData(bufferId, alFormat, buffer, (int) decodedFormat.getSampleRate());
                // Crea una fuente de OpenAL
                int sourceId = AL10.alGenSources();
                AL10.alSourcei(sourceId, AL10.AL_BUFFER, bufferId);
                AL10.alSource3f(sourceId, AL10.AL_POSITION, (float)entity.getX(), (float)entity.getY(), (float)entity.getZ());
                AL10.alSourcef(sourceId, AL10.AL_GAIN, 1.0f);
                AL10.alSourcef(sourceId, AL10.AL_REFERENCE_DISTANCE, 2.0f);
                AL10.alSourcef(sourceId, AL10.AL_MAX_DISTANCE, 32.0f);
                AL10.alSourcef(sourceId, AL10.AL_ROLLOFF_FACTOR, 1.0f);
                AL10.alSourcei(sourceId, AL10.AL_SOURCE_RELATIVE, AL10.AL_FALSE);
                AL10.alSourcePlay(sourceId);
                // Devuelve el objeto para seguimiento dinámico
                return new SoundFollowEntity(sourceId, bufferId, entity);
            }
        } catch (Exception e) {
            System.out.println("[DEPURACIÓN] Error en OpenALPlayer.playFollowEntity: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    /**
     * Reproduce un audio PCM (16bit, 44100Hz, mono o estéreo) usando OpenAL en la posición dada.
     * @param pcmData  Bytes PCM decodificados (por ejemplo, desde OGG)
     * @param format   Formato de audio PCM (usa AudioInputStream.getFormat())
     * @param x        Posición X en el mundo (para audio posicional)
     * @param y        Posición Y en el mundo (para audio posicional)
     * @param z        Posición Z en el mundo (para audio posicional)
     */
    public static void play(byte[] pcmData, AudioFormat format, float x, float y, float z) {
        System.out.println("[MEGAN][OpenALPlayer.play] Ejecutando play()");
        System.out.println("[MEGAN][OpenALPlayer.play] Tamaño pcmData: " + (pcmData != null ? pcmData.length : -1));
        System.out.println("[MEGAN][OpenALPlayer.play] Formato: " + format);
        System.out.println("[MEGAN][OpenALPlayer.play] Posición: x=" + x + ", y=" + y + ", z=" + z);
        try {


            // Determina el formato de OpenAL
            int alFormat;
            if (format.getChannels() == 1) {
                alFormat = format.getSampleSizeInBits() == 16 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_MONO8;
            } else {
                alFormat = format.getSampleSizeInBits() == 16 ? AL10.AL_FORMAT_STEREO16 : AL10.AL_FORMAT_STEREO8;
            }

            // Crea un buffer de OpenAL
            int bufferId = AL10.alGenBuffers();
            ByteBuffer buffer = BufferUtils.createByteBuffer(pcmData.length);
            buffer.put(pcmData);
            buffer.flip();
            AL10.alBufferData(bufferId, alFormat, buffer, (int) format.getSampleRate());

            // Crea una fuente de OpenAL
            int sourceId = AL10.alGenSources();
            AL10.alSourcei(sourceId, AL10.AL_BUFFER, bufferId);
            AL10.alSource3f(sourceId, AL10.AL_POSITION, x, y, z); // Posición 3D
AL10.alSourcef(sourceId, AL10.AL_GAIN, 1.0f); // Volumen
// Parámetros de distancia y atenuación para audio posicional
AL10.alSourcef(sourceId, AL10.AL_REFERENCE_DISTANCE, 2.0f); // distancia a la que se escucha al 100%
AL10.alSourcef(sourceId, AL10.AL_MAX_DISTANCE, 32.0f);     // distancia máxima de audición
AL10.alSourcef(sourceId, AL10.AL_ROLLOFF_FACTOR, 1.0f);    // atenuación por distancia
AL10.alSourcei(sourceId, AL10.AL_SOURCE_RELATIVE, AL10.AL_FALSE); // debe ser posicional, NO relativo
// Reproduce el audio
AL10.alSourcePlay(sourceId);

            // Espera a que termine la reproducción
            new Thread(() -> {
                int state;
                do {
                    state = AL10.alGetSourcei(sourceId, AL10.AL_SOURCE_STATE);
                    try { Thread.sleep(10); } catch (InterruptedException ignored) {}
                } while (state == AL10.AL_PLAYING);
                // Libera recursos
                AL10.alDeleteSources(sourceId);
                AL10.alDeleteBuffers(bufferId);
            }).start();
        } catch (Exception e) {
            System.out.println("[DEPURACIÓN] Error en OpenALPlayer: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Decodifica un archivo OGG a PCM usando Java Sound y lo reproduce con OpenAL.
     * @param oggData  Bytes del archivo OGG
     * @param x        Posición X en el mundo
     * @param y        Posición Y en el mundo
     * @param z        Posición Z en el mundo
     */
    public static void playOgg(byte[] oggData, float x, float y, float z) {
        System.out.println("[MEGAN][OpenALPlayer.playOgg] Ejecutando playOgg()");
        System.out.println("[MEGAN][OpenALPlayer.playOgg] Tamaño oggData: " + (oggData != null ? oggData.length : -1));
        System.out.println("[MEGAN][OpenALPlayer.playOgg] Posición: x=" + x + ", y=" + y + ", z=" + z);
        // --- Depuración: listar tipos de audio soportados ---
        System.out.println("[DEPURACIÓN] Tipos de audio soportados por Java Sound:");
        for (javax.sound.sampled.AudioFileFormat.Type type : javax.sound.sampled.AudioSystem.getAudioFileTypes()) {
            System.out.println("[DEPURACIÓN] Audio type supported: " + type);
        }
        // --- Depuración: listar proveedores de AudioFileReader ---
        System.out.println("[DEPURACIÓN] Proveedores AudioFileReader cargados:");
        java.util.ServiceLoader<javax.sound.sampled.spi.AudioFileReader> loader =
            java.util.ServiceLoader.load(javax.sound.sampled.spi.AudioFileReader.class);
        for (javax.sound.sampled.spi.AudioFileReader reader : loader) {
            System.out.println("[DEPURACIÓN] AudioFileReader: " + reader.getClass().getName());
        }
        try (AudioInputStream ais = AudioSystem.getAudioInputStream(new ByteArrayInputStream(oggData))) {
            AudioFormat baseFormat = ais.getFormat();
            AudioFormat decodedFormat = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    baseFormat.getSampleRate(),
                    16,
                    baseFormat.getChannels(),
                    baseFormat.getChannels() * 2,
                    baseFormat.getSampleRate(),
                    false
            );
            try (AudioInputStream decodedAis = AudioSystem.getAudioInputStream(decodedFormat, ais)) {
                byte[] pcmBytes = decodedAis.readAllBytes();
                play(pcmBytes, decodedFormat, x, y, z);
            }
        } catch (Exception e) {
            System.out.println("[DEPURACIÓN] Error al decodificar y reproducir OGG: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
