package com.ejemplo.npcai;

import net.minecraft.server.level.ServerPlayer;

public class TestChatGPT {
    public static void test(ServerPlayer player) {
        ElevenLabsMP3Player.reproducir("Hola, soy un NPC parlante.", player);
    }
}
