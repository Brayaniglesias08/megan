package com.ejemplo.npcai;

import net.minecraft.server.MinecraftServer;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONObject;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;

@Mod("meganai")
public class NpcAIMod {


    static {
        boolean isClient = false;
        try {
            Class.forName("net.minecraft.client.Minecraft");
            isClient = true;
        } catch (Throwable ignored) {}
        if (isClient) {
        } else {
        }
    }
    public static MinecraftServer SERVER;

    public NpcAIMod() {
        System.out.println("✅ NPC AI Mod cargado correctamente.");

        // Usa SIEMPRE el mismo modEventBus para todos los registros
        IEventBus modEventBus = net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext.get().getModEventBus();
        ModEntities.ENTITIES.register(modEventBus);
        ModMenus.register(); // <-- Registro de menús personalizados
        // Fuerza la carga de la clase ModEntities para asegurar el registro estático
        ModEntities.class.getName();
        System.out.println("✅ Registro de ENTITIES: " + ModEntities.MEGAN);

        // Registrar canal de red y paquetes (¡NECESARIO para los paquetes personalizados!)
        MeganNetwork.register(); // <--- ¡Registro del canal de voz posicional!
        ModNetwork.register();
        // Registro del handler de audio SOLO en cliente
        try {
            Class.forName("net.minecraft.client.Minecraft");
            System.out.println("[MEGAN][INIT] Registrando handler de audio en CLIENTE");
            // Forzar carga de clase para inicializar cualquier static block
            Class.forName("com.ejemplo.npcai.net.MeganAudioClientHandler");
        } catch (Throwable ignored) {
            System.out.println("[MEGAN][INIT] No es cliente, no se registra handler de audio");
        }
        // Si prefieres usar NetworkHandler, descomenta la siguiente línea y comenta la anterior:
        NetworkHandler.registerMessages();
        // Registrar listener para chat y broadcasting de voz
        MinecraftForge.EVENT_BUS.register(MeganChatListener.class);

        // Registrar sonidos
        ModSounds.register(modEventBus);

        // Registrar eventos
        MinecraftForge.EVENT_BUS.register(this);
        // (Ya registramos MeganChatListener arriba)

        // Verificar que org.json está funcionando
        // System.out.println(new JSONObject().put("test", 123));

        // Registrar interacción con NPCs (como aldeanos)
        new NPCChatAI(modEventBus);
    }

    @SubscribeEvent
    public void onServerStarting(ServerStartingEvent event) {
        SERVER = event.getServer();
        System.out.println("✅ [NpcAIMod] Servidor iniciado.");
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        System.out.println("🔧 Registrando comandos...");
        HolaCommand.register(event.getDispatcher());
        ComandoIA.register(event.getDispatcher());
        ComandoSpawnMegan.register(event.getDispatcher());
        ComandoPruebaXdCommand.register(event.getDispatcher());
        ComandoMeganVen.register(event.getDispatcher());
        System.out.println("✅ Comandos registrados con éxito.");
    }

    /**
     * [NO TOCAR] Registro de atributos de Megan.
     * ¡NO EDITAR NI ELIMINAR! Si se modifica, Megan crasheará el juego por falta de atributos.
     * Validado y protegido por el equipo de desarrollo.
     */
    @Deprecated // Marca visual para IDEs, no afecta ejecución
    @SubscribeEvent
    public static void onEntityAttributeCreation(EntityAttributeCreationEvent event) {
        // [NO TOCAR] Registro crítico para evitar NullPointerException en Megan
        event.put(ModEntities.MEGAN.get(), MeganEntity.createAttributes().build());
    }
}