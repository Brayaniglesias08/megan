package com.ejemplo.npcai;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

public class MeganInventoryScreen extends AbstractContainerScreen<MeganInventoryMenu> {
    // Cambia la ruta por la de tu PNG personalizado cuando lo tengas
    private static final ResourceLocation TEXTURE = new ResourceLocation("npcai", "textures/gui/megan_inventory.png");

    public MeganInventoryScreen(MeganInventoryMenu menu, Inventory playerInventory, Component title) {
        super(menu, playerInventory, title);
        this.imageWidth = 352;   // Más ancho para ambos inventarios lado a lado
        this.imageHeight = 168;  // Alto estándar de inventario
        this.inventoryLabelY = 74; // Ajusta si quieres el texto del jugador más arriba o abajo
    }

    @Override
    protected void renderBg(GuiGraphics guiGraphics, float partialTick, int mouseX, int mouseY) {
        // Dibuja el fondo personalizado
        guiGraphics.blit(TEXTURE, this.leftPos, this.topPos, 0, 0, this.imageWidth, this.imageHeight);
    }

    @Override
    protected void renderLabels(GuiGraphics guiGraphics, int mouseX, int mouseY) {
        // Título de Megan a la izquierda
        guiGraphics.drawString(this.font, this.title, 18, 6, 4210752, false);
        // Título del jugador a la derecha
        guiGraphics.drawString(this.font, this.playerInventoryTitle, 190, 74, 4210752, false);
    }
}