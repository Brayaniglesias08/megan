package com.ejemplo.npcai;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;
import java.io.File;
import java.io.FileInputStream;
import java.util.Random;

public class MeganCustomAudioPlayer {
    private static final String[] VEN_AUDIOS = {
        "megan_voice_ven_1.wav",
        "megan_voice_ven_2.wav",
        "megan_voice_ven_3.wav",
        "megan_voice_ven_4.wav",
        "megan_voice_ven_5.wav"
    };
    private static final String BASE_PATH = "C:/Users/Brayan Iglesias/Downloads/nuevo mod/forge-1.20.1-47.4.0-mdk/src/main/resources/assets/meganai/sounds/";
    private static final Random random = new Random();

    public static void reproducirVenAleatorio(ServerPlayer player, MeganEntity megan) {
        String nombreArchivo = VEN_AUDIOS[random.nextInt(VEN_AUDIOS.length)];
        File audioFile = new File(BASE_PATH + nombreArchivo);
        reproducirAudioWav(audioFile, megan);
    }

    public static void reproducirAudioWav(File audioFile, MeganEntity megan) {
        try (FileInputStream fis = new FileInputStream(audioFile)) {
            byte[] wavBytes = fis.readAllBytes();
            double x = megan.getX(), y = megan.getY(), z = megan.getZ();
            double radio = 16.0;
            for (ServerPlayer jugador : megan.level().getEntitiesOfClass(ServerPlayer.class, megan.getBoundingBox().inflate(radio))) {
                ModNetwork.INSTANCE.send(
                    PacketDistributor.PLAYER.with(() -> jugador),
                    new PlayAudioPacket(wavBytes, x, y, z)
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
            // No se puede enviar mensaje de error a todos, solo loguear
        }
    }
}
