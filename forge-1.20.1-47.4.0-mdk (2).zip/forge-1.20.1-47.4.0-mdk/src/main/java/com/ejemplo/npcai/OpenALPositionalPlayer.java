package com.ejemplo.npcai;

import org.lwjgl.openal.AL;
import org.lwjgl.openal.ALC;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.ALC10;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.nio.ShortBuffer;
import java.nio.IntBuffer;

public class OpenALPositionalPlayer {
    private static long device;
    private static long context;
    private static boolean initialized = false;

    public static void init() {
        if (initialized) return;
        device = ALC10.alcOpenDevice((ByteBuffer) null);
        if (device == MemoryUtil.NULL) throw new IllegalStateException("Failed to open the default OpenAL device.");
        context = ALC10.alcCreateContext(device, (IntBuffer) null);
        if (context == MemoryUtil.NULL) throw new IllegalStateException("Failed to create OpenAL context.");
        ALC10.alcMakeContextCurrent(context);
        AL.createCapabilities(ALC.createCapabilities(device));
        initialized = true;
    }

    public static void playPCM(short[] pcm, int sampleRate, int channels, float x, float y, float z) {
        init();
        int format = channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16;

        int source = AL10.alGenSources();
        int buffer = AL10.alGenBuffers();

        ShortBuffer pcmBuffer = MemoryUtil.memAllocShort(pcm.length);
        pcmBuffer.put(pcm).flip();

        AL10.alBufferData(buffer, format, pcmBuffer, sampleRate);
        AL10.alSourcei(source, AL10.AL_BUFFER, buffer);
        AL10.alSource3f(source, AL10.AL_POSITION, x, y, z);
        AL10.alSourcePlay(source);

        // Reproducción no bloqueante: libera el buffer en un hilo separado
        new Thread(() -> {
            try {
                while (AL10.alGetSourcei(source, AL10.AL_SOURCE_STATE) == AL10.AL_PLAYING) {
                    Thread.sleep(10);
                }
            } catch (InterruptedException ignored) {}
            AL10.alDeleteSources(source);
            AL10.alDeleteBuffers(buffer);
            MemoryUtil.memFree(pcmBuffer);
        }).start();
    }

    public static void cleanup() {
        if (!initialized) return;
        ALC10.alcDestroyContext(context);
        ALC10.alcCloseDevice(device);
        initialized = false;
    }
}
