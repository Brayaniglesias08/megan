package com.ejemplo.npcai;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.*;

/**
 * Maneja la memoria persistente de Megan (por jugador y general, temporal y permanente).
 */
public class MeganMemoryManager {
    private static final int LIMITE_TEMPORAL = 200;
    private static final File BASE_DIR = new File("world/data/meganai/");
    private static final File GENERAL_FILE = new File(BASE_DIR, "general.json");
    private static final File GENERAL_PERMA_FILE = new File(BASE_DIR, "general_perma.json");
    private static final Gson GSON = new Gson();
    static {
        BASE_DIR.mkdirs();
    }

    public static List<String> cargarMemoriaJugador(UUID uuid) {
        return cargarLista(new File(BASE_DIR, uuid+".json"), LIMITE_TEMPORAL);
    }
    public static List<String> cargarMemoriaPermaJugador(UUID uuid) {
        return cargarLista(new File(BASE_DIR, uuid+"_perma.json"), Integer.MAX_VALUE);
    }
    public static List<String> cargarMemoriaGeneral() {
        return cargarLista(GENERAL_FILE, LIMITE_TEMPORAL);
    }
    public static List<String> cargarMemoriaPermaGeneral() {
        return cargarLista(GENERAL_PERMA_FILE, Integer.MAX_VALUE);
    }
    public static void guardarMemoriaJugador(UUID uuid, List<String> mensajes) {
        guardarLista(new File(BASE_DIR, uuid+".json"), mensajes, LIMITE_TEMPORAL);
    }
    public static void guardarMemoriaPermaJugador(UUID uuid, List<String> mensajes) {
        guardarLista(new File(BASE_DIR, uuid+"_perma.json"), mensajes, Integer.MAX_VALUE);
    }
    public static void guardarMemoriaGeneral(List<String> mensajes) {
        guardarLista(GENERAL_FILE, mensajes, LIMITE_TEMPORAL);
    }
    public static void guardarMemoriaPermaGeneral(List<String> mensajes) {
        guardarLista(GENERAL_PERMA_FILE, mensajes, Integer.MAX_VALUE);
    }
    private static List<String> cargarLista(File archivo, int limite) {
        if (!archivo.exists()) return new LinkedList<>();
        try (Reader reader = new InputStreamReader(new FileInputStream(archivo), StandardCharsets.UTF_8)) {
            Type type = new TypeToken<LinkedList<String>>(){}.getType();
            LinkedList<String> lista = GSON.fromJson(reader, type);
            if (lista == null) return new LinkedList<>();
            if (lista.size() > limite) {
                while (lista.size() > limite) lista.removeFirst();
            }
            return lista;
        } catch (Exception e) {
            return new LinkedList<>();
        }
    }
    private static void guardarLista(File archivo, List<String> mensajes, int limite) {
        LinkedList<String> lista = new LinkedList<>(mensajes);
        while (lista.size() > limite) lista.removeFirst();
        try (Writer writer = new OutputStreamWriter(new FileOutputStream(archivo), StandardCharsets.UTF_8)) {
            GSON.toJson(lista, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
