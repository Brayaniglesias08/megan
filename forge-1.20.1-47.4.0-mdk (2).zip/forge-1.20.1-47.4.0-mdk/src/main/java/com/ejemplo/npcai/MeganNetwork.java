package com.ejemplo.npcai;

import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.network.PacketDistributor;
import net.minecraft.resources.ResourceLocation;
import com.ejemplo.npcai.net.MeganAudioPacket;

public class MeganNetwork {
    public static final String PROTOCOL_VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
        new ResourceLocation("meganai:audio"),
        () -> PROTOCOL_VERSION, PROTOCOL_VERSION::equals, PROTOCOL_VERSION::equals
    );

    public static void register() {
        CHANNEL.registerMessage(
            0, MeganAudioPacket.class,
            (pkt, buf) -> pkt.toBytes(buf),
            MeganAudioPacket::new,
            (pkt, ctx) -> pkt.handle(ctx)
        );
    }
}
