package com.ejemplo.npcai;

/**
 * MeganEmotionEngine: Sistema de gestión de emociones para Megan.
 * Arquitectura limpia y modular, lista para integración IA.
 */
public class MeganEmotionEngine {
    private final MeganEntity megan;
    private String emocionActual = "neutral";
    public MeganEmotionEngine(MeganEntity megan) {
        this.megan = megan;
    }
    public void setEmocionActual(String emocion) {
        this.emocionActual = emocion;
    }

    /**
     * Cambia la emoción actual de Megan (alias para setEmocionActual).
     * @param emocion Nueva emoción a establecer.
     */
    public void cambiarEmocion(String emocion) {
        setEmocionActual(emocion);
    }
    public String getEmocionActual() {
        return emocionActual;
    }
}
