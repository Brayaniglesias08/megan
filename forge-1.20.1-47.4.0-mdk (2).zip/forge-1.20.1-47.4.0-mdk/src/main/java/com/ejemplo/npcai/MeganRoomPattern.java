package com.ejemplo.npcai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import com.ejemplo.npcai.MeganEntity;

/**
 * Patrón de minería tipo ROOM (sala) configurable (ancho x largo x altura)
 * Recorre la sala por "layers" en Y, y dentro de cada layer recorre filas y columnas.
 */
public class MeganRoomPattern implements MeganMiningPattern {
    private final BlockPos startPos;
    private final int width;
    private final int length;
    private final int height;
    private int currentY;
    private int currentX;
    private int currentZ;
    private boolean finished;

    /**
     * Crea un patrón de sala en la posición dada, con dimensiones configurables.
     * @param startPos esquina inferior-noroeste (mínimos X y Z, Y base)
     * @param width ancho de la sala (en X)
     * @param length largo de la sala (en Z)
     * @param height altura de la sala (en Y, hacia arriba)
     */
    public MeganRoomPattern(BlockPos startPos, int width, int length, int height) {
        this.startPos = startPos;
        this.width = width;
        this.length = length;
        this.height = height;
        this.currentY = 0;
        this.currentX = 0;
        this.currentZ = 0;
        this.finished = false;
    }

    @Override
    public BlockPos getNextBlockToMine(MeganEntity entity, Level level) {
        if (finished) return null;
        int baseY = startPos.getY();
        while (currentY < height) {
            while (currentX < width) {
                while (currentZ < length) {
                    BlockPos pos = new BlockPos(
                        startPos.getX() + currentX,
                        baseY + currentY,
                        startPos.getZ() + currentZ
                    );
                    currentZ++;
                    if (!level.getBlockState(pos).isAir()) {
                        return pos;
                    }
                }
                currentZ = 0;
                currentX++;
            }
            currentX = 0;
            currentY++;
        }
        finished = true;
        return null;
    }

    @Override
    public void reset(BlockPos startPos, net.minecraft.core.Direction direction) {
        this.currentY = 0;
        this.currentX = 0;
        this.currentZ = 0;
        this.finished = false;
        // Si necesitas actualizar startPos, quita el final del campo y descomenta:
        // this.startPos = startPos;
    }
}
