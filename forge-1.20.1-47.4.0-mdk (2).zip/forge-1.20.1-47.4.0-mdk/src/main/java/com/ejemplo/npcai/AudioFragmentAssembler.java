package com.ejemplo.npcai;

import java.util.*;

public class AudioFragmentAssembler {
    private static final Map<Integer, FragmentBuffer> buffers = new HashMap<>();

    public static void receiveFragment(AudioFragmentMessage msg) {
        FragmentBuffer buffer = buffers.computeIfAbsent(msg.getStreamId(), k -> new FragmentBuffer(msg.getTotalFragments(), msg.getMx(), msg.getMy(), msg.getMz()));
        buffer.addFragment(msg.getFragmentIndex(), msg.getFragmentData());
        if (buffer.isComplete()) {
            byte[] fullAudio = buffer.assemble();
            double mx = buffer.mx;
            double my = buffer.my;
            double mz = buffer.mz;
            buffers.remove(msg.getStreamId());
            playAudioAtMegan(fullAudio, mx, my, mz);
        }
    }

    // Nuevo método: Ensambla el audio y envía el paquete para reproducirlo en la posición de Megan
    public static void playAudioAtMegan(byte[] audioData, double mx, double my, double mz) {
        // Buscar la entidad Megan más cercana a la posición (mx, my, mz)
        net.minecraft.client.Minecraft mc = net.minecraft.client.Minecraft.getInstance();
        if (mc.level == null) {
            System.out.println("[MEGAN][FRAGMENT] No hay mundo cargado en el cliente");
            return;
        }
        net.minecraft.world.entity.Entity megan = null;
        double minDist = Double.MAX_VALUE;
        for (net.minecraft.world.entity.Entity e : mc.level.entitiesForRendering()) {
            if (e instanceof com.ejemplo.npcai.MeganEntity) {
                double dist = e.distanceToSqr(mx, my, mz);
                if (dist < minDist) {
                    minDist = dist;
                    megan = e;
                }
            }
        }
        if (megan != null) {
            SoundFollowEntity sound = OpenALPlayer.playFollowEntity(audioData, megan);
            if (sound != null) {
                ClientAudioTracker.addSound(sound);
                System.out.println("[MEGAN][FRAGMENT] Reproduciendo audio dinámico siguiendo a Megan: x=" + mx + ", y=" + my + ", z=" + mz);
            } else {
                System.out.println("[MEGAN][FRAGMENT] No se pudo crear SoundFollowEntity, se usará audio estático.");
                OpenALPlayer.playOgg(audioData, (float)mx, (float)my, (float)mz);
            }
        } else {
            System.out.println("[MEGAN][FRAGMENT] No se encontró entidad Megan cerca, se usará audio estático.");
            OpenALPlayer.playOgg(audioData, (float)mx, (float)my, (float)mz);
        }
    }

    private static class FragmentBuffer {
        private final byte[][] fragments;
        private final boolean[] received;
        private int receivedCount = 0;
        public final double mx, my, mz;

        public FragmentBuffer(int totalFragments, double mx, double my, double mz) {
            this.fragments = new byte[totalFragments][];
            this.received = new boolean[totalFragments];
            this.mx = mx;
            this.my = my;
            this.mz = mz;
        }

        public void addFragment(int index, byte[] data) {
            if (!received[index]) {
                fragments[index] = data;
                received[index] = true;
                receivedCount++;
            }
        }

        public boolean isComplete() {
            return receivedCount == fragments.length;
        }

        public byte[] assemble() {
            int totalLength = 0;
            for (byte[] frag : fragments) totalLength += frag.length;
            byte[] result = new byte[totalLength];
            int pos = 0;
            for (byte[] frag : fragments) {
                System.arraycopy(frag, 0, result, pos, frag.length);
                pos += frag.length;
            }
            return result;
        }
    }
}
