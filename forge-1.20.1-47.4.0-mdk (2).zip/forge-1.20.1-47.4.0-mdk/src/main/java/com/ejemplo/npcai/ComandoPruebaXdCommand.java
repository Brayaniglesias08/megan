package com.ejemplo.npcai;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;

public class ComandoPruebaXdCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        System.out.println("[NpcAIMod] Registrando ComandoPruebaXdCommand");
        dispatcher.register(
            LiteralArgumentBuilder.<CommandSourceStack>literal("comandopruebaxd")
                .executes(context -> {
                    CommandSourceStack source = context.getSource();
                    source.sendSuccess(() -> Component.literal("¡Comando de prueba XD funcionando!"), false);
                    return 1;
                })
        );
    }
}
