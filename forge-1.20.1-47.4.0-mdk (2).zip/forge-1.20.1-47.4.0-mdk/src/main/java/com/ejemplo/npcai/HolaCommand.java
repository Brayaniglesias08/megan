package com.ejemplo.npcai;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

public class HolaCommand {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
                LiteralArgumentBuilder.<CommandSourceStack>literal("pruebaaudio")
                        .executes(context -> {
                            CommandSourceStack source = context.getSource();
                            try {
                                ServerPlayer player = source.getPlayerOrException(); // Obtener el ServerPlayer
                                // Eliminado mensaje de texto duplicado para evitar doble respuesta en el chat.
                                // Reproducir voz con IA
                                // Nueva lógica: obtener audio OGG/Opus y enviarlo al cliente
                                // Siempre usar la voz de Megan (voice_id por defecto en ElevenLabsClient)
                                if (player.getServer() == null) {
                                    source.sendFailure(Component.literal("Error: Este comando solo puede ejecutarse en el servidor."));
                                    return 0;
                                }
                                String texto = "Hola, soy Megan, la voz de la IA en Minecraft.";
                                byte[] audioOpus = ElevenLabsClient.generarAudio(texto, null, null); // null usa el voice_id de Megan
                                // Buscar a Megan cerca del jugador
                                MeganEntity megan = player.level().getEntitiesOfClass(MeganEntity.class,
                                    player.getBoundingBox().inflate(64.0))
                                    .stream()
                                    .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(player)))
                                    .orElse(null);
                                double mx = player.getX(), my = player.getY(), mz = player.getZ();
                                System.out.println("[MEGAN][DEBUG] Posición jugador: x=" + mx + " y=" + my + " z=" + mz);
                                if (megan != null) {
                                    mx = megan.getX();
                                    my = megan.getY();
                                    mz = megan.getZ();
                                    System.out.println("[MEGAN][DEBUG] ¡Megan encontrada! Posición Megan: x=" + mx + " y=" + my + " z=" + mz);
                                } else {
                                    System.out.println("[MEGAN][DEBUG] Megan NO encontrada cerca. Usando posición del jugador.");
                                }
                                ModNetwork.INSTANCE.send(
                                    net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> player),
                                    new PlayAudioPacket(audioOpus, mx, my, mz)
                                );
                            } catch (Exception e) {
                                source.sendFailure(Component.literal("Error: Este comando solo puede ser ejecutado por un jugador."));
                                e.printStackTrace();
                                return 0;
                            }
                            return 1;
                        })
        );
    }
}