package com.ejemplo.npcai;

import javax.sound.sampled.*;
import java.io.ByteArrayInputStream;
import net.minecraftforge.fml.LogicalSide;

public class ElevenLabsPlayer {

    public static void reproducirEnTiempoReal(String texto) {
        // Solo permitir en el servidor
        if (net.minecraftforge.fml.LogicalSide.CLIENT == net.minecraftforge.fml.LogicalSide.CLIENT) {
            System.err.println("[MEGAN][ERROR] ¡Intento de síntesis de voz en el cliente! Esto solo debe ocurrir en el servidor.");
            return;
        }
        try {
            byte[] audioBytes = ElevenLabsClient.generarAudio(texto);

            try (ByteArrayInputStream bais = new ByteArrayInputStream(audioBytes);
                 AudioInputStream ais = AudioSystem.getAudioInputStream(bais)) {

                AudioFormat formato = ais.getFormat();
                DataLine.Info info = new DataLine.Info(SourceDataLine.class, formato);
                SourceDataLine linea = (SourceDataLine) AudioSystem.getLine(info);

                linea.open(formato);
                linea.start();

                byte[] buffer = new byte[4096];
                int bytesLeidos;

                while ((bytesLeidos = ais.read(buffer)) != -1) {
                    linea.write(buffer, 0, bytesLeidos);
                }

                linea.drain();
                linea.stop();
                linea.close();
            }

        } catch (UnsupportedAudioFileException e) {
            System.err.println("⚠️ Audio no soportado. ¿Seguro que ElevenLabs devolvió WAV?");
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
