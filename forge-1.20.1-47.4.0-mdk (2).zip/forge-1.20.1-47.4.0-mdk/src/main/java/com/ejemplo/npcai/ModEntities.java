package com.ejemplo.npcai;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Registro de entidades personalizadas del mod.
 */
public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, "meganai");

    public static final RegistryObject<EntityType<MeganEntity>> MEGAN = ENTITIES.register("megan",
        () -> EntityType.Builder.of(MeganEntity::new, MobCategory.CREATURE)
            .sized(0.6F, 1.95F)
            .build("megan")
    );
}
