package com.ejemplo.npcai;

import org.lwjgl.openal.AL10;
import java.io.File;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ShortBuffer;

public class MeganPositionalAudioDemo {
    // Utilidad robusta para cargar un archivo WAV PCM 16bit, detectando sampleRate y canales
    public static class WavPCM {
        public final short[] data;
        public final int sampleRate;
        public final int channels;
        public WavPCM(short[] data, int sampleRate, int channels) {
            this.data = data;
            this.sampleRate = sampleRate;
            this.channels = channels;
        }
    }
    public static WavPCM loadWavPcm(File file) throws IOException, UnsupportedAudioFileException {
        try (AudioInputStream ais = AudioSystem.getAudioInputStream(file)) {
            return decodeToPCM16(ais);
        }
    }
    public static WavPCM loadWavPcm(java.io.InputStream is) throws IOException, UnsupportedAudioFileException {
        try (AudioInputStream ais = AudioSystem.getAudioInputStream(is)) {
            return decodeToPCM16(ais);
        }
    }
    private static WavPCM decodeToPCM16(AudioInputStream ais) throws IOException, UnsupportedAudioFileException {
        javax.sound.sampled.AudioFormat baseFormat = ais.getFormat();
        javax.sound.sampled.AudioFormat decodedFormat = baseFormat;
        // Si no es PCM_SIGNED 16bit, convierte
        if (baseFormat.getEncoding() != javax.sound.sampled.AudioFormat.Encoding.PCM_SIGNED || baseFormat.getSampleSizeInBits() != 16) {
            decodedFormat = new javax.sound.sampled.AudioFormat(
                javax.sound.sampled.AudioFormat.Encoding.PCM_SIGNED,
                baseFormat.getSampleRate(),
                16,
                baseFormat.getChannels(),
                baseFormat.getChannels() * 2,
                baseFormat.getSampleRate(),
                false // little endian
            );
            ais = AudioSystem.getAudioInputStream(decodedFormat, ais);
        }
        int channels = decodedFormat.getChannels();
        int sampleRate = (int) decodedFormat.getSampleRate();
        byte[] bytes = ais.readAllBytes();
        // Little endian: convierte a short[]
        ShortBuffer sb = ByteBuffer.wrap(bytes).order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer();
        short[] shorts = new short[sb.remaining()];
        sb.get(shorts);
        return new WavPCM(shorts, sampleRate, channels);
    }

    // === ElevenLabs TTS ===
    public static java.io.InputStream elevenLabsTTSStream(String apiKey, String voiceId, String texto) throws IOException {
        String url = "https://api.elevenlabs.io/v1/text-to-speech/" + voiceId + "/stream";
        java.net.HttpURLConnection conn = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Accept", "audio/mpeg");
        conn.setRequestProperty("xi-api-key", apiKey);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setDoOutput(true);
        String json = "{\"text\":\"" + texto.replace("\"", "\\\"") + "\",\"model_id\":\"eleven_multilingual_v2\",\"voice_settings\":{}}";
        try (java.io.OutputStream os = conn.getOutputStream()) {
            os.write(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        if (code != 200) {
            throw new IOException("ElevenLabs API error: HTTP " + code + " - " + new String(conn.getErrorStream().readAllBytes()));
        }
        return conn.getInputStream(); // ¡El audio MP3 en streaming!
    }

    // === Guardar PCM como WAV (depuración) ===
    public static void savePcmAsWav(WavPCM wav, String outFile) throws java.io.IOException {
        javax.sound.sampled.AudioFormat fmt = new javax.sound.sampled.AudioFormat(
            wav.sampleRate, 16, wav.channels, true, false);
        byte[] bytes = new byte[wav.data.length * 2];
        for (int i = 0; i < wav.data.length; i++) {
            bytes[i*2] = (byte) (wav.data[i] & 0xFF);
            bytes[i*2+1] = (byte) ((wav.data[i] >> 8) & 0xFF);
        }
        javax.sound.sampled.AudioInputStream ais = new javax.sound.sampled.AudioInputStream(
            new java.io.ByteArrayInputStream(bytes), fmt, wav.data.length / wav.channels);
        javax.sound.sampled.AudioSystem.write(ais, javax.sound.sampled.AudioFileFormat.Type.WAVE, new java.io.File(outFile));
    }

    public static void main(String[] args) throws Exception {
        // 1. Inicializa OpenAL
        OpenALStreamingPlayer.init();

        // 2. Configura el listener (oído del jugador) en el centro, mirando hacia Z+
        AL10.alListener3f(AL10.AL_POSITION, 0f, 0f, 0f);
        AL10.alListener3f(AL10.AL_VELOCITY, 0f, 0f, 0f);
        float[] orientation = {0f, 0f, 1f, 0f, 1f, 0f}; // at(0,0,1), up(0,1,0)
        AL10.alListenerfv(AL10.AL_ORIENTATION, orientation);

        // 3. Carga el audio (archivo local, URL, o ElevenLabs TTS)
        String audioSource = args.length > 0 ? args[0] : "megan_voice.wav";
        WavPCM wav;
        if (audioSource.startsWith("elevenlabs:")) {
            // Sintetiza texto con ElevenLabs API
            String texto = audioSource.substring("elevenlabs:".length());
            String apiKey = "sk_cf4008ea0d155845102571785bd1316ef8e73635e4a63723";
            String voiceId = "n4x17EKVqyxfey8QMqvy";
            System.out.println("Solicitando voz a ElevenLabs... (texto: " + texto + ")");
            try (java.io.InputStream is = elevenLabsTTSStream(apiKey, voiceId, texto)) {
                // Guarda el audio MP3 recibido como archivo temporal para depuración
                java.nio.file.Path tempMp3 = java.nio.file.Files.createTempFile("megan_voice_debug", ".mp3");
                java.nio.file.Files.copy(is, tempMp3, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                System.out.println("[DEBUG] Audio MP3 recibido guardado en: " + tempMp3);
                // Ahora decodifica desde el archivo temporal
                wav = loadWavPcm(tempMp3.toFile());
                // (Opcional) Guarda el PCM como WAV para depuración
                savePcmAsWav(wav, "megan_voice_debug.wav");
                System.out.println("[DEBUG] Audio PCM guardado como: megan_voice_debug.wav");
            }
        } else if (audioSource.startsWith("http")) {
            System.out.println("Descargando audio desde URL: " + audioSource);
            try (java.io.InputStream is = new java.net.URL(audioSource).openStream()) {
                wav = loadWavPcm(is);
            }
        } else {
            File audioFile = new File(audioSource);
            if (!audioFile.exists()) {
                System.err.println("ERROR: No se encontró el archivo de audio: " + audioFile.getAbsolutePath());
                return;
            }
            wav = loadWavPcm(audioFile);
        }
        short[] pcmData = wav.data;
        int sampleRate = wav.sampleRate;
        int channels = wav.channels;
        System.out.println("Audio cargado - SampleRate: " + sampleRate + " Hz, Canales: " + channels);

        // Prueba: reproduce el WAV de depuración generado
        java.io.File debugWav = new java.io.File("megan_voice_debug.wav");
        if (debugWav.exists()) {
            System.out.println("[TEST] Reproduciendo megan_voice_debug.wav desde disco...");
            WavPCM wavDebug = loadWavPcm(debugWav);
            System.out.println("[TEST] WAV debug: SampleRate=" + wavDebug.sampleRate + ", Canales=" + wavDebug.channels + ", Frames=" + (wavDebug.data.length/(wavDebug.channels)));
            OpenALStreamingPlayer.playPCMStreamedWithDebug(wavDebug.data, wavDebug.sampleRate, wavDebug.channels, 0f, 0f, 0f, 100, 12);
            System.out.println("[TEST] Reproducción de WAV debug finalizada.");
        } else {
            System.out.println("[TEST] No se encontró megan_voice_debug.wav para prueba de reproducción.");
        }

        // 4. Crea la fuente OpenAL
        int source = AL10.alGenSources();
        AL10.alSourcei(source, AL10.AL_LOOPING, AL10.AL_FALSE);
        AL10.alSourcef(source, AL10.AL_GAIN, 1.0f);
        AL10.alSourcef(source, AL10.AL_REFERENCE_DISTANCE, 1.0f);
        AL10.alSourcef(source, AL10.AL_ROLLOFF_FACTOR, 1.0f);
        AL10.alSourcef(source, AL10.AL_MAX_DISTANCE, 50.0f);

        // 5. Lógica de movimiento: Megan camina de izquierda (-5,0,5) → centro (0,0,5) → derecha (5,0,5) → lejos (5,0,20) → centro → izquierda
        float[][] path = {
            {-5f, 0f, 5f},
            { 0f, 0f, 5f},
            { 5f, 0f, 5f},
            { 5f, 0f, 20f},
            { 0f, 0f, 5f},
            {-5f, 0f, 5f}
        };
        int[] lingerMs = {1500, 1500, 1500, 2000, 1500, 1500};
        int stepsPerSegment = 60; // Más pasos = movimiento más suave

        // 6. Arranca el audio (streaming)
        new Thread(() -> {
            OpenALStreamingPlayer.playPCMStreamedWithDebug(pcmData, sampleRate, channels, path[0][0], path[0][1], path[0][2], 100, 12, source);
        }).start();

        // 7. Mueve la fuente a lo largo del path
        for (int seg = 0; seg < path.length - 1; seg++) {
            float[] from = path[seg];
            float[] to = path[seg+1];
            for (int step = 0; step < stepsPerSegment; step++) {
                float t = step / (float) stepsPerSegment;
                float x = from[0] + (to[0] - from[0]) * t;
                float y = from[1] + (to[1] - from[1]) * t;
                float z = from[2] + (to[2] - from[2]) * t;
                AL10.alSource3f(source, AL10.AL_POSITION, x, y, z);
                Thread.sleep(lingerMs[seg] / stepsPerSegment);
            }
        }
        // Espera un poco al final
        Thread.sleep(2000);
        AL10.alSourceStop(source);
        AL10.alDeleteSources(source);
        System.out.println("Demo de audio 3D posicional finalizada.");
    }
}
