package com.ejemplo.npcai;

import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.SimpleContainer;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.common.extensions.IForgeMenuType;

public class MeganInventoryMenu extends AbstractContainerMenu {
    public static final int CONTAINER_SIZE = 27;
    private final SimpleContainer container;
    private final ContainerLevelAccess access;

    public MeganInventoryMenu(int id, Inventory playerInventory, FriendlyByteBuf buf) {
        this(id, playerInventory, new SimpleContainer(CONTAINER_SIZE));
    }

    public MeganInventoryMenu(int id, Inventory playerInventory, SimpleContainer container) {
        super(ModMenus.MEGAN_INVENTORY_MENU.get(), id);
        this.container = container;
        this.access = ContainerLevelAccess.NULL;

        int meganX = 18;
        int playerX = 190; // Ajusta según el ancho de tu fondo

        // Inventario de Megan (3 filas x 9 columnas)
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.addSlot(new Slot(container, j + i * 9, meganX + j * 18, 18 + i * 18));
            }
        }
        // Inventario del jugador (3 filas x 9 columnas)
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.addSlot(new Slot(playerInventory, j + i * 9 + 9, playerX + j * 18, 18 + i * 18));
            }
        }
        // Hotbar del jugador (debajo del inventario del jugador)
        for (int k = 0; k < 9; ++k) {
            this.addSlot(new Slot(playerInventory, k, playerX + k * 18, 76));
        }
    }

    @Override
    public boolean stillValid(Player player) { return true; }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack itemstack = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack itemstack1 = slot.getItem();
            itemstack = itemstack1.copy();
            if (index < CONTAINER_SIZE) {
                if (!this.moveItemStackTo(itemstack1, CONTAINER_SIZE, this.slots.size(), true)) {
                    return ItemStack.EMPTY;
                }
            } else if (!this.moveItemStackTo(itemstack1, 0, CONTAINER_SIZE, false)) {
                return ItemStack.EMPTY;
            }
            if (itemstack1.isEmpty()) {
                slot.set(ItemStack.EMPTY);
            } else {
                slot.setChanged();
            }
        }
        return itemstack;
    }
}