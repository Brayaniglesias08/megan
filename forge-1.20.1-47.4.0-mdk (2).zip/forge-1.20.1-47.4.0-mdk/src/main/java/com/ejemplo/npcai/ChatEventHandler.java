package com.ejemplo.npcai;

import java.io.File;

import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.network.PacketDistributor; // Para envío a múltiples jugadores
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.util.concurrent.ConcurrentHashMap;

@Mod.EventBusSubscriber(modid = "meganai")
public class ChatEventHandler {
    // Borra la memoria temporal de todos los jugadores y general al iniciar el servidor
    public static void reiniciarMemoriaTemporal() {
        File baseDir = new File("world/data/meganai/");
        if (baseDir.exists()) {
            File[] archivos = baseDir.listFiles();
            if (archivos != null) {
                for (File archivo : archivos) {
                    String nombre = archivo.getName();
                    if (nombre.endsWith(".json") && !nombre.contains("perma") && !nombre.contains("general_perma")) {
                        archivo.delete();
                    }
                    if (nombre.equals("general.json")) {
                        archivo.delete();
                    }
                }
            }
        }
    }
    private static final Logger LOGGER = LoggerFactory.getLogger(ChatEventHandler.class);
    private static final ConcurrentHashMap<String, Boolean> jugadoresRespondiendo = new ConcurrentHashMap<>();

    @SubscribeEvent
    public static void onServerChat(ServerChatEvent event) {
        String mensajeJugador = event.getMessage().getString();
        ServerPlayer jugador = event.getPlayer();
        if (!mensajeJugador.toLowerCase().contains("megan")) return;
        final String nombreJugador = jugador.getName().getString();
        if (jugadoresRespondiendo.putIfAbsent(nombreJugador, true) != null) return;
        if (jugador.getServer() == null) {
            LOGGER.error("[MEGAN][ERROR] ¡Intento de síntesis de voz en el cliente! Esto solo debe ocurrir en el servidor.");
            return;
        }
        new Thread(() -> {
            // --- Detectar comandos de acción para Megan ---
            String mensajeLower = mensajeJugador.toLowerCase();
            boolean accionRealizada = false;
            // --- Megan: devolver herramienta específica ---
            if (mensajeLower.matches(".*megan devuélveme (el|la) (pico|hacha|pala|espada).*")) {
                String herramienta = null;
                if (mensajeLower.contains("pico")) herramienta = "pico";
                else if (mensajeLower.contains("hacha")) herramienta = "hacha";
                else if (mensajeLower.contains("pala")) herramienta = "pala";
                else if (mensajeLower.contains("espada")) herramienta = "espada";
                if (herramienta != null) {
                    double radioBusqueda = 8.0;
                    MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                        jugador.getBoundingBox().inflate(radioBusqueda))
                        .stream()
                        .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                        .orElse(null);
                    if (meganCercana != null) {
                        net.minecraft.world.SimpleContainer inv = meganCercana.getInventory();
                        boolean entregado = false;
                        for (int i = 0; i < inv.getContainerSize(); i++) {
                            net.minecraft.world.item.ItemStack stack = inv.getItem(i);
                            String n = stack.getDisplayName().getString().toLowerCase();
                            if (!stack.isEmpty() && n.contains(herramienta)) {
                                net.minecraft.world.item.ItemStack dado = stack.split(1);
                                if (!jugador.getInventory().add(dado)) {
                                    jugador.drop(dado, false);
                                }
                                entregado = true;
                                try {
                                    String texto = "¡Aquí tienes tu " + herramienta + "!";
                                    byte[] audio = com.ejemplo.npcai.ElevenLabsTTS.solicitarAudioMP3(texto);
                                    com.ejemplo.npcai.AudioFragmentAssembler.playAudioAtMegan(audio, meganCercana.getX(), meganCercana.getY(), meganCercana.getZ());
                                } catch (Exception e) {}
                                LOGGER.info("[MEGAN][ACCIÓN] Megan devolvió {} al jugador.", herramienta);
                                break;
                            }
                        }
                        if (!entregado) {
                            LOGGER.warn("[MEGAN][ACCIÓN] Megan no tiene {} para devolver.", herramienta);
                        }
                        accionRealizada = true;
                    } else {
                        LOGGER.warn("[MEGAN][ACCIÓN] No se encontró a Megan cerca para devolver herramienta.");
                    }
                }
            }
            // --- Megan: detenerse (detente, espera, para) ---
            if (mensajeLower.contains("megan") &&
                (mensajeLower.contains("detente") || mensajeLower.contains("espera") || mensajeLower.contains("para"))) {
                double radioBusqueda = 10.0;
                MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                    jugador.getBoundingBox().inflate(radioBusqueda))
                    .stream()
                    .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                    .orElse(null);
                if (meganCercana != null) {
                    // Detener recolección
                    meganCercana.stopCollecting();
                    // Detener seguimiento
                    meganCercana.setObjetivoJugador(null);
                    // Detener movimiento inmediato
                    meganCercana.getNavigation().stop();
                    LOGGER.info("[MEGAN][ACCIÓN] Megan se detuvo por orden del jugador.");
                } else {
                    LOGGER.warn("[MEGAN][ACCIÓN] No se encontró a Megan cerca para detenerla.");
                }
            // --- Megan: seguir al jugador (sígueme, vamos, ven) ---
            } else if (mensajeLower.contains("megan") &&
                (mensajeLower.contains("sígueme") || mensajeLower.contains("sigueme") || mensajeLower.contains("vamos") || mensajeLower.contains("ven") || mensajeLower.contains("acompáñame") || mensajeLower.contains("acompaniame") || mensajeLower.contains("camina conmigo"))) {
                double radioBusqueda = 10.0;
                MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                    jugador.getBoundingBox().inflate(radioBusqueda))
                    .stream()
                    .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                    .orElse(null);
                if (meganCercana != null) {
                    meganCercana.stopCollecting(); // Cancelar recolección si está activa
                    meganCercana.setObjetivoJugador(jugador);
                    LOGGER.info("[MEGAN][ACCIÓN] Megan ahora sigue al jugador {}.", jugador.getName().getString());
                    // Reproducir audio aleatorio personalizado y terminar flujo
                    com.ejemplo.npcai.MeganCustomAudioPlayer.reproducirVenAleatorio(jugador, meganCercana);
                    return;
                }
            // --- Megan: dejar de seguir al jugador (adiós megan, ya no me sigas megan, chao megan) ---
            } else if ((mensajeLower.contains("adios megan") || mensajeLower.contains("adiós megan") || mensajeLower.contains("ya no me sigas megan") || mensajeLower.contains("chao megan"))) {
                double radioBusqueda = 10.0;
                MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                    jugador.getBoundingBox().inflate(radioBusqueda))
                    .stream()
                    .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                    .orElse(null);
                if (meganCercana != null) {
                    meganCercana.setObjetivoJugador(null); // Cancelar seguimiento
                    meganCercana.stopCollecting(); // Cancelar recolección
                    LOGGER.info("[MEGAN][ACCIÓN] Megan dejó de seguir al jugador por despedida.");
                }

            // --- Megan: recoger herramienta específica (comando flexible) ---
            // Acepta frases con: megan + (toma|agarra|recoge) + (espada|pico|hacha|pala) en cualquier orden
            }
            // --- Reconocimiento flexible para comando de recogida de herramienta ---
            if (true) {
                String[] herramientas = {"espada", "pico", "hacha", "pala"};
                String[] verbos = {"toma", "agarra", "recoge"};
                boolean contieneMegan = mensajeLower.contains("megan");
                boolean contieneVerbo = false;
                String herramientaDetectada = null;
                for (String v : verbos) {
                    if (mensajeLower.contains(v)) {
                        contieneVerbo = true;
                        break;
                    }
                }
                for (String h : herramientas) {
                    if (mensajeLower.contains(h)) {
                        herramientaDetectada = h;
                        break;
                    }
                }
                if (contieneMegan && contieneVerbo && herramientaDetectada != null) {
                    LOGGER.info("[MEGAN][DEPURACIÓN] Detectado comando de recogida: verbo={}, herramienta={}", contieneVerbo, herramientaDetectada);
                    // --- Copia el bloque de recogida de herramienta aquí (líneas 186-250 aprox) ---
                    String herramienta = herramientaDetectada;
                    double radioBusqueda = 20.0;
                    MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                        jugador.getBoundingBox().inflate(radioBusqueda))
                        .stream()
                        .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                        .orElse(null);
                    if (meganCercana != null) {
                        meganCercana.stopCollecting(); // Cancelar recolección si está activa
                        meganCercana.setObjetivoJugador(null); // Cancelar seguimiento
                        final String herramientaFinal = herramienta;
                        java.util.List<net.minecraft.world.entity.item.ItemEntity> itemsCerca = jugador.level().getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,
                            meganCercana.getBoundingBox().inflate(20.0));
                        for (net.minecraft.world.entity.item.ItemEntity e : itemsCerca) {
                            net.minecraft.world.item.ItemStack stack = e.getItem();
                            LOGGER.info("[DEPURACIÓN][MEGAN] Item detectado cerca: {} | DescId: {} | isSword: {} | isPickaxe: {} | isAxe: {} | isShovel: {}", stack.getDisplayName().getString(), stack.getItem().getDescriptionId(), com.ejemplo.npcai.ToolUtil.isSword(stack), com.ejemplo.npcai.ToolUtil.isPickaxe(stack), com.ejemplo.npcai.ToolUtil.isAxe(stack), com.ejemplo.npcai.ToolUtil.isShovel(stack));
                        }
                        net.minecraft.world.entity.item.ItemEntity itemEntity = itemsCerca
                            .stream()
                            .filter(e -> {
                                net.minecraft.world.item.ItemStack stack = e.getItem();
                                if (herramientaFinal.equals("pico")) return com.ejemplo.npcai.ToolUtil.isPickaxe(stack);
                                if (herramientaFinal.equals("hacha")) return com.ejemplo.npcai.ToolUtil.isAxe(stack);
                                if (herramientaFinal.equals("pala")) return com.ejemplo.npcai.ToolUtil.isShovel(stack);
                                if (herramientaFinal.equals("espada")) return com.ejemplo.npcai.ToolUtil.isSword(stack);
                                return false;
                            })
                            .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(meganCercana)))
                            .orElse(null);
                        if (itemEntity != null) {
                            double distancia = meganCercana.distanceTo(itemEntity);
                            if (distancia > 4.0) {
                                LOGGER.info("[MEGAN][ACCIÓN] Megan se mueve hacia la {} (distancia: {}).", herramienta, distancia);
                                meganCercana.getNavigation().moveTo(itemEntity, 1.1);
                                int intentos = 0;
                                boolean pudoAcercarse = false;
                                while (meganCercana.distanceTo(itemEntity) > 2.2 && intentos < 160 && !itemEntity.isRemoved()) {
                                    try { Thread.sleep(50); } catch (Exception e) {}
                                    intentos++;
                                    // Si Megan se atasca, intentar teletransportarla cerca
                                    if (intentos % 40 == 0 && meganCercana.distanceTo(itemEntity) > 6.0) {
                                        meganCercana.teleportTo(itemEntity.getX(), itemEntity.getY(), itemEntity.getZ());
                                        LOGGER.info("[MEGAN][DEBUG] Megan se teletransportó cerca del item por atasco.");
                                    }
                                }
                                if (meganCercana.distanceTo(itemEntity) <= 4.0 && !itemEntity.isRemoved()) {
                                    pudoAcercarse = true;
                                }
                                if (!pudoAcercarse) {
                                    try {
                                        String texto = "No puedo llegar a la " + herramienta + ". Está demasiado lejos o hay obstáculos.";
                                        byte[] audio = com.ejemplo.npcai.ElevenLabsTTS.solicitarAudioMP3(texto);
                                        com.ejemplo.npcai.AudioFragmentAssembler.playAudioAtMegan(audio, meganCercana.getX(), meganCercana.getY(), meganCercana.getZ());
                                    } catch (Exception e) {}
                                    LOGGER.warn("[MEGAN][ACCIÓN] Megan no pudo acercarse lo suficiente a la {} para recogerla.", herramienta);
                                    return;
                                }
                            }
                            if (meganCercana.distanceTo(itemEntity) <= 4.0 && !itemEntity.isRemoved()) {
                                meganCercana.addItemToInventory(itemEntity.getItem().copy());
                                itemEntity.discard();
                                try {
                                    String texto = "¡Gracias! Ahora tengo la " + herramienta + ".";
                                    byte[] audio = com.ejemplo.npcai.ElevenLabsTTS.solicitarAudioMP3(texto);
                                    com.ejemplo.npcai.AudioFragmentAssembler.playAudioAtMegan(audio, meganCercana.getX(), meganCercana.getY(), meganCercana.getZ());
                                } catch (Exception e) {}
                                accionRealizada = true;
                                LOGGER.info("[MEGAN][ACCIÓN] Megan recogió una {} del suelo.", herramienta);
                            } else {
                                try {
                                    String texto = "No pude recoger la " + herramienta + ". Está demasiado lejos o no puedo alcanzarla.";
                                    byte[] audio = com.ejemplo.npcai.ElevenLabsTTS.solicitarAudioMP3(texto);
                                    com.ejemplo.npcai.AudioFragmentAssembler.playAudioAtMegan(audio, meganCercana.getX(), meganCercana.getY(), meganCercana.getZ());
                                } catch (Exception e) {}
                                LOGGER.warn("[MEGAN][ACCIÓN] Megan no pudo acercarse lo suficiente a la {} para recogerla.", herramienta);
                            }
                        } else {
                            LOGGER.warn("[MEGAN][ACCIÓN] No se encontró {} cerca para recoger.", herramienta);
                        }
                    } else {
                        LOGGER.warn("[MEGAN][ACCIÓN] No se encontró a Megan cerca para recoger herramienta.");
                    }
                    return;
                }

            // --- Megan: recolectar recurso específico (tierra, piedra, madera, etc) ---
            // Ejemplo: 'megan recolecta tierra', 'megan mina piedra', 'megan corta madera'
            } else if (mensajeLower.contains("megan") &&
                (mensajeLower.contains("recolecta") || mensajeLower.contains("mina") || mensajeLower.contains("corta") || mensajeLower.contains("pica"))) {
                String recurso = null;
                for (String key : com.ejemplo.npcai.MeganEntity.NAMED_RESOURCES.keySet()) {
                    if (mensajeLower.contains(key)) {
                        recurso = key;
                        break;
                    }
                }
                if (recurso != null) {
                    double radioBusqueda = 10.0;
                    MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                        jugador.getBoundingBox().inflate(radioBusqueda))
                        .stream()
                        .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                        .orElse(null);
                    if (meganCercana != null) {
                        // Asignar objetivo de recolección
                        java.util.Set<net.minecraft.world.level.block.Block> bloques = com.ejemplo.npcai.MeganEntity.NAMED_RESOURCES.get(recurso);
                        if (meganCercana.collectGoal != null) {
                            MeganDebugLogger.log("[MEGAN][RECOLECCION][DEBUG][ChatEventHandler] Eliminando collectGoal (prioridad 1) para: " + recurso);
                            
                            meganCercana.goalSelector.removeGoal(meganCercana.collectGoal);
                            
                        }
                        meganCercana.collectGoal = new com.ejemplo.npcai.MeganCollectResourceGoal(meganCercana, bloques, 16, pos -> true);
                        MeganDebugLogger.log("[MEGAN][RECOLECCION][DEBUG][ChatEventHandler] Añadiendo collectGoal (prioridad 1) para: " + recurso);
                        
                        meganCercana.goalSelector.addGoal(1, meganCercana.collectGoal);
                        
                        try {
                            String texto = "¡Recolectando " + recurso + "!";
                            byte[] audio = com.ejemplo.npcai.ElevenLabsTTS.solicitarAudioMP3(texto);
                            com.ejemplo.npcai.AudioFragmentAssembler.playAudioAtMegan(audio, meganCercana.getX(), meganCercana.getY(), meganCercana.getZ());
                        } catch (Exception e) {}
                        LOGGER.info("[MEGAN][ACCIÓN] Megan comienza a recolectar {}.", recurso);
                    } else {
                        LOGGER.warn("[MEGAN][ACCIÓN] No se encontró a Megan cerca para recolectar {}.", recurso);
                    }
                }
            
                String herramienta = null;
                if (mensajeLower.contains("pico")) herramienta = "pico";
                else if (mensajeLower.contains("hacha")) herramienta = "hacha";
                else if (mensajeLower.contains("pala")) herramienta = "pala";
                else if (mensajeLower.contains("espada")) herramienta = "espada";
                if (herramienta != null) {
                    double radioBusqueda = 8.0;
                    MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                        jugador.getBoundingBox().inflate(radioBusqueda))
                        .stream()
                        .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                        .orElse(null);
                    if (meganCercana != null) {
                        meganCercana.stopCollecting(); // Cancelar recolección si está activa
                        meganCercana.setObjetivoJugador(null); // Cancelar seguimiento
                        // Buscar el ItemEntity más cercano que coincida con la herramienta (por tipo, no solo nombre)
                        final String herramientaFinal = herramienta;
                        java.util.List<net.minecraft.world.entity.item.ItemEntity> itemsCerca = jugador.level().getEntitiesOfClass(net.minecraft.world.entity.item.ItemEntity.class,
                            meganCercana.getBoundingBox().inflate(20.0));
                        for (net.minecraft.world.entity.item.ItemEntity e : itemsCerca) {
                            net.minecraft.world.item.ItemStack stack = e.getItem();
                            LOGGER.info("[DEPURACIÓN][MEGAN] Item detectado cerca: {} | DescId: {} | isSword: {} | isPickaxe: {} | isAxe: {} | isShovel: {}", stack.getDisplayName().getString(), stack.getItem().getDescriptionId(), com.ejemplo.npcai.ToolUtil.isSword(stack), com.ejemplo.npcai.ToolUtil.isPickaxe(stack), com.ejemplo.npcai.ToolUtil.isAxe(stack), com.ejemplo.npcai.ToolUtil.isShovel(stack));
                        }
                        net.minecraft.world.entity.item.ItemEntity itemEntity = itemsCerca
                            .stream()
                            .filter(e -> {
                                net.minecraft.world.item.ItemStack stack = e.getItem();
                                if (herramientaFinal.equals("pico")) return com.ejemplo.npcai.ToolUtil.isPickaxe(stack);
                                if (herramientaFinal.equals("hacha")) return com.ejemplo.npcai.ToolUtil.isAxe(stack);
                                if (herramientaFinal.equals("pala")) return com.ejemplo.npcai.ToolUtil.isShovel(stack);
                                if (herramientaFinal.equals("espada")) return com.ejemplo.npcai.ToolUtil.isSword(stack);
                                return false;
                            })
                            .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(meganCercana)))
                            .orElse(null);
                        if (itemEntity != null) {
                            double distancia = meganCercana.distanceTo(itemEntity);
                            if (distancia > 4.0) {
                                LOGGER.info("[MEGAN][ACCIÓN] Megan se mueve hacia la {} (distancia: {}).", herramienta, distancia);
                                meganCercana.getNavigation().moveTo(itemEntity, 1.1);
                                int intentos = 0;
                                boolean pudoAcercarse = false;
                                while (meganCercana.distanceTo(itemEntity) > 2.2 && intentos < 160 && !itemEntity.isRemoved()) {
                                    try { Thread.sleep(50); } catch (Exception e) {}
                                    intentos++;
                                    // Si Megan se atasca, intentar teletransportarla cerca
                                    if (intentos % 40 == 0 && meganCercana.distanceTo(itemEntity) > 6.0) {
                                        meganCercana.teleportTo(itemEntity.getX(), itemEntity.getY(), itemEntity.getZ());
                                        LOGGER.info("[MEGAN][DEBUG] Megan se teletransportó cerca del item por atasco.");
                                    }
                                }
                                if (meganCercana.distanceTo(itemEntity) <= 4.0 && !itemEntity.isRemoved()) {
                                    pudoAcercarse = true;
                                }
                                if (!pudoAcercarse) {
                                    try {
                                        String texto = "No puedo llegar a la " + herramienta + ". Está demasiado lejos o hay obstáculos.";
                                        byte[] audio = com.ejemplo.npcai.ElevenLabsTTS.solicitarAudioMP3(texto);
                                        com.ejemplo.npcai.AudioFragmentAssembler.playAudioAtMegan(audio, meganCercana.getX(), meganCercana.getY(), meganCercana.getZ());
                                    } catch (Exception e) {}
                                    LOGGER.warn("[MEGAN][ACCIÓN] Megan no pudo acercarse lo suficiente a la {} para recogerla.", herramienta);
                                    return;
                                }
                            }
                            if (meganCercana.distanceTo(itemEntity) <= 4.0 && !itemEntity.isRemoved()) {
                                meganCercana.addItemToInventory(itemEntity.getItem().copy());
                                itemEntity.discard();
                                try {
                                    String texto = "¡Gracias! Ahora tengo la " + herramienta + ".";
                                    byte[] audio = com.ejemplo.npcai.ElevenLabsTTS.solicitarAudioMP3(texto);
                                    com.ejemplo.npcai.AudioFragmentAssembler.playAudioAtMegan(audio, meganCercana.getX(), meganCercana.getY(), meganCercana.getZ());
                                } catch (Exception e) {}
                                accionRealizada = true;
                                LOGGER.info("[MEGAN][ACCIÓN] Megan recogió una {} del suelo.", herramienta);
                            } else {
                                try {
                                    String texto = "No pude recoger la " + herramienta + ". Está demasiado lejos o no puedo alcanzarla.";
                                    byte[] audio = com.ejemplo.npcai.ElevenLabsTTS.solicitarAudioMP3(texto);
                                    com.ejemplo.npcai.AudioFragmentAssembler.playAudioAtMegan(audio, meganCercana.getX(), meganCercana.getY(), meganCercana.getZ());
                                } catch (Exception e) {}
                                LOGGER.warn("[MEGAN][ACCIÓN] Megan no pudo acercarse lo suficiente a la {} para recogerla.", herramienta);
                            }
                        } else {
                            LOGGER.warn("[MEGAN][ACCIÓN] No se encontró {} cerca para recoger.", herramienta);
                        }
                    } else {
                        LOGGER.warn("[MEGAN][ACCIÓN] No se encontró a Megan cerca para recoger herramienta.");
                    }
                }
            }
            // --- Megan: revivir jugador (Corail Tombstone) ---
            if ((mensajeLower.contains("reviveme") || mensajeLower.matches(".*revive a \\w+.*")) && mensajeLower.contains("megan")) {
                double radioBusqueda = 64.0;
                MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                    jugador.getBoundingBox().inflate(radioBusqueda))
                    .stream()
                    .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                    .orElse(null);
                ServerPlayer objetivo = null;
                if (mensajeLower.contains("reviveme")) {
                    objetivo = jugador;
                } else {
                    // Buscar nombre después de "revive a "
                    java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("revive a (\\w+)").matcher(mensajeLower);
                    if (matcher.find()) {
                        String nombreObjetivo = matcher.group(1);
                        objetivo = jugador.getServer().getPlayerList().getPlayers().stream()
                            .filter(p -> p.getName().getString().equalsIgnoreCase(nombreObjetivo))
                            .findFirst().orElse(null);
                    }
                }
                if (meganCercana != null && objetivo != null) {
                    // Que Megan camine hacia el jugador caído
                    meganCercana.goToPlayer(objetivo);
                    // Esperar a estar cerca (distancia < 2)
                    int intentos = 0;
                    while (meganCercana.distanceTo(objetivo) > 2.0 && intentos < 80) { // máx 4 segundos
                        try { Thread.sleep(50); } catch (Exception e) {}
                        intentos++;
                    }
                    // Animación y voz
                    try {
                        String texto = "¡No te preocupes, te ayudo a revivir!";
                        byte[] audio = com.ejemplo.npcai.ElevenLabsTTS.solicitarAudioMP3(texto);
                        com.ejemplo.npcai.AudioFragmentAssembler.playAudioAtMegan(audio, meganCercana.getX(), meganCercana.getY(), meganCercana.getZ());
                    } catch (Exception e) {}
                    // Simular mantener clic derecho por 3 segundos
                    for (int i = 0; i < 100; i++) { // 100 ciclos ~ 5 segundos
                        net.minecraftforge.common.ForgeHooks.onInteractEntity(objetivo, meganCercana, net.minecraft.world.InteractionHand.MAIN_HAND);
                        ((net.minecraft.world.entity.LivingEntity) meganCercana).swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
                        meganCercana.level().broadcastEntityEvent(meganCercana, (byte) 4);
                        try { Thread.sleep(50); } catch (Exception e) {}
                    }
                    // Mensaje final
                    try {
                        String texto = "¡Listo! Espero que estés bien.";
                        byte[] audio = com.ejemplo.npcai.ElevenLabsTTS.solicitarAudioMP3(texto);
                        com.ejemplo.npcai.AudioFragmentAssembler.playAudioAtMegan(audio, meganCercana.getX(), meganCercana.getY(), meganCercana.getZ());
                    } catch (Exception e) {}
                    accionRealizada = true;
                    LOGGER.info("[MEGAN][ACCIÓN] Megan intentó revivir a {}", objetivo.getName().getString());
                } else {
                    LOGGER.warn("[MEGAN][ACCIÓN] No se encontró a Megan o al jugador objetivo para revivir.");
                }
            }
            // --- Megan: recolectar/minar ---
            if ((mensajeLower.contains("ve a recolectar") || mensajeLower.contains("ve a minar")) && mensajeLower.contains("megan")) {
                double radioBusqueda = 64.0;
                MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                    jugador.getBoundingBox().inflate(radioBusqueda))
                    .stream()
                    .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                    .orElse(null);
                if (meganCercana != null) {
                    meganCercana.startCollectingAllResources();
                    accionRealizada = true;
                    LOGGER.info("[MEGAN][ACCIÓN] Megan comienza a recolectar todos los recursos.");
                } else {
                    LOGGER.warn("[MEGAN][ACCIÓN] No se encontró a Megan cerca para recolectar.");
                }
            }
            // --- Megan: recolectar recurso específico ---
            else if (mensajeLower.contains("ve por") && mensajeLower.contains("megan")) {
                String[] recursos = {"tierra", "piedra", "arena", "hierro", "carbón", "madera", "redstone", "lapislázuli", "diamante", "esmeralda"};
                String recursoEncontrado = null;
                for (String recurso : recursos) {
                    if (mensajeLower.contains(recurso)) {
                        recursoEncontrado = recurso;
                        break;
                    }
                }
                if (recursoEncontrado != null) {
                    double radioBusqueda = 64.0;
                    MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                        jugador.getBoundingBox().inflate(radioBusqueda))
                        .stream()
                        .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                        .orElse(null);
                    System.out.println("[MEGAN][RECOLECCION][DEBUG][ChatEventHandler] Comando de recolección detectado: " + recursoEncontrado);
                    if (meganCercana != null) {
                        System.out.println("[MEGAN][RECOLECCION][DEBUG][ChatEventHandler] Megan encontrada cerca, llamando a startCollectingResourceByName con: " + recursoEncontrado);
                        MeganDebugLogger.log("[MEGAN][RECOLECCION][DEBUG][ChatEventHandler] Llamando a startCollectingResourceByName con: " + recursoEncontrado);
meganCercana.startCollectingResourceByName(recursoEncontrado);
                    } else {
                        System.out.println("[MEGAN][RECOLECCION][DEBUG][ChatEventHandler] No se encontró a Megan cerca para recolectar: " + recursoEncontrado);
                    }
                }
            }
            // --- Megan: dar recurso al jugador (cantidad soportada o TODO si se pide) ---
            else if (mensajeLower.contains("megan dame")) {
                String[] recursos = {"tierra", "piedra", "arena", "hierro", "carbón", "madera", "redstone", "lapislázuli", "diamante", "esmeralda"};
                String recursoEncontrado = null;
                int cantidad = 1;
                boolean pedirTodo = false;
                // Detectar si el jugador pide TODO
                if (mensajeLower.contains("todo ") || mensajeLower.contains("todos ")) {
                    pedirTodo = true;
                }
                // Detectar cantidad si se escribe "megan dame 5 piedra"
                java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("megan dame (\\d+)").matcher(mensajeLower);
                if (matcher.find()) {
                    try {
                        cantidad = Integer.parseInt(matcher.group(1));
                    } catch (Exception e) { cantidad = 1; }
                }
                if (pedirTodo) {
                    cantidad = Integer.MAX_VALUE;
                }
                for (String recurso : recursos) {
                    if (mensajeLower.contains(recurso)) {
                        recursoEncontrado = recurso;
                        break;
                    }
                }
                double radioBusqueda = 64.0;
                MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                    jugador.getBoundingBox().inflate(radioBusqueda))
                    .stream()
                    .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                    .orElse(null);
                if (meganCercana != null && recursoEncontrado != null) {
                    net.minecraft.world.SimpleContainer inv = meganCercana.getInventory();
                    int entregados = 0;
                    for (int i = 0; i < inv.getContainerSize(); i++) {
                        net.minecraft.world.item.ItemStack stack = inv.getItem(i);
                        if (!stack.isEmpty() && stack.getDisplayName().getString().toLowerCase().contains(recursoEncontrado)) {
                            while (!stack.isEmpty() && entregados < cantidad) {
                                net.minecraft.world.item.ItemStack dado = stack.split(1);
                                if (!jugador.getInventory().add(dado)) {
                                    jugador.drop(dado, false);
                                }
                                entregados++;
                            }
                            if (entregados >= cantidad) break;
                        }
                    }
                    if (entregados > 0) {
                        LOGGER.info("[MEGAN][ACCIÓN] Megan entregó {} x{} a {}", recursoEncontrado, entregados, jugador.getName().getString());
                        if (pedirTodo) {
                            // Comentario por voz sobre su esfuerzo y pago
                            try {
                                String texto = "Te he dado todo lo que tengo de " + recursoEncontrado + ". ¡Trabajé muy duro! Creo que merezco un pago, ¿no crees?";
                                byte[] audio = com.ejemplo.npcai.ElevenLabsTTS.solicitarAudioMP3(texto);
                                com.ejemplo.npcai.AudioFragmentAssembler.playAudioAtMegan(audio, meganCercana.getX(), meganCercana.getY(), meganCercana.getZ());
                            } catch (Exception e) {
                                LOGGER.error("[MEGAN][VOZ] Error al generar comentario de pago: ", e);
                            }
                        }
                    } else {
                        // Hablar con voz usando ElevenLabsTTS
                        try {
                            String texto = "No tengo " + recursoEncontrado + ".";
                            byte[] audio = com.ejemplo.npcai.ElevenLabsTTS.solicitarAudioMP3(texto);
                            com.ejemplo.npcai.AudioFragmentAssembler.playAudioAtMegan(audio, meganCercana.getX(), meganCercana.getY(), meganCercana.getZ());
                        } catch (Exception e) {
                            LOGGER.error("[MEGAN][VOZ] Error al generar audio de voz: ", e);
                        }
                        LOGGER.info("[MEGAN][ACCIÓN] Megan no tiene {} para entregar.", recursoEncontrado);
                    }
                    accionRealizada = true;
                }
            }
            // --- Megan: parar recolección ---
            else if ((mensajeLower.contains("megan para") || mensajeLower.contains("megan detente"))) {
                double radioBusqueda = 64.0;
                MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                    jugador.getBoundingBox().inflate(radioBusqueda))
                    .stream()
                    .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                    .orElse(null);
                if (meganCercana != null) {
                    meganCercana.stopCollecting();
                    accionRealizada = true;
                    LOGGER.info("[MEGAN][ACCIÓN] Megan detiene la recolección.");
                } else {
                    LOGGER.warn("[MEGAN][ACCIÓN] No se encontró a Megan cerca para detener la recolección.");
                }
            }
            if (mensajeLower.contains("ven") && mensajeLower.contains("megan")) {
                double radioBusqueda = 64.0;
                MeganEntity meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                    jugador.getBoundingBox().inflate(radioBusqueda))
                    .stream()
                    .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                    .orElse(null);
                if (meganCercana != null) {
                    meganCercana.goToPlayer(jugador);
                    accionRealizada = true;
                    LOGGER.info("[MEGAN][ACCIÓN] Megan va hacia el jugador {}", nombreJugador);
                    // Reproducir audio posicional de "ven" con sistema de sonidos de Minecraft
                    java.util.Random rand = new java.util.Random();
                    int opcion = rand.nextInt(5) + 1; // 1 a 5
                    net.minecraft.resources.ResourceLocation soundLoc = new net.minecraft.resources.ResourceLocation("meganai", "megan_voice_ven_" + opcion);
                    net.minecraft.sounds.SoundEvent sound = net.minecraftforge.registries.ForgeRegistries.SOUND_EVENTS.getValue(soundLoc);
                    if (sound != null) {
                        meganCercana.level().playSound(
                            null,
                            meganCercana.getX(),
                            meganCercana.getY(),
                            meganCercana.getZ(),
                            sound,
                            net.minecraft.sounds.SoundSource.PLAYERS,
                            1.0F,
                            1.0F
                        );
                    } else {
                        LOGGER.warn("[MEGAN][ACCIÓN] No se encontró el sonido: {}", soundLoc);
                    }
                } else {
                    LOGGER.warn("[MEGAN][ACCIÓN] No se encontró a Megan cerca para la acción 'ven'.");
                }
            }

            if (accionRealizada) {
                jugadoresRespondiendo.remove(nombreJugador);
                return;
            }

            try {
                Thread.sleep(1000); // Delay para que el mensaje del jugador aparezca antes
                LOGGER.info("[DEPURACIÓN] Solicitando respuesta a ChatGPT para: {}", mensajeJugador);
                // Construir contexto del mundo
                String contexto = "";
                try {
                    String hora = jugador.level().isDay() ? "Es de día" : "Es de noche";
                    String clima = jugador.level().isRaining() ? "y está lloviendo" : "y no está lloviendo";
                    int vida = (int) jugador.getHealth();
                    contexto = hora + " " + clima + ". El jugador tiene " + vida + " corazones de vida.";
                } catch (Exception ex) {
                    contexto = "No se pudo obtener el contexto del mundo.";
                }
                // --- Manejo de memoria ---
                java.util.UUID uuidJugador = jugador.getUUID();
                // Cargar memoria temporal y permanente del jugador
                java.util.List<String> memoriaJugador = MeganMemoryManager.cargarMemoriaJugador(uuidJugador);
                java.util.List<String> memoriaPermaJugador = MeganMemoryManager.cargarMemoriaPermaJugador(uuidJugador);
                // Cargar memoria general y permanente general
                java.util.List<String> memoriaGeneral = MeganMemoryManager.cargarMemoriaGeneral();
                java.util.List<String> memoriaPermaGeneral = MeganMemoryManager.cargarMemoriaPermaGeneral();
                // Detectar si el mensaje pide memoria permanente
                boolean guardarPerma = false;
                String mensajeParaGuardar = mensajeJugador.toLowerCase();
                if (mensajeParaGuardar.contains("recuerda esto para siempre") ||
                    mensajeParaGuardar.contains("nunca olvides") ||
                    mensajeParaGuardar.contains("guarda esto") ||
                    mensajeParaGuardar.matches(".*recuerda(.*)para siempre.*") ||
                    mensajeParaGuardar.contains("memoriza esto") ||
                    mensajeParaGuardar.contains("graba esto") ||
                    mensajeParaGuardar.contains("no lo olvides")
                ) {
                    guardarPerma = true;
                }
                // Construir historial para el prompt
                StringBuilder historial = new StringBuilder();
                // Limitar la cantidad de recuerdos/mensajes incluidos en el prompt a los últimos 2 de cada tipo
                if (!memoriaPermaJugador.isEmpty()) {
                    java.util.List<String> ultimosPermaJugador = memoriaPermaJugador.subList(Math.max(0, memoriaPermaJugador.size()-2), memoriaPermaJugador.size());
                    historial.append("Recuerdos importantes contigo: ").append(ultimosPermaJugador).append(". ");
                }
                if (!memoriaJugador.isEmpty()) {
                    java.util.List<String> ultimosRecientesJugador = memoriaJugador.subList(Math.max(0, memoriaJugador.size()-2), memoriaJugador.size());
                    historial.append("Historial reciente contigo: ").append(ultimosRecientesJugador).append(". ");
                }
                if (!memoriaPermaGeneral.isEmpty()) {
                    java.util.List<String> ultimosPermaGeneral = memoriaPermaGeneral.subList(Math.max(0, memoriaPermaGeneral.size()-2), memoriaPermaGeneral.size());
                    historial.append("Recuerdos importantes del servidor: ").append(ultimosPermaGeneral).append(". ");
                }
                if (!memoriaGeneral.isEmpty()) {
                    java.util.List<String> ultimosRecientesGeneral = memoriaGeneral.subList(Math.max(0, memoriaGeneral.size()-2), memoriaGeneral.size());
                    historial.append("Historial reciente del servidor: ").append(ultimosRecientesGeneral).append(". ");
                }
                // Prompt enriquecido
                String promptFinal = historial.toString() + " " + mensajeJugador;
                String respuesta = ChatGPTIntegration.obtenerRespuestaDeChatGPT(
                    MeganConversationManager.obtenerHistorial(uuidJugador),
                    nombreJugador,
                    contexto
                );
                // Guardar en memoria
                if (guardarPerma) {
                    memoriaPermaJugador.add(mensajeJugador);
                    MeganMemoryManager.guardarMemoriaPermaJugador(uuidJugador, memoriaPermaJugador);
                } else {
                    memoriaJugador.add(mensajeJugador);
                    MeganMemoryManager.guardarMemoriaJugador(uuidJugador, memoriaJugador);
                }
                // Guardar siempre en memoria general
                memoriaGeneral.add(mensajeJugador);
                MeganMemoryManager.guardarMemoriaGeneral(memoriaGeneral);
                LOGGER.info("[DEPURACIÓN] Respuesta de ChatGPT: {}", respuesta);

                // 1. Obtener audio MP3 de ElevenLabs
                LOGGER.info("[DEPURACIÓN] Solicitando audio MP3 a ElevenLabs para el texto de Megan...");
                // Reproducir voz usando ElevenLabsClient y enviar al cliente
                byte[] audioMp3 = ElevenLabsClient.generarAudio(respuesta);
                LOGGER.info("[DEPURACIÓN] Audio MP3 recibido de ElevenLabs. Tamaño: {} bytes", (audioMp3 != null ? audioMp3.length : -1));
                byte[] audioWav = null;
                try {
                    audioWav = AudioUtils.convertirAudioAWav(audioMp3, "mp3");
                    LOGGER.info("[DEPURACIÓN] Audio WAV generado. Tamaño: {} bytes", (audioWav != null ? audioWav.length : -1));

                     // --- Calcular posición de Megan antes de fragmentar y enviar audio ---
                    double px = jugador.getX();
                    double py = jugador.getY();
                    double pz = jugador.getZ();
                    double mx = px, my = py, mz = pz;
                    MeganEntity meganCercana = null;
                    double radioBusqueda = 64.0;
                    try {
                        meganCercana = jugador.level().getEntitiesOfClass(MeganEntity.class,
                            jugador.getBoundingBox().inflate(radioBusqueda))
                            .stream()
                            .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                            .orElse(null);
                        if (meganCercana != null) {
                            mx = meganCercana.getX();
                            my = meganCercana.getY();
                            mz = meganCercana.getZ();
                        }
                    } catch (Exception ex) {
                        // Si hay error, fallback a la posición del jugador
                    }

                    // --- Fragmentar y enviar audio ---
                    if (audioWav != null && audioWav.length > 0) {
                        final int MAX_FRAGMENT_SIZE = 1046528; // 2KB menos de 1MB (deja margen para el overhead)
                        int totalFragments = (audioWav.length + MAX_FRAGMENT_SIZE - 1) / MAX_FRAGMENT_SIZE;
                        int streamId = (int) (System.currentTimeMillis() & 0x7FFFFFFF); // Simple streamId único
                        for (int i = 0; i < totalFragments; i++) {
                            int start = i * MAX_FRAGMENT_SIZE;
                            int end = Math.min(audioWav.length, (i + 1) * MAX_FRAGMENT_SIZE);
                            byte[] fragment = java.util.Arrays.copyOfRange(audioWav, start, end);
                            if (fragment.length > MAX_FRAGMENT_SIZE) {
                                LOGGER.error("[FRAGMENTACIÓN][ERROR] El fragmento {} excede el tamaño máximo: {} bytes", i, fragment.length);
                                throw new IllegalArgumentException("Fragmento demasiado grande: " + fragment.length);
                            }
                            LOGGER.info("[FRAGMENTACIÓN] Enviando fragmento {} de {} (tamaño: {} bytes)", i + 1, totalFragments, fragment.length);
                            final double fmx = mx;
                            final double fmy = my;
                            final double fmz = mz;
                            final ServerPlayer fJugador = jugador;
                            AudioFragmentMessage msg = new AudioFragmentMessage(streamId, i, totalFragments, fragment, fmx, fmy, fmz);
                            NetworkHandler.CHANNEL.send(
                                PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(fmx, fmy, fmz, 32, fJugador.level().dimension())),
                                msg
                            ); // Ahora se envía el fragmento a todos los jugadores cercanos a Megan
                        }
                        LOGGER.info("[DEPURACIÓN] Audio fragmentado y enviado en {} fragmentos (streamId={})", totalFragments, streamId);
                    }
                    // Debug info (opcional)
                    System.out.println("[MEGAN][DEBUG] Posición jugador: x=" + px + " y=" + py + " z=" + pz);
                    if (meganCercana != null) {
                        System.out.println("[MEGAN][DEBUG] ¡Megan encontrada! Posición Megan: x=" + mx + " y=" + my + " z=" + mz);
                    } else {
                        System.out.println("[MEGAN][DEBUG] Megan NO encontrada cerca. Usando posición del jugador.");
                    }
                    // Si tienes un sistema de red adicional, puedes dejar el siguiente bloque, si no, elimínalo para evitar duplicados.
                    // ModNetwork.INSTANCE.send(
                    //     net.minecraftforge.network.PacketDistributor.PLAYER.with(() -> jugador),
                    //     new PlayAudioPacket(audioWav, mx, my, mz)
                    // );
                    // System.out.println("[MEGAN][DEBUG] Audio WAV enviado al cliente.");
                } catch (Exception ex) {
                    LOGGER.error("[ERROR] Falló la conversión de MP3 a WAV: {}", ex.getMessage(), ex);
                    jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("[Megan] Error al convertir voz a WAV."));
                    return;
                }

                // 3. Buscar la MeganEntity más cercana y reproducir el audio OPUS usando Simple Voice Chat
                try {
                    double radioBusqueda = 64.0; // Radio de búsqueda para encontrar a Megan
                    MeganEntity megan = jugador.level().getEntitiesOfClass(MeganEntity.class,
                        jugador.getBoundingBox().inflate(radioBusqueda))
                        .stream()
                        .min(java.util.Comparator.comparingDouble(e -> e.distanceTo(jugador)))
                        .orElse(null);

                    if (megan != null) {
                        double x = megan.getX();
                        double y = megan.getY();
                        double z = megan.getZ();
                        java.util.UUID uuid = megan.getUUID();
                        MeganVoiceSender.enviarAudioNPC(uuid, x, y, z, audioWav);
                    } else {
                        jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("[Megan] No se encontró a Megan cerca."));
                        LOGGER.warn("[DEPURACIÓN] No se encontró a Megan cerca del jugador para reproducir la voz.");
                        return;
                    }
                } catch (Exception ex) {
                    LOGGER.error("[ERROR] Falló la reproducción del audio OPUS: {}", ex.getMessage(), ex);
                    jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("[Megan] Error al reproducir voz posicional."));
                }

                // 3. Mostrar el mensaje de Megan en el chat
                jugador.getServer().getPlayerList().broadcastSystemMessage(
                    net.minecraft.network.chat.Component.literal("Megan: " + respuesta), false
                );
            } catch (Exception e) {
                LOGGER.error("Error al procesar mensaje de chat: {}", mensajeJugador, e);
            } finally {
                jugadoresRespondiendo.remove(nombreJugador);
            }
        }).start();
    }
}