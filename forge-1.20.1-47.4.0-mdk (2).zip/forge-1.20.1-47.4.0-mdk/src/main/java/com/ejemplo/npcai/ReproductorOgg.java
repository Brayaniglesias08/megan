package com.ejemplo.npcai;

import javax.sound.sampled.*;
import java.io.File;

public class ReproductorOgg {

    public static void reproducir(File archivoOgg) {
        try (AudioInputStream ais = AudioSystem.getAudioInputStream(archivoOgg)) {
            Clip clip = AudioSystem.getClip();
            clip.open(ais);
            clip.start();
            while (!clip.isRunning())
                Thread.sleep(10);
            while (clip.isRunning())
                Thread.sleep(10);
            clip.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
