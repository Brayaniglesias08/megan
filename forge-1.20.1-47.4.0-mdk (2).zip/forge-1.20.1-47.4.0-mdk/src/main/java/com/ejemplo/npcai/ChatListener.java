package com.ejemplo.npcai;

/**
 * ChatListener: Escucha mensajes del chat para comandos naturales y control de Megan.
 * Arquitectura lista para integración de procesamiento de lenguaje natural.
 */
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "megan")
public class ChatListener {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChatListener.class);

    /**
     * Escucha los mensajes del chat y busca a Megan cerca del jugador.
     * Plantilla mínima para futuras expansiones.
     */
    @SubscribeEvent
    public static void onChatMessage(ServerChatEvent event) {
        String mensaje = event.getMessage().getString();
        ServerPlayer jugador = event.getPlayer();
        LOGGER.info("[DEBUG] Mensaje recibido en chat: {}", mensaje);
        MeganEntity megan = buscarMegan(jugador);

        if (megan == null) {
            LOGGER.info("[DEBUG] No se encontró a Megan cerca del jugador {}", jugador.getName().getString());
            return;
        } else {
            LOGGER.info("[DEBUG] Megan encontrada cerca del jugador {}");
        }

        // Control por chat para Megan
        // --- [MEJORADO] Activación robusta de comandos por chat ---
        // [NO TOCAR] Si esta función es validada, no modificar sin autorización del usuario.
        String msgNorm = normalizarMensaje(mensaje);
        if (esComandoSeguir(msgNorm)) {
            megan.setObjetivoJugador(jugador);
            jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Voy contigo!"));
            LOGGER.info("[MEGAN][CHAT] Megan ahora sigue a {}", jugador.getName().getString());
        } else if (esComandoDetener(msgNorm)) {
            megan.setObjetivoJugador(null);
            jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Me detengo aquí!"));
            LOGGER.info("[MEGAN][CHAT] Megan deja de seguir a {}", jugador.getName().getString());
        }

    }

    // --- Plantilla limpia: toda la lógica avanzada ha sido eliminada temporalmente ---
    // Puedes reintroducir las funciones de memoria, emociones y tareas aquí más adelante.

    // [NO TOCAR] Métodos validados por el usuario:
    /**
     * Busca la entidad Megan en el mundo del jugador.
     */
    private static MeganEntity buscarMegan(ServerPlayer jugador) {
        return jugador.level().getEntitiesOfClass(MeganEntity.class, jugador.getBoundingBox().inflate(128)).stream().findFirst().orElse(null);
    }

    // --- Normalización y detección de comandos robusta ---
    private static String normalizarMensaje(String mensaje) {
        // Quita tildes, pasa a minúsculas, elimina signos de puntuación
        String norm = java.text.Normalizer.normalize(mensaje, java.text.Normalizer.Form.NFD)
            .replaceAll("[\\p{InCombiningDiacriticalMarks}]", "")
            .toLowerCase()
            .replaceAll("[!¡¿?.,;:]", " ")
            .replaceAll("\\s+", " ")
            .trim();
        return norm;
    }
    private static boolean esComandoSeguir(String msgNorm) {
        // Permite frases como: "megan ven", "megan vamos", "megan sigueme", "megan sígueme", etc.
        return msgNorm.matches(".*megan (ven|vamos|sigueme|sígueme|acercate|acércate|acompáñame|acompaniame|follow).*" );
    }
    private static boolean esComandoDetener(String msgNorm) {
        // Permite frases como: "adios megan", "adiós megan", "chao megan", "megan stop", etc.
        return msgNorm.matches(".*(adios|adiós|chao|stop|quieta|detente|espera) megan.*") || msgNorm.matches(".*megan (stop|quieta|detente|espera).*" );
    }
}