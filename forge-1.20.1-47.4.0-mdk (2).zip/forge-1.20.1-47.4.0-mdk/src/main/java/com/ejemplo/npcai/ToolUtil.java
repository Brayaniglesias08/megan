package com.ejemplo.npcai;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantment;
import java.util.Map;

public class ToolUtil {
    public static boolean isSword(ItemStack stack) {
        return stack.getItem().getDescriptionId().contains("sword");
    }
    public static boolean isPickaxe(ItemStack stack) {
        return stack.getItem().getDescriptionId().contains("pickaxe") || stack.getDisplayName().getString().toLowerCase().contains("pico");
    }
    public static boolean isAxe(ItemStack stack) {
        return stack.getItem().getDescriptionId().contains("axe") && !isPickaxe(stack);
    }
    public static boolean isShovel(ItemStack stack) {
        return stack.getItem().getDescriptionId().contains("shovel") || stack.getDisplayName().getString().toLowerCase().contains("pala");
    }
    public static boolean isTool(ItemStack stack) {
        return isSword(stack) || isPickaxe(stack) || isAxe(stack) || isShovel(stack);
    }
    // ARMADURAS
    public static boolean isHelmet(ItemStack stack) {
        return stack.getItem().getDescriptionId().contains("helmet") || stack.getDisplayName().getString().toLowerCase().contains("casco");
    }
    public static boolean isChestplate(ItemStack stack) {
        return stack.getItem().getDescriptionId().contains("chestplate") || stack.getDisplayName().getString().toLowerCase().contains("pechera");
    }
    public static boolean isLeggings(ItemStack stack) {
        return stack.getItem().getDescriptionId().contains("leggings") || stack.getDisplayName().getString().toLowerCase().contains("pantal");
    }
    public static boolean isBoots(ItemStack stack) {
        return stack.getItem().getDescriptionId().contains("boots") || stack.getDisplayName().getString().toLowerCase().contains("bota");
    }
    public static boolean isArmor(ItemStack stack) {
        return isHelmet(stack) || isChestplate(stack) || isLeggings(stack) || isBoots(stack);
    }
    // COMPARADOR DE HERRAMIENTAS: mejor encantamiento y menor daño
    public static int getEnchantmentLevel(ItemStack stack, String enchName) {
        Map<Enchantment, Integer> enchants = EnchantmentHelper.getEnchantments(stack);
        int best = 0;
        for (Map.Entry<Enchantment, Integer> entry : enchants.entrySet()) {
            String id = entry.getKey().getDescriptionId().toLowerCase();
            if (id.contains(enchName.toLowerCase())) {
                if (entry.getValue() > best) best = entry.getValue();
            }
        }
        return best;
    }
    /**
     * Devuelve el "nivel" de la herramienta para comparar calidad.
     * Madera=1, Piedra=2, Hierro=3, Oro=4, Diamante=5, Netherite=6. Si no es herramienta conocida, devuelve 0.
     */
    public static int getToolLevel(ItemStack stack) {
        if (stack.isEmpty()) return 0;
        String name = stack.getItem().getDescriptionId().toLowerCase();
        if (name.contains("wood")) return 1;
        if (name.contains("stone")) return 2;
        if (name.contains("iron")) return 3;
        if (name.contains("gold")) return 4;
        if (name.contains("diamond")) return 5;
        if (name.contains("netherite")) return 6;
        // Para español
        String display = stack.getDisplayName().getString().toLowerCase();
        if (display.contains("madera")) return 1;
        if (display.contains("piedra")) return 2;
        if (display.contains("hierro")) return 3;
        if (display.contains("oro")) return 4;
        if (display.contains("diamante")) return 5;
        if (display.contains("netherite")) return 6;
        return 0;
    }

    public static int compareTools(ItemStack a, ItemStack b) {
        // Prioriza nivel de afilado, eficiencia, fortuna, etc.
        int sharpA = getEnchantmentLevel(a, "sharp");
        int sharpB = getEnchantmentLevel(b, "sharp");
        if (sharpA != sharpB) return Integer.compare(sharpB, sharpA);
        int effA = getEnchantmentLevel(a, "efficien");
        int effB = getEnchantmentLevel(b, "efficien");
        if (effA != effB) return Integer.compare(effB, effA);
        int fortA = getEnchantmentLevel(a, "fortun");
        int fortB = getEnchantmentLevel(b, "fortun");
        if (fortA != fortB) return Integer.compare(fortB, fortA);
        // Si mismo encantamiento, prioriza menor daño
        return Integer.compare(a.getDamageValue(), b.getDamageValue());
    }
}
