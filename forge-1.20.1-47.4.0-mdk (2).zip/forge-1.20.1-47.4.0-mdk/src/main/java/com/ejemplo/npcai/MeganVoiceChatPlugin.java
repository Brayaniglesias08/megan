// MeganVoiceChatPlugin.java
// Plugin integrado para Minecraft Forge: Audio posicional robusto
// (Basado en el pipeline probado)

package com.ejemplo.npcai;

import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraft.server.level.ServerPlayer;
import org.lwjgl.openal.AL10;
import java.util.ArrayList;
import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.SampleBuffer;
import javazoom.jl.decoder.Decoder;

@Mod.EventBusSubscriber(modid = "npcai")
public class MeganVoiceChatPlugin {
    // Llama esto cuando quieras reproducir voz posicional
    public static void playMeganVoiceAt(ServerPlayer player, String mp3Path) {
        try {
            // Decodifica MP3 a PCM mono 48000 Hz
            List<Short> pcmList = new ArrayList<>();
            int sampleRate = 48000;
            int channels = 1;
            File mp3File = new File(mp3Path);
            if (!mp3File.exists()) {
                System.err.println("No se encontró el archivo: " + mp3Path);
                return;
            }
            try (FileInputStream fis = new FileInputStream(mp3File)) {
                Bitstream bitstream = new Bitstream(fis);
                Decoder decoder = new Decoder();
                javazoom.jl.decoder.Header frameHeader;
                while ((frameHeader = bitstream.readFrame()) != null) {
                    SampleBuffer output = (SampleBuffer) decoder.decodeFrame(frameHeader, bitstream);
                    int outChannels = output.getChannelCount();
                    int outRate = output.getSampleFrequency();
                    short[] pcm = output.getBuffer();
                    // Convierte a mono si es necesario
                    if (outChannels == 2) {
                        for (int i = 0; i < pcm.length; i += 2) {
                            short mono = (short)(((int)pcm[i] + (int)pcm[i+1]) / 2);
                            pcmList.add(mono);
                        }
                    } else {
                        for (short s : pcm) {
                            pcmList.add(s);
                        }
                    }
                    bitstream.closeFrame();
                    if (outRate != 48000) {
                        System.err.println("Advertencia: el MP3 tiene sample rate " + outRate + ". Se recomienda 48000 Hz para máxima calidad.");
                    }
                }
            }
            short[] pcmData = new short[pcmList.size()];
            for (int i = 0; i < pcmList.size(); i++) {
                pcmData[i] = pcmList.get(i);
            }
            System.out.println("[MeganVoiceChatPlugin] PCM extraído del MP3. Samples: " + pcmData.length);
            // Posición del jugador
            double x = player.getX();
            double y = player.getY();
            double z = player.getZ();
            // Streaming robusto
            int chunkMs = 200;
            int bufferCount = 8;
            System.out.println("[MeganVoiceChatPlugin] Iniciando reproducción streaming con chunkMs=" + chunkMs + ", buffers=" + bufferCount);
            OpenALStreamingPlayer.playPCMStreamedWithDebug(
                pcmData, 48000, 1, (float)x, (float)y, (float)z, chunkMs, bufferCount
            );
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    // Ejemplo de integración: reproduce voz de Megan cuando el jugador entra
    @SubscribeEvent
    public static void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        ServerPlayer player = (ServerPlayer) event.getEntity();
        // Cambia la ruta al archivo MP3 correcto
        playMeganVoiceAt(player, "audio-elevenlabs.mp3");
    }
}
