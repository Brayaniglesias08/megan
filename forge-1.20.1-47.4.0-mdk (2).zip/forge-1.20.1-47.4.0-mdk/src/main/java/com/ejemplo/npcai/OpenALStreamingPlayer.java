package com.ejemplo.npcai;

import org.lwjgl.openal.AL;
import org.lwjgl.openal.ALC;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.ALC10;
import org.lwjgl.system.MemoryUtil;

import java.nio.ShortBuffer;
import java.nio.ByteBuffer;
import java.nio.IntBuffer;

public class OpenALStreamingPlayer {
    private static long device;
    private static long context;
    private static boolean initialized = false;

    public static void init() {
        if (initialized) return;
        device = ALC10.alcOpenDevice((ByteBuffer) null);
        if (device == MemoryUtil.NULL) throw new IllegalStateException("Failed to open the default OpenAL device.");
        context = ALC10.alcCreateContext(device, (IntBuffer) null);
        if (context == MemoryUtil.NULL) throw new IllegalStateException("Failed to create OpenAL context.");
        ALC10.alcMakeContextCurrent(context);
        AL.createCapabilities(ALC.createCapabilities(device));
        initialized = true;
    }

    /**
     * Reproduce un buffer PCM mono 48000Hz en chunks pequeños para evitar cortes.
     * @param pcmData buffer PCM (short[])
     * @param sampleRate sample rate (ej: 48000)
     * @param channels canales (1 = mono, 2 = estéreo)
     * @param x posición X
     * @param y posición Y
     * @param z posición Z
     */
    // Nueva sobrecarga: permite pasar un src externo
    public static void playPCMStreamedWithDebug(short[] pcmData, int sampleRate, int channels, float x, float y, float z, int chunkMs, int bufferCount, int source) {
        System.out.println("[MEGAN][CLIENTE][AUDIO] Reproduciendo audio PCM. sampleRate=" + sampleRate + ", canales=" + channels + ", muestras=" + pcmData.length + ", pos=(" + x + "," + y + "," + z + ")");
        init();
        int format = channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16;
        boolean ownsSource = false;
        if (source == -1) {
            source = AL10.alGenSources();
            ownsSource = true;
            AL10.alSource3f(source, AL10.AL_POSITION, x, y, z);
        }
        // Fuerza el volumen a máximo
        AL10.alSourcef(source, AL10.AL_GAIN, 1.0f);
        System.out.println("[DEBUG] Source gain: " + AL10.alGetSourcef(source, AL10.AL_GAIN));
        // Log del dispositivo/contexto
        System.out.println("[DEBUG] OpenAL Device: " + device + ", Context: " + context);
        int errInit = AL10.alGetError();
        if (errInit != AL10.AL_NO_ERROR) System.err.println("[DEBUG] OpenAL error tras init: " + errInit);
        // OPTIMIZACIÓN: chunkMs y bufferCount por defecto aumentados para robustez
        chunkMs = chunkMs < 80 ? 100 : chunkMs;
        bufferCount = bufferCount < 10 ? 12 : bufferCount;
        int samplesPerChunk = (sampleRate * chunkMs) / 1000 * channels;
        final int finalBufferCount = bufferCount;
        final int finalTotalChunks = (int) Math.ceil((double) pcmData.length / samplesPerChunk);
        int[] buffers = new int[finalBufferCount];
        AL10.alGenBuffers(buffers);
        final int src = source;
        final boolean owns = ownsSource;
        Thread streamer = new Thread(() -> {
            int chunkIdx = 0;
            int bufferIdx = 0;
            int processed = 0;
            // Pre-carga TODOS los buffers posibles antes de iniciar la reproducción
            for (int i = 0; i < finalBufferCount && chunkIdx < finalTotalChunks; i++, chunkIdx++) {
                int start = chunkIdx * samplesPerChunk;
                int end = Math.min(start + samplesPerChunk, pcmData.length);
                ShortBuffer chunkBuffer = MemoryUtil.memAllocShort(end - start);
                chunkBuffer.put(pcmData, start, end - start).flip();
                AL10.alBufferData(buffers[i], format, chunkBuffer, sampleRate);
                MemoryUtil.memFree(chunkBuffer);
                System.out.println("[LOG] Pre-cargando chunk " + chunkIdx + "/" + finalTotalChunks);
            }
            System.out.println("[LOG] Precarga completa. Iniciando reproducción...");
            AL10.alSourceQueueBuffers(src, buffers);
            AL10.alSourcePlay(src);

            int underrunCount = 0;
            while (chunkIdx < finalTotalChunks) {
                int processedBuffers = AL10.alGetSourcei(src, AL10.AL_BUFFERS_PROCESSED);
                if (processedBuffers == 0) {
                    underrunCount++;
                    if (underrunCount == 1 || underrunCount % 1000 == 0) {
                        System.err.println("[UNDERUN] OpenAL se quedó sin buffers en tiempo real (x" + underrunCount + ")");
                    }
                }
                while (processedBuffers-- > 0) {
                    int unqueued = AL10.alSourceUnqueueBuffers(src);
                    int start = chunkIdx * samplesPerChunk;
                    int end = Math.min(start + samplesPerChunk, pcmData.length);
                    ShortBuffer chunkBuffer = MemoryUtil.memAllocShort(end - start);
                    chunkBuffer.put(pcmData, start, end - start).flip();
                    AL10.alBufferData(unqueued, format, chunkBuffer, sampleRate);
                    AL10.alSourceQueueBuffers(src, new int[]{unqueued});
                    MemoryUtil.memFree(chunkBuffer);
                    System.out.println("Procesando chunk " + chunkIdx + "/" + finalTotalChunks);
                    chunkIdx++;
                }
                try { Thread.sleep(5); } catch (InterruptedException ignored) {}
                Thread.yield(); // Prueba máxima reactividad del hilo
            }
            // Espera a que termine la reproducción
            while (AL10.alGetSourcei(src, AL10.AL_SOURCE_STATE) == AL10.AL_PLAYING) {
                try { Thread.sleep(10); } catch (InterruptedException ignored) {}
            }
            if (owns) {
                AL10.alDeleteSources(src);
            }
            AL10.alDeleteBuffers(buffers);
        });
        streamer.start();
        try { streamer.join(); } catch (InterruptedException ignored) {}
    }

    // Mantén la versión anterior para compatibilidad
    public static void playPCMStreamedWithDebug(short[] pcmData, int sampleRate, int channels, float x, float y, float z, int chunkMs, int bufferCount) {
        init();
        int format = channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16;
        int src = AL10.alGenSources();
        AL10.alSource3f(src, AL10.AL_POSITION, x, y, z);

        // OPTIMIZACIÓN: chunkMs y bufferCount por defecto aumentados para robustez
        chunkMs = chunkMs < 80 ? 100 : chunkMs;
        bufferCount = bufferCount < 10 ? 12 : bufferCount;
        int samplesPerChunk = (sampleRate * chunkMs) / 1000 * channels;
        final int finalBufferCount = bufferCount;
        final int finalTotalChunks = (int) Math.ceil((double) pcmData.length / samplesPerChunk);
        int[] buffers = new int[finalBufferCount];
        AL10.alGenBuffers(buffers);

        Thread streamer = new Thread(() -> {
            int chunkIdx = 0;
            int bufferIdx = 0;
            int processed = 0;
            // Pre-carga TODOS los buffers posibles antes de iniciar la reproducción
            for (int i = 0; i < finalBufferCount && chunkIdx < finalTotalChunks; i++, chunkIdx++) {
                int start = chunkIdx * samplesPerChunk;
                int end = Math.min(start + samplesPerChunk, pcmData.length);
                ShortBuffer chunkBuffer = MemoryUtil.memAllocShort(end - start);
                chunkBuffer.put(pcmData, start, end - start).flip();
                AL10.alBufferData(buffers[i], format, chunkBuffer, sampleRate);
                MemoryUtil.memFree(chunkBuffer);
                System.out.println("[LOG] Pre-cargando chunk " + chunkIdx + "/" + finalTotalChunks);
            }
            System.out.println("[LOG] Precarga completa. Iniciando reproducción...");
            AL10.alSourceQueueBuffers(src, buffers);
            AL10.alSourcePlay(src);

            int underrunCount = 0;
            while (chunkIdx < finalTotalChunks) {
                int processedBuffers = AL10.alGetSourcei(src, AL10.AL_BUFFERS_PROCESSED);
                if (processedBuffers == 0) {
                    underrunCount++;
                    if (underrunCount == 1 || underrunCount % 1000 == 0) {
                        System.err.println("[UNDERUN] OpenAL se quedó sin buffers en tiempo real (x" + underrunCount + ")");
                    }
                }
                while (processedBuffers-- > 0) {
                    int unqueued = AL10.alSourceUnqueueBuffers(src);
                    int start = chunkIdx * samplesPerChunk;
                    int end = Math.min(start + samplesPerChunk, pcmData.length);
                    ShortBuffer chunkBuffer = MemoryUtil.memAllocShort(end - start);
                    chunkBuffer.put(pcmData, start, end - start).flip();
                    AL10.alBufferData(unqueued, format, chunkBuffer, sampleRate);
                    AL10.alSourceQueueBuffers(src, new int[]{unqueued});
                    MemoryUtil.memFree(chunkBuffer);
                    System.out.println("Procesando chunk " + chunkIdx + "/" + finalTotalChunks);
                    chunkIdx++;
                }
                try { Thread.sleep(5); } catch (InterruptedException ignored) {}
                Thread.yield(); // Prueba máxima reactividad del hilo
            }
            // Espera a que termine la reproducción
            while (AL10.alGetSourcei(src, AL10.AL_SOURCE_STATE) == AL10.AL_PLAYING) {
                try { Thread.sleep(10); } catch (InterruptedException ignored) {}
            }
            AL10.alDeleteSources(src);
            AL10.alDeleteBuffers(buffers);
        });
        // Comentario: Puedes ajustar bufferCount hasta 12 para máxima robustez si tu sistema lo soporta.
        // Ejemplo: int bufferCount = 12; en tu test principal.

        streamer.start();
    }

    public static void cleanup() {
        if (!initialized) return;
        ALC10.alcDestroyContext(context);
        ALC10.alcCloseDevice(device);
        initialized = false;
    }
}
