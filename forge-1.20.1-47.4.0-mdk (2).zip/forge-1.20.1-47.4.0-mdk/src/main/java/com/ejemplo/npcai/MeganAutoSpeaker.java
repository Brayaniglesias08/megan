package com.ejemplo.npcai;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.LivingEntity;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import java.util.*;

/**
 * Hace que Megan hable sola cada 2 minutos a jugadores cercanos.
 */
@Mod.EventBusSubscriber
public class MeganAutoSpeaker {
    private static final long INTERVALO_MS = 2 * 60 * 1000; // 2 minutos
    private static long lastSpeakTime = 0;
    private static final Random random = new Random();

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        long now = System.currentTimeMillis();
        if (now - lastSpeakTime < INTERVALO_MS) return;
        lastSpeakTime = now;
        // Buscar todas las Megans activas
        for (ServerLevel level : net.minecraftforge.server.ServerLifecycleHooks.getCurrentServer().getAllLevels()) {
            List<Entity> megans = new ArrayList<>();
            for (Entity e : level.getEntities().getAll()) {
                if (e instanceof com.ejemplo.npcai.MeganEntity) {
                    megans.add(e);
                }
            }
            for (Entity megan : megans) {
                // Buscar jugadores cercanos (radio 16 bloques)
                List<Player> cercanos = level.getEntitiesOfClass(Player.class, megan.getBoundingBox().inflate(16));
                if (cercanos.isEmpty()) continue;
                Player elegido = cercanos.get(random.nextInt(cercanos.size()));
                // Construir contexto y memoria
                UUID uuidJugador = elegido.getUUID();
                String nombreJugador = elegido.getName().getString();
                String contexto = (level.isDay() ? "Es de día" : "Es de noche") + (level.isRaining() ? ", y está lloviendo" : ", y no llueve") + ". El jugador tiene " + (int)((LivingEntity)elegido).getHealth() + " corazones de vida.";
                List<String> memoriaJugador = MeganMemoryManager.cargarMemoriaJugador(uuidJugador);
                List<String> memoriaPermaJugador = MeganMemoryManager.cargarMemoriaPermaJugador(uuidJugador);
                List<String> memoriaGeneral = MeganMemoryManager.cargarMemoriaGeneral();
                List<String> memoriaPermaGeneral = MeganMemoryManager.cargarMemoriaPermaGeneral();
                StringBuilder historial = new StringBuilder();
                if (!memoriaPermaJugador.isEmpty()) historial.append("Recuerdos importantes contigo: ").append(memoriaPermaJugador).append(". ");
                if (!memoriaJugador.isEmpty()) historial.append("Historial reciente contigo: ").append(memoriaJugador).append(". ");
                if (!memoriaPermaGeneral.isEmpty()) historial.append("Recuerdos importantes del servidor: ").append(memoriaPermaGeneral).append(". ");
                if (!memoriaGeneral.isEmpty()) historial.append("Historial reciente del servidor: ").append(memoriaGeneral).append(". ");
                String promptFinal = historial.toString() + " Inicia una conversación espontánea con el jugador, puedes comentar algo divertido, útil, preguntar cómo está, o recordar algo relevante.";
                try {
                    String respuesta = ChatGPTIntegration.obtenerRespuestaDeChatGPT(
                        MeganConversationManager.obtenerHistorial(uuidJugador),
                        nombreJugador,
                        contexto
                    );
                    // Aquí deberías llamar al pipeline de voz para que Megan hable (puedes reutilizar el código de ChatEventHandler)
                    // Por ejemplo:
                    // MeganVoiceSender.enviarAudioNPC(megan.getUUID(), megan.getX(), megan.getY(), megan.getZ(), respuesta);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            }
        }
    }
}
