package com.ejemplo.npcai;

import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.ItemInHandLayer;
import net.minecraft.resources.ResourceLocation;

public class MeganRenderer extends MobRenderer<MeganEntity, PlayerModel<MeganEntity>> {
    public MeganRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
        this.addLayer(new ItemInHandLayer<>(this, context.getItemInHandRenderer()));
    }
    @Override
    public ResourceLocation getTextureLocation(MeganEntity entity) {
        return new ResourceLocation("npcai:textures/entity/megan.png");
    }
}
