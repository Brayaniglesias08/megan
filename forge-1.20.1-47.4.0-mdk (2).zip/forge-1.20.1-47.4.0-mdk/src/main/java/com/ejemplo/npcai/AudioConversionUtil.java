package com.ejemplo.npcai;

import java.io.File;
import java.io.IOException;

/**
 * Utilidad para convertir archivos de audio (MP3, WAV) a OGG usando ffmpeg.
 * Requiere que ffmpeg esté instalado y accesible desde el PATH del sistema.
 */
public class AudioConversionUtil {
    /**
     * Convierte un archivo de audio (MP3/WAV) a OGG usando ffmpeg.
     * @param input Archivo de entrada (MP3 o WAV)
     * @param output Archivo de salida (OGG)
     * @throws IOException Si ocurre un error al ejecutar ffmpeg
     * @throws InterruptedException Si el proceso es interrumpido
     */
    public static void convertToOgg(File input, File output) throws IOException, InterruptedException {
        ProcessBuilder pb = new ProcessBuilder(
            "ffmpeg", "-y", "-i", input.getAbsolutePath(), output.getAbsolutePath()
        );
        pb.redirectErrorStream(true);
        Process process = pb.start();
        int exitCode = process.waitFor();
        if (exitCode != 0) {
            throw new IOException("Error converting audio to OGG, exit code: " + exitCode);
        }
    }
}
