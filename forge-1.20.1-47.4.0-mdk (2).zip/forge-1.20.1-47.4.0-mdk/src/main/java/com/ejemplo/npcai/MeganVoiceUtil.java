package com.ejemplo.npcai;

import net.minecraft.client.Minecraft;
import java.io.File;

/**
 * Utilidad para reproducir audio TTS de Megan de forma rápida y posicional.
 * Llama a este método desde el hilo donde recibes el audio TTS generado.
 * Documentado en español.
 */
public class MeganVoiceUtil {
    /**
     * Reproduce el audio WAV de Megan en la posición actual del NPC usando la API de sonidos de Minecraft.
     * @param wavFile Archivo temporal WAV con el audio TTS
     * @param megan   Instancia de MeganEntity
     */
    public static void reproducirVozMegan(File wavFile, MeganEntity megan) {
        MeganVoiceSound sound = new MeganVoiceSound(wavFile, megan);
        Minecraft.getInstance().getSoundManager().play(sound);
    }

    /**
     * Guarda un array de bytes WAV como archivo temporal en disco.
     * @param wavBytes Array de bytes con el audio WAV
     * @return Archivo temporal listo para reproducir
     */
    public static File guardarWavTemporal(byte[] wavBytes) throws java.io.IOException {
        File tempFile = File.createTempFile("megan_voice_", ".wav");
        try (java.io.FileOutputStream fos = new java.io.FileOutputStream(tempFile)) {
            fos.write(wavBytes);
        }
        tempFile.deleteOnExit();
        return tempFile;
    }
}
