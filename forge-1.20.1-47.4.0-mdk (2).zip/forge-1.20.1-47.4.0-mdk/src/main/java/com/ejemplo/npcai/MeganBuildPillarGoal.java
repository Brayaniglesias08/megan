package com.ejemplo.npcai;

import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;

import java.util.EnumSet;

/**
 * Goal para que Megan construya un pilar debajo suyo (pillar jump)
 * cuando no puede alcanzar un objetivo por diferencia de altura.
 * Prioriza usar tierra, luego piedra, luego madera.
 */
public class MeganBuildPillarGoal extends Goal {
    private final PathfinderMob megan;
    private final BlockPos targetPos;
    private int buildTicks = 0;
    private static final int MAX_HEIGHT_DIFF = 2; // Si el objetivo está a más de 1 bloque de altura

    public MeganBuildPillarGoal(PathfinderMob megan, BlockPos targetPos) {
        this.megan = megan;
        this.targetPos = targetPos;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        // Solo usar si el objetivo está arriba y Megan no puede saltar normalmente
        if (megan == null || targetPos == null) return false;
        if (targetPos.getY() - megan.blockPosition().getY() < MAX_HEIGHT_DIFF) return false;
        // Solo si hay espacio para colocar bloque debajo
        BlockPos below = megan.blockPosition().below();
        Level level = megan.level();
        return level.isEmptyBlock(below);
    }

    @Override
    public void start() {
        buildTicks = 0;
    }

    @Override
    public void tick() {
        if (buildTicks > 0) {
            buildTicks--;
            return;
        }
        // Seleccionar bloque para colocar
        int slot = getBestBlockSlot();
        if (slot == -1) return; // No hay bloques disponibles
        ItemStack stack = ((MeganEntity)megan).getInventory().getItem(slot);
        Block block = Block.byItem(stack.getItem());
        BlockPos below = megan.blockPosition().below();
        Level level = megan.level();
        if (level.isEmptyBlock(below)) {
            level.setBlock(below, block.defaultBlockState(), 3);
            stack.shrink(1);
            buildTicks = 10; // Espera antes de intentar colocar otro
            // Saltar para subir al bloque
            // Simular salto usando setDeltaMovement
            megan.setDeltaMovement(megan.getDeltaMovement().x, 0.42D, megan.getDeltaMovement().z);
            megan.hasImpulse = true;
        }
    }

    private int getBestBlockSlot() {
        MeganEntity entity = (MeganEntity)megan;
        // Prioridad: tierra > piedra > madera
        int tierraSlot = -1, piedraSlot = -1, maderaSlot = -1;
        for (int i = 0; i < entity.getInventory().getContainerSize(); i++) {
            ItemStack stack = entity.getInventory().getItem(i);
            if (stack.isEmpty()) continue;
            Block block = Block.byItem(stack.getItem());
            if (block == Blocks.DIRT || block == Blocks.GRASS_BLOCK) {
                if (tierraSlot == -1) tierraSlot = i;
            } else if (block == Blocks.STONE) {
                if (piedraSlot == -1) piedraSlot = i;
            } else if (block == Blocks.OAK_LOG || block == Blocks.BIRCH_LOG || block == Blocks.SPRUCE_LOG || block == Blocks.JUNGLE_LOG || block == Blocks.ACACIA_LOG || block == Blocks.DARK_OAK_LOG) {
                if (maderaSlot == -1) maderaSlot = i;
            }
        }
        if (tierraSlot != -1) return tierraSlot;
        if (piedraSlot != -1) return piedraSlot;
        if (maderaSlot != -1) return maderaSlot;
        return -1;
    }

    @Override
    public boolean canContinueToUse() {
        // Termina si ya está a la altura del objetivo o no hay más bloques
        return megan.blockPosition().getY() < targetPos.getY() && getBestBlockSlot() != -1;
    }

    @Override
    public void stop() {
        buildTicks = 0;
    }
}
