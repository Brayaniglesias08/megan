package com.ejemplo.npcai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import com.ejemplo.npcai.MeganEntity;
import java.util.Objects;

/**
 * Patrón de minería tipo pozo (PIT) configurable (ancho x largo x profundidad)
 * Recorre el área en "layers" de arriba a abajo, y dentro de cada layer recorre filas y columnas.
 */
public class MeganPitPattern implements MeganMiningPattern {
    private final BlockPos startPos;
    private final int width;
    private final int length;
    private final int depth;
    private int currentY;
    private int currentX;
    private int currentZ;
    private boolean finished;

    /**
     * Crea un patrón de pozo en la posición dada, con dimensiones configurables.
     * @param startPos esquina superior-noroeste (mínimos X y Z, Y inicial)
     * @param width ancho del pozo (en X)
     * @param length largo del pozo (en Z)
     * @param depth profundidad del pozo (en Y, hacia abajo)
     */
    public MeganPitPattern(BlockPos startPos, int width, int length, int depth) {
        this.startPos = startPos;
        this.width = width;
        this.length = length;
        this.depth = depth;
        this.currentY = 0; // offset desde Y inicial
        this.currentX = 0;
        this.currentZ = 0;
        this.finished = false;
    }

    @Override
    public BlockPos getNextBlockToMine(MeganEntity entity, Level level) {
        if (finished) return null;
        int baseY = startPos.getY();
        while (currentY < depth) {
            while (currentX < width) {
                while (currentZ < length) {
                    BlockPos pos = new BlockPos(
                        startPos.getX() + currentX,
                        baseY - currentY,
                        startPos.getZ() + currentZ
                    );
                    currentZ++;
                    // Solo minar si no es aire
                    if (!level.getBlockState(pos).isAir()) {
                        return pos;
                    }
                }
                currentZ = 0;
                currentX++;
            }
            currentX = 0;
            currentY++;
        }
        finished = true;
        return null;
    }

    @Override
    public void reset(BlockPos startPos, net.minecraft.core.Direction direction) {
        this.currentY = 0;
        this.currentX = 0;
        this.currentZ = 0;
        this.finished = false;
        // Si necesitas actualizar startPos, quita el final del campo y descomenta:
        // this.startPos = startPos;
    }
}
