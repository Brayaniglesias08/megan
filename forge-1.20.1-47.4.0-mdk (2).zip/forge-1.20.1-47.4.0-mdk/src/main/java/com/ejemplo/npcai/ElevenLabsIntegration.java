package com.ejemplo.npcai;

// Clase obsoleta. No utilizar. Archivo vacío para evitar errores de compilación.