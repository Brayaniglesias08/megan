package com.ejemplo.npcai;

import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.AbstractTickableSoundInstance;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraft.client.resources.sounds.SoundInstance;

import java.io.File;

/**
 * Sonido posicional personalizado para reproducir audio TTS de Megan.
 * El audio se reproduce en la posición de Megan y se actualiza cada tick.
 * Documentado en español.
 */
public class MeganVoiceSound extends AbstractTickableSoundInstance {
    private final File wavFile; // Archivo temporal WAV con el audio TTS
    private final MeganEntity megan; // Referencia a Megan para actualizar posición
    private boolean stopped = false;

    public MeganVoiceSound(File wavFile, MeganEntity megan) {
        super(net.minecraft.sounds.SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, SoundInstance.createUnseededRandom());
        this.wavFile = wavFile;
        this.megan = megan;
        this.x = megan.getX();
        this.y = megan.getY();
        this.z = megan.getZ();
        this.looping = false;
        this.delay = 0;
        this.volume = 1.0f;
        this.attenuation = Attenuation.LINEAR;
    }

    @Override
    public void tick() {
        // Actualiza la posición cada tick
        this.x = megan.getX();
        this.y = megan.getY();
        this.z = megan.getZ();
        // Si Megan desaparece o el audio termina, detén el sonido
        if (megan.isRemoved() || stopped) {
            this.stop();
        }
    }

    @Override
    public boolean canStartSilent() {
        return false;
    }

    @Override
    public boolean isStopped() {
        return stopped;
    }



    // Aquí puedes agregar métodos para controlar el volumen, paneo, etc. si lo deseas
}
