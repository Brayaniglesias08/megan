package com.ejemplo.npcai;

import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.server.level.ServerPlayer;
import com.ejemplo.npcai.net.OpusUtils;
import com.ejemplo.npcai.net.MeganAudioPacket;
import java.util.Arrays;

@Mod.EventBusSubscriber
// ============================
// ¡NO MODIFICAR!
// Lógica crítica de seguimiento de Megan.
// Si necesitas cambiar el comportamiento, consulta primero con Brayan.
// DO NOT MODIFY!
// Critical logic for Megan's following behavior.
// If you need to change this, consult Brayan first.
// ============================
public class MeganChatListener {
    private static final org.slf4j.Logger logger = org.slf4j.LoggerFactory.getLogger("MeganAI");
    private static int streamIdCounter = 0;

    // --- Métodos auxiliares para obtener la posición de Megan ---
    public static double getMeganX(ServerPlayer player) {
        return getMeganPos(player, 0);
    }
    public static double getMeganY(ServerPlayer player) {
        return getMeganPos(player, 1);
    }
    public static double getMeganZ(ServerPlayer player) {
        return getMeganPos(player, 2);
    }

    // Listener de chat para comandos naturales de Megan
    @SubscribeEvent
    public static void onChat(ServerChatEvent event) {
        String msg = event.getMessage().getString().toLowerCase().trim();
        ServerPlayer player = event.getPlayer();
        // Frases para activar el seguimiento
        if (msg.equals("sigueme megan") || msg.equals("vamos megan") || msg.equals("ven megan")) {
            MeganEntity megan = getClosestMegan(player);
            if (megan != null) {
                megan.setEnModoSeguir(true);
                megan.setObjetivoJugador(player);
                player.displayClientMessage(net.minecraft.network.chat.Component.literal("§a[Megan] ¡Ahora te sigo!"), false);
                // Reproducir audio aleatorio de "ven"
                com.ejemplo.npcai.MeganCustomAudioPlayer.reproducirVenAleatorio(player, megan);
            }
            return; // No responder con ChatGPT
        }
        // Frases para desactivar el seguimiento
        if (msg.equals("para megan") || msg.equals("adios megan") || msg.equals("chao megan")) {
            MeganEntity megan = getClosestMegan(player);
            if (megan != null) {
                megan.setEnModoSeguir(false);
                megan.setObjetivoJugador(null); // Limpia el objetivo al parar
                player.displayClientMessage(net.minecraft.network.chat.Component.literal("§e[Megan] Me detengo aquí."), false);
            }
            return; // No responder con ChatGPT
        }
        // Si no es comando de acción, procesar como conversación
        try {
            java.util.UUID uuid = player.getUUID();
            com.ejemplo.npcai.MeganConversationManager.agregarMensaje(uuid, "user", msg);
            java.util.List<com.ejemplo.npcai.MeganConversationManager.MensajeTurno> historial = com.ejemplo.npcai.MeganConversationManager.obtenerHistorial(uuid);
            String respuesta = com.ejemplo.npcai.ChatGPTIntegration.obtenerRespuestaDeChatGPT(historial, player.getName().getString(), "");
            com.ejemplo.npcai.MeganConversationManager.agregarMensaje(uuid, "assistant", respuesta);
// player.displayClientMessage(net.minecraft.network.chat.Component.literal(respuesta), false);
// Aquí puedes reproducir audio si lo deseas
            // Aquí puedes reproducir audio si lo deseas
        } catch (Exception e) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal("§c[Error Megan] No se pudo contactar con la IA."), false);
            e.printStackTrace();
        }
    }

    // Utilidad: buscar la Megan más cercana al jugador
    /**
     * ============================
     * ¡NO MODIFICAR ESTE MÉTODO!
     * Lógica crítica de búsqueda de Megan para el seguimiento.
     * Si necesitas cambiarlo, documenta el motivo y consulta primero con Brayan.
     * DO NOT MODIFY THIS METHOD!
     * Critical logic for finding Megan for following behavior.
     * If you must change it, document the reason and consult Brayan first.
     * ============================
     */
    private static final MeganEntity getClosestMegan(ServerPlayer player) {
        double px = player.getX();
        double py = player.getY();
        double pz = player.getZ();
        double minDist = Double.MAX_VALUE;
        MeganEntity closest = null;
        // Buscar en un área de 32 bloques alrededor del jugador
        net.minecraft.world.phys.AABB searchBox = new net.minecraft.world.phys.AABB(
            player.getX() - 32, player.getY() - 16, player.getZ() - 32,
            player.getX() + 32, player.getY() + 16, player.getZ() + 32
        );
        java.util.List<MeganEntity> megans = new java.util.ArrayList<>(player.level().getEntitiesOfClass(MeganEntity.class, searchBox));
        // logger.info("[MEGAN][DEBUG][getClosestMegan] Megans encontradas: {}", megans.size());
        for (MeganEntity entity : megans) {
            // logger.info("[MEGAN][DEBUG][getClosestMegan] Megan pos: x={}, y={}, z={}, id={}", entity.getX(), entity.getY(), entity.getZ(), entity.getId());
            double dx = entity.getX() - px;
            double dy = entity.getY() - py;
            double dz = entity.getZ() - pz;
            double dist = dx*dx + dy*dy + dz*dz;
            if (dist < minDist) {
                minDist = dist;
                closest = entity;
            }
        }
        if (closest != null) {
            // logger.info("[MEGAN][DEBUG][getClosestMegan] Más cercana: id={}, pos=({}, {}, {})", closest.getId(), closest.getX(), closest.getY(), closest.getZ());
        } else {
            // logger.info("[MEGAN][DEBUG][getClosestMegan] No se encontró ninguna Megan cercana");
        }
        return closest;
    }
    public static double getMeganPos(ServerPlayer player, int axis) {
        double px = player.getX();
        double py = player.getY();
        double pz = player.getZ();
        double minDist = Double.MAX_VALUE;
        double[] best = {px, py, pz};
        java.util.List<MeganEntity> megans = new java.util.ArrayList<>(player.level().getEntitiesOfClass(com.ejemplo.npcai.MeganEntity.class, player.level().getWorldBorder().getCollisionShape().bounds()));
        for (MeganEntity entity : megans) {
            double dx = entity.getX() - px;
            double dy = entity.getY() - py;
            double dz = entity.getZ() - pz;
            double dist = dx*dx + dy*dy + dz*dz;
            if (dist < minDist) {
                minDist = dist;
                best[0] = entity.getX();
                best[1] = entity.getY();
                best[2] = entity.getZ();
            }
        }
        return best[axis];
    }
}