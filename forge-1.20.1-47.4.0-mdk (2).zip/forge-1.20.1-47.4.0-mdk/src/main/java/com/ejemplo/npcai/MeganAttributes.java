package com.ejemplo.npcai;

import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

// @Mod.EventBusSubscriber(modid = "iaminecraft", bus = Mod.EventBusSubscriber.Bus.MOD)
// public class MeganAttributes {
//     @SubscribeEvent
//     public static void onEntityAttributeCreation(EntityAttributeCreationEvent event) {
//         event.put(ModEntities.MEGAN.get(), MeganEntity.createAttributes().build());
//     }
// }
