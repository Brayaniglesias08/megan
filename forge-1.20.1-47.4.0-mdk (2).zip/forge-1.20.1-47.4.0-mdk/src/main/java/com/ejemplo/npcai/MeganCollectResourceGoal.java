package com.ejemplo.npcai;

import net.minecraft.world.entity.Mob;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import java.util.*;

/**
 * MeganCollectResourceGoal - Versión completamente nueva y robusta
 * Megan recolecta recursos como un jugador humano:
 * - Busca los recursos especificados (prioriza la capa actual)
 * - Usa pathfinding natural
 * - Evita zonas peligrosas (lava, vacío)
 * - Solo recolecta si tiene espacio
 * - Recoge drops en el inventario
 * - Selecciona automáticamente la mejor herramienta del inventario
 */
public class MeganCollectResourceGoal extends Goal {
    private final Mob megan;
    private Set<Block> targetBlocks;
    private final int scanRadius;
    private BlockPos currentTarget;
    private int miningCooldown = 0;
    private final int miningTime = 20; // ticks para "romper" un bloque
    // --- Modular Mining Pattern ---
    private MeganMiningPattern miningPattern;

    /**
     * Permite cambiar el patrón de minería de forma dinámica.
     */
    public void setMiningPattern(MeganMiningPattern pattern) {
        this.miningPattern = pattern;
    }

    // Bloques por herramienta
    private static final Set<Block> SHOVEL_BLOCKS = Set.of(
            Blocks.DIRT, Blocks.GRASS_BLOCK
    );

    private static final Set<Block> PICKAXE_BLOCKS = Set.of(
            Blocks.STONE, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE,
            Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE,
            Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE,
            Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE,
            Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
            Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE,
            Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE
    );

    private static final Set<Block> AXE_BLOCKS = Set.of(
            Blocks.OAK_LOG, Blocks.SPRUCE_LOG, Blocks.BIRCH_LOG, Blocks.JUNGLE_LOG, Blocks.ACACIA_LOG, Blocks.DARK_OAK_LOG
    );

    // Stub temporal para isDangerousBlock
    private boolean isDangerousBlock(BlockState state) {
        // Implementa tu lógica real aquí si lo necesitas
        return false;
    }


    public MeganCollectResourceGoal(Mob megan, int scanRadius) {
        this.megan = megan;
        this.scanRadius = scanRadius;
        this.targetBlocks = getDefaultTargetBlocks();
        // Por defecto: túnel de 10 bloques al norte
        this.miningPattern = new MeganTunnelPattern(megan.blockPosition(), net.minecraft.core.Direction.NORTH, 10);
    }

    // Constructor compatible con el código antiguo
    public MeganCollectResourceGoal(Mob megan, Set<Block> targetBlocks, int scanRadius, java.util.function.Predicate<BlockPos> filter) {
        this.megan = megan;
        this.scanRadius = scanRadius;
        this.targetBlocks = targetBlocks;
        // El filtro no se usa aquí, pero se acepta para compatibilidad
    }

    private Set<Block> getDefaultTargetBlocks() {
        // Incluye los bloques solicitados
        return new HashSet<>(Arrays.asList(
                Blocks.DIRT, Blocks.GRASS_BLOCK, Blocks.STONE, Blocks.OAK_LOG, Blocks.SPRUCE_LOG, Blocks.BIRCH_LOG, Blocks.JUNGLE_LOG, Blocks.ACACIA_LOG, Blocks.DARK_OAK_LOG,
                Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE,
                Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE,
                Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE,
                Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE,
                Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE,
                Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE,
                Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE
        ));
    }

    @Override
    public boolean canUse() {
        // Si el objetivo principal es tierra, buscar el bloque más cercano (estilo villager worker)
        if (targetBlocks.size() == 1 && targetBlocks.contains(Blocks.DIRT)) {
            currentTarget = findNearestSoilBlock(megan.blockPosition(), scanRadius);
            return currentTarget != null && hasInventorySpace();
        }
        // Protección contra miningPattern nulo
        if (miningPattern == null) {
            miningPattern = new MeganFlatPattern(megan.blockPosition(), 3, 3, 1);
            System.out.println("[MEGAN][CollectGoal] miningPattern era null en canUse, se asignó MeganFlatPattern por defecto");
        }
        // Busca el siguiente bloque objetivo usando el patrón de minería
        if (!hasInventorySpace()) return false;
        currentTarget = miningPattern.getNextBlockToMine((MeganEntity)megan, megan.level());
        return currentTarget != null;
    }

    @Override
    public boolean canContinueToUse() {
        // Mientras tenga inventario y un objetivo válido, sigue minando
        return hasInventorySpace() && currentTarget != null;
    }

    @Override
    public void start() {
        miningCooldown = 0;
        if (currentTarget != null && megan instanceof MeganEntity) {
            BlockState state = megan.level().getBlockState(currentTarget);
            ((MeganEntity) megan).equipBestToolForBlock(state.getBlock());
        }
    }

    @Override
    public void tick() {
        // Si el objetivo principal es tierra, usar búsqueda inteligente
        if (targetBlocks.size() == 1 && targetBlocks.contains(Blocks.DIRT)) {
            if (currentTarget == null || !(megan.level().getBlockState(currentTarget).is(Blocks.DIRT) || megan.level().getBlockState(currentTarget).is(Blocks.GRASS_BLOCK))) {
                currentTarget = findNearestSoilBlock(megan.blockPosition(), scanRadius);
                if (currentTarget == null) return;
            }
            // Moverse y recolectar como siempre
            double dist = megan.blockPosition().distSqr(currentTarget);
            if (dist > 3.5) {
                megan.getNavigation().moveTo(currentTarget.getX() + 0.5, currentTarget.getY() + 1, currentTarget.getZ() + 0.5, 1.1);
            } else {
                BlockState state = megan.level().getBlockState(currentTarget);
                if (canHarvest(state.getBlock())) {
                    breakBlockAndCollect(currentTarget, state);
                    currentTarget = null; // buscar el siguiente en el próximo tick
                } else if (state.getBlock() == Blocks.GRASS || state.getBlock() == Blocks.TALL_GRASS) {
                    // Rompe la hierba o hierba alta para despejar el camino
                    megan.level().setBlock(currentTarget, Blocks.AIR.defaultBlockState(), 3);
                    System.out.println("[MEGAN][CollectGoal] Hierba/hierba alta despejada en: " + currentTarget);
                    currentTarget = null;
                }
            }
            return;
        }
        // Protección contra miningPattern nulo
        if (miningPattern == null) {
            miningPattern = new MeganFlatPattern(megan.blockPosition(), 3, 3, 1);
            System.out.println("[MEGAN][CollectGoal] miningPattern era null en tick, se asignó MeganFlatPattern por defecto");
        }
        // --- LÓGICA DE INVENTARIO LLENO Y DEPÓSITO ---
        if (((MeganEntity)megan).isInventoryFull() && !((MeganEntity)megan).isInventoryFullFlag()) {
            if (((MeganEntity)megan).getOwnerPlayer() == null && megan.level().getNearestPlayer(megan, 16) instanceof ServerPlayer owner) {
                ((MeganEntity)megan).markInventoryFull(owner);
            }
            megan.goalSelector.addGoal(1, new MeganDepositItemsGoal((MeganEntity)megan));
            return;
        }
        // --- FIN LÓGICA DEPÓSITO ---
        // --- FEEDBACK VISUAL Y EVITAR BLOQUES PELIGROSOS ---
        if (currentTarget != null) {
            var state = megan.level().getBlockState(currentTarget);
            if (isDangerousBlock(state)) {
                // Saltar bloque peligroso
                currentTarget = null;
                return;
            }
            // Feedback visual: partículas
            if (megan.level() instanceof ServerLevel serverLevel) {
    serverLevel.sendParticles(
        new net.minecraft.core.particles.BlockParticleOption(net.minecraft.core.particles.ParticleTypes.BLOCK, state),
        currentTarget.getX() + 0.5, currentTarget.getY() + 0.5, currentTarget.getZ() + 0.5,
        8, 0.3, 0.3, 0.3, 0.05
    );
}
            // Feedback visual: barra de progreso (simple)
            if (((MeganEntity)megan).getOwnerPlayer() != null) {
                ((MeganEntity)megan).sendFeedbackToOwner("[Megan] Minando: " + state.getBlock().getName().getString() + " en " + currentTarget + "...");
            }
        }
        // --- FIN FEEDBACK VISUAL ---
        if (!hasInventorySpace() || currentTarget == null) return;
        double dist = megan.blockPosition().distSqr(currentTarget);
        System.out.println("[MEGAN][DEBUG][CollectGoal] Distancia al objetivo: " + dist + " (target: " + currentTarget + ")");
        if (dist > 3.5) {
            megan.getNavigation().moveTo(currentTarget.getX() + 0.5, currentTarget.getY() + 1, currentTarget.getZ() + 0.5, 1.1);
        } else {
            Level level = megan.level();
            BlockState state = level.getBlockState(currentTarget);

            if (megan instanceof MeganEntity) {
                ((MeganEntity) megan).equipBestToolForBlock(state.getBlock());
            }

            if (targetBlocks.contains(state.getBlock()) && canHarvest(state.getBlock()) && !isDangerousToBreak(currentTarget, state)) {
                System.out.println("[MEGAN][DEBUG][CollectGoal] miningCooldown: " + miningCooldown + "/" + miningTime);
                miningCooldown++;
                if (miningCooldown % 5 == 0) {
                    System.out.println("[MEGAN][DEBUG][CollectGoal] Animación de brazo ejecutada");
                    ((net.minecraft.world.entity.LivingEntity) megan).swing(net.minecraft.world.InteractionHand.MAIN_HAND);
                }
                if (miningCooldown >= miningTime) {
                    System.out.println("[MEGAN][DEBUG][CollectGoal] ¡Bloque recolectado!: " + state.getBlock() + " en " + currentTarget);
                    breakBlockAndCollect(currentTarget, state);
                    miningCooldown = 0;
                    // Obtén el siguiente bloque objetivo usando el patrón
                    currentTarget = miningPattern.getNextBlockToMine((MeganEntity)megan, megan.level());
                }
            } else {
                System.out.println("[MEGAN][DEBUG][CollectGoal] El bloque objetivo ya no es válido: " + state.getBlock() + " (esperado: " + targetBlocks + ")");
                currentTarget = null;
                miningCooldown = 0;
            }
        }
    }

    // Eliminado: findNextTarget(). Ahora el patrón modular decide el siguiente bloque a minar.

    /**
     * Solo recolecta si tiene la herramienta adecuada en la mano
     */
    private boolean canHarvest(Block block) {
        ItemStack mainHand = megan.getMainHandItem();
        String itemName = mainHand.getItem().toString().toLowerCase();
        if (SHOVEL_BLOCKS.contains(block)) {
            return itemName.contains("shovel") || itemName.contains("pala");
        }
        if (PICKAXE_BLOCKS.contains(block)) {
            return itemName.contains("pickaxe") || itemName.contains("pico");
        }
        if (AXE_BLOCKS.contains(block)) {
            return itemName.contains("axe") || itemName.contains("hacha");
        }
        return false;
    }

    /**
     * Devuelve las posiciones adyacentes en la capa actual y capas cercanas
     */
    private List<BlockPos> getAdjacentPositions(BlockPos pos, int baseY, int maxYDiff) {
        List<BlockPos> adj = new ArrayList<>();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                BlockPos np = pos.offset(dx, 0, dz);
                if (np.getY() == baseY)
                    adj.add(np);
            }
        }
        return adj;
    }

    /**
     * Evita romper si hay aire o lava debajo
     */
    private boolean isDangerousToBreak(BlockPos pos, BlockState state) {
        Level level = megan.level();
        BlockPos below = pos.below();
        BlockState belowState = level.getBlockState(below);
        return belowState.isAir() || belowState.getBlock() == Blocks.LAVA;
    }

    /**
     * Rompe el bloque y recoge los drops
     */
    private void breakBlockAndCollect(BlockPos pos, BlockState state) {
        System.out.println("[MEGAN][DEBUG][CollectGoal] breakBlockAndCollect() llamado en " + pos + " bloque: " + state.getBlock());
        Level level = megan.level();
        if (!level.isClientSide && targetBlocks.contains(state.getBlock())) {
            List<ItemStack> drops = Block.getDrops(state, (ServerLevel)level, pos, null, megan, ItemStack.EMPTY);
            System.out.println("[MEGAN][DEBUG][CollectGoal] breakBlockAndCollect() drops: " + drops);
            level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
            if (megan instanceof MeganEntity) {
                for (ItemStack drop : drops) {
                    ((MeganEntity) megan).addItemToInventory(drop);
                }
            } else {
                for (ItemStack drop : drops) {
                    Block.popResource(level, pos, drop);
                }
            }
        }
    }

    /**
     * Verifica si Megan tiene espacio en el inventario
     */
    private boolean hasInventorySpace() {
        if (megan instanceof MeganEntity) {
            return ((MeganEntity) megan).hasInventorySpace();
        }
        return true;
    }

    // --- Búsqueda de tierra estilo villager worker ---
    /**
     * Busca el bloque de tierra más cercano dentro del radio dado.
     */
    private BlockPos findNearestSoilBlock(BlockPos center, int radius) {
        Level level = megan.level();
        BlockPos nearest = null;
        double minDist = Double.MAX_VALUE;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -2; dy <= 2; dy++) { // pequeña altura para evitar bugs
                for (int dz = -radius; dz <= radius; dz++) {
                    BlockPos pos = center.offset(dx, dy, dz);
                    if (level.getBlockState(pos).is(Blocks.DIRT) || level.getBlockState(pos).is(Blocks.GRASS_BLOCK)) {
                        double dist = center.distSqr(pos);
                        if (dist < minDist) {
                            minDist = dist;
                            nearest = pos;
                        }
                    }
                }
            }
        }
        return nearest;
    }

    // --- Métodos públicos para compatibilidad con MeganEntity ---
    /**
     * Devuelve el bloque objetivo actual (puede ser null si no hay objetivo).
     */
    public Block getCurrentTargetBlock() {
        if (currentTarget == null) return null;
        BlockState state = megan.level().getBlockState(currentTarget);
        return state.getBlock();
    }

    /**
     * Permite cambiar dinámicamente los bloques objetivo a minar.
     */
    public void setTargetBlocks(Set<Block> blocks) {
        if (blocks != null && !blocks.isEmpty()) {
            this.targetBlocks = blocks;
        }
    }
}