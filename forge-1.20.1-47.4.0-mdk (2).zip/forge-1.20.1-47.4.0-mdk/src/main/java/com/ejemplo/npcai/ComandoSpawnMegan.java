package com.ejemplo.npcai;

import com.mojang.brigadier.CommandDispatcher;
import java.util.List;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import com.ejemplo.npcai.SpawnUtil;

/**
 * Comando para spawnear a Megan en la posición del jugador.
 * Mensajes y logs en español.
 */
public class ComandoSpawnMegan {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("spawnmegan").executes(ctx -> {
            ServerPlayer player = ctx.getSource().getPlayerOrException();
            System.out.println("[NpcAIMod] Intentando crear Megan...");
            // Busca si ya hay una Megan en el mundo
            MeganEntity existingMegan = null;
            // Busca en TODOS los mundos para máxima robustez
            List<MeganEntity> megans = new java.util.ArrayList<>();
            for (var level : player.server.getAllLevels()) {
                megans.addAll(level.getEntitiesOfClass(MeganEntity.class, level.getWorldBorder().getCollisionShape().bounds()));
            }
            if (!megans.isEmpty()) {
                existingMegan = megans.get(0);
                // Elimina Megans duplicadas si hay más de una
                for (int i = 1; i < megans.size(); i++) {
                    megans.get(i).discard();
                }
            }
            if (existingMegan != null) {
                // Teletransporta a Megan a la posición del jugador
                // Calcula una posición 5 bloques delante del jugador
float yawRad = (float) Math.toRadians(player.getYRot());
double offsetX = -Math.sin(yawRad) * 5;
double offsetZ = Math.cos(yawRad) * 5;
double spawnX = player.getX() + offsetX;
double spawnZ = player.getZ() + offsetZ;
// Buscar altura libre hasta 10 bloques arriba
double spawnY = SpawnUtil.buscarAlturaLibre(player.level(), spawnX, player.getY(), spawnZ, 10);
if (spawnY == -1) {
    ctx.getSource().sendFailure(net.minecraft.network.chat.Component.literal("No hay espacio libre para spawnear/teletransportar a Megan."));
    return 0;
}
existingMegan.moveTo(spawnX, spawnY, spawnZ, player.getYRot(), 0);
                ctx.getSource().sendSuccess(() -> net.minecraft.network.chat.Component.literal("¡Megan ha sido teletransportada!"), false);
                System.out.println("[NpcAIMod] ¡Megan teletransportada!");
                return 1;
            } else {
                MeganEntity megan = ModEntities.MEGAN.get().create(player.level());
                if (megan == null) {
                    ctx.getSource().sendFailure(net.minecraft.network.chat.Component.literal("Error: No se pudo crear la entidad Megan."));
                    return 0;
                }
                // Calcula una posición 5 bloques delante del jugador
float yawRad = (float) Math.toRadians(player.getYRot());
double offsetX = -Math.sin(yawRad) * 5;
double offsetZ = Math.cos(yawRad) * 5;
double spawnX = player.getX() + offsetX;
double spawnZ = player.getZ() + offsetZ;
// Buscar altura libre hasta 10 bloques arriba
double spawnY = SpawnUtil.buscarAlturaLibre(player.level(), spawnX, player.getY(), spawnZ, 10);
if (spawnY == -1) {
    ctx.getSource().sendFailure(net.minecraft.network.chat.Component.literal("No hay espacio libre para spawnear/teletransportar a Megan."));
    return 0;
}
megan.moveTo(spawnX, spawnY, spawnZ, player.getYRot(), 0);
player.level().addFreshEntity(megan);
                ctx.getSource().sendSuccess(() -> net.minecraft.network.chat.Component.literal("¡Megan ha sido spawneada!"), false);
                System.out.println("[NpcAIMod] ¡Megan spawneada correctamente!");
                return 1;
            }
        }));
    }
}