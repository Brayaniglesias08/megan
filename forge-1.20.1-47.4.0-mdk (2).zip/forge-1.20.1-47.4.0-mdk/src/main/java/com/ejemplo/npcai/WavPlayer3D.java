package com.ejemplo.npcai;

import javax.sound.sampled.*;
import java.io.ByteArrayInputStream;

/**
 * Reproduce audio WAV en 3D (posición x, y, z) con volumen y paneo según la posición relativa al jugador.
 * Documentado en español.
 */
public class WavPlayer3D {
    /**
     * Reproduce un audio WAV en la posición dada (x, y, z) con volumen y paneo según la posición del jugador.
     * @param audioWav  Array de bytes WAV
     * @param x         Posición X de Megan
     * @param y         Posición Y de Megan
     * @param z         Posición Z de Megan
     * @param playerX   Posición X del jugador
     * @param playerY   Posición Y del jugador
     * @param playerZ   Posición Z del jugador
     */
    public static void playWavAt(byte[] audioWav, float x, float y, float z, float playerX, float playerY, float playerZ) throws Exception {
        try (ByteArrayInputStream bais = new ByteArrayInputStream(audioWav)) {
            // Log de diagnóstico: imprime los primeros 16 bytes del archivo recibido
            StringBuilder hex = new StringBuilder();
            for (int i = 0; i < Math.min(16, audioWav.length); i++) {
                hex.append(String.format("%02X ", audioWav[i]));
            }
            System.out.println("[DEBUG] Primeros bytes WAV: " + hex.toString());

            AudioInputStream ais = AudioSystem.getAudioInputStream(bais);
            AudioFormat baseFormat = ais.getFormat();
            // Log de diagnóstico: imprime el formato real del WAV recibido
            System.out.println("[DEBUG] Formato WAV recibido: " + baseFormat);
            // Log de diagnóstico: imprime el formato real del WAV recibido
            System.out.println("[DEBUG] Formato WAV recibido: " + baseFormat);
            // Conversión a PCM_SIGNED, 44100 Hz, mono, 16-bit para máxima compatibilidad
            AudioFormat targetFormat = new AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    44100f, // Frecuencia de muestreo estándar
                    16,     // 16 bits por muestra
                    1,      // Mono
                    2,      // 2 bytes por frame (mono, 16-bit)
                    44100f, // Frames por segundo
                    false   // little endian
            );
            AudioInputStream din = AudioSystem.getAudioInputStream(targetFormat, ais);
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, targetFormat);
            try (SourceDataLine line = (SourceDataLine) AudioSystem.getLine(info)) {
                line.open(targetFormat);
                // Cálculo de volumen y paneo
                float dx = x - playerX;
                float dz = z - playerZ;
                float dy = y - playerY;
                float distance = (float) Math.sqrt(dx*dx + dy*dy + dz*dz);
                float maxDistance = 24.0f; // Distancia máxima para escuchar
                float attenuation = Math.max(0f, 1f - (distance / maxDistance));
                // Paneo: -1.0 (izq), 0.0 (centro), 1.0 (der)
                float angle = (float) Math.atan2(dz, dx);
                float pan = (float) Math.sin(angle);
                // Ajustar volumen
                if (line.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                    FloatControl volControl = (FloatControl) line.getControl(FloatControl.Type.MASTER_GAIN);
                    float min = volControl.getMinimum();
                    float max = volControl.getMaximum();
                    float gain = min + (max - min) * attenuation;
                    volControl.setValue(gain);
                }
                // Ajustar paneo si es stereo
                if (line.isControlSupported(FloatControl.Type.PAN)) {
                    FloatControl panControl = (FloatControl) line.getControl(FloatControl.Type.PAN);
                    panControl.setValue(pan);
                }
                line.start();
                byte[] buffer = new byte[4096];
                int n;
                while ((n = din.read(buffer, 0, buffer.length)) != -1) {
                    line.write(buffer, 0, n);
                }
                line.drain();
                line.stop();
            }
        }
    }
}
