package com.ejemplo.npcai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

public class SpawnUtil {
    /**
     * Busca el primer espacio libre hacia arriba desde (x, y, z) hasta maxOffsetY bloques,
     * donde haya 2 bloques de aire para que Megan pueda spawnear.
     * @return La altura Y válida o -1 si no hay espacio suficiente.
     */
    public static double buscarAlturaLibre(Level level, double x, double y, double z, int maxOffsetY) {
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos(x, y, z);
        for (int dy = 0; dy <= maxOffsetY; dy++) {
            pos.set(x, y + dy, z);
            BlockState state1 = level.getBlockState(pos);
            BlockState state2 = level.getBlockState(pos.above());
            if (state1.isAir() && state2.isAir()) {
                return y + dy;
            }
        }
        return -1;
    }
}
