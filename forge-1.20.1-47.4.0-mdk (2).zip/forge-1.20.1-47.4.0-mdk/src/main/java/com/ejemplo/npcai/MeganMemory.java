package com.ejemplo.npcai;

import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.Gson;
import com.google.gson.JsonParser;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MeganMemory {
    private final MeganEntity megan;
    private final File memoryFile;
    private JsonObject memoryData;

    public MeganMemory(MeganEntity megan) {
        this.megan = megan;
        this.memoryFile = new File("megan_memory.json");
        cargar();
    }

    public void cargar() {
        if (memoryFile.exists()) {
            try {
                String content = new String(Files.readAllBytes(Paths.get(memoryFile.getPath())));
                memoryData = JsonParser.parseString(content).getAsJsonObject();
            } catch (IOException e) {
                memoryData = new JsonObject();
            }
        } else {
            memoryData = new JsonObject();
        }
    }

    public void guardar() {
        try (FileWriter writer = new FileWriter(memoryFile)) {
            writer.write(new Gson().toJson(memoryData));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Recordar un dato genérico (clave/valor)
    public void recordarDato(String clave, String valor) {
        if (valor == null) {
            memoryData.remove(clave);
        } else {
            memoryData.addProperty(clave, valor);
        }
        guardar();
    }

    // Recordar un evento emocional
    public void recordarEvento(String uuidJugador, String tipo, String descripcion, String emocion, String lugar) {
        JsonArray eventos = memoryData.has("eventos") ? memoryData.getAsJsonArray("eventos") : new JsonArray();
        JsonObject evento = new JsonObject();
        evento.addProperty("jugador", uuidJugador);
        evento.addProperty("tipo", tipo);
        evento.addProperty("descripcion", descripcion);
        evento.addProperty("emocion", emocion);
        evento.addProperty("lugar", lugar);
        evento.addProperty("fecha", LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME));
        eventos.add(evento);
        memoryData.add("eventos", eventos);
        guardar();
    }

    // Consultar recuerdos de un jugador
    public JsonArray recuerdosDeJugador(String uuidJugador) {
        JsonArray resultado = new JsonArray();
        if (memoryData.has("eventos")) {
            JsonArray eventos = memoryData.getAsJsonArray("eventos");
            for (int i = 0; i < eventos.size(); i++) {
                JsonObject ev = eventos.get(i).getAsJsonObject();
                if (ev.has("jugador") && uuidJugador.equals(ev.get("jugador").getAsString())) {
                    resultado.add(ev);
                }
            }
        }
        return resultado;
    }

    // Consultar recuerdos de un lugar
    public JsonArray recuerdosDeLugar(String lugar) {
        JsonArray resultado = new JsonArray();
        if (memoryData.has("eventos")) {
            JsonArray eventos = memoryData.getAsJsonArray("eventos");
            for (int i = 0; i < eventos.size(); i++) {
                JsonObject ev = eventos.get(i).getAsJsonObject();
                if (ev.has("lugar") && lugar.equals(ev.get("lugar").getAsString())) {
                    resultado.add(ev);
                }
            }
        }
        return resultado;
    }

    // Puedes seguir adaptando los demás métodos siguiendo este patrón:
    // - Usa memoryData.has("clave") para comprobar existencia
    // - Usa getAsJsonArray y getAsJsonObject para arrays/objetos
    // - Usa addProperty para strings, ints, etc.
    // - Usa .get("clave").getAsString() o .getAsInt() para obtener valores

    // Ejemplo de obtener un dato:
    public String obtenerDatoJugador(String uuid, String clave) {
        String key = uuid + ":" + clave;
        return memoryData.has(key) ? memoryData.get(key).getAsString() : null;
    }

    // Ejemplo de modificar confianza:
    public void modificarConfianza(String uuidJugador, int delta) {
        JsonObject conf = memoryData.has("confianza") ? memoryData.getAsJsonObject("confianza") : new JsonObject();
        int actual = conf.has(uuidJugador) ? conf.get(uuidJugador).getAsInt() : 50;
        int nuevo = Math.max(0, Math.min(100, actual + delta));
        conf.addProperty(uuidJugador, nuevo);
        memoryData.add("confianza", conf);
        guardar();
    }

    // ...continúa adaptando los métodos restantes de la misma forma.
}