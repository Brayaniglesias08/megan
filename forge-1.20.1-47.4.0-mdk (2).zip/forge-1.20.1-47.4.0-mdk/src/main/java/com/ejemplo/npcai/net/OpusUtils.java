package com.ejemplo.npcai.net;

import de.maxhenkel.opus4j.OpusEncoder;
import de.maxhenkel.opus4j.OpusDecoder;
import de.maxhenkel.opus4j.OpusEncoder.Application;
import java.util.Arrays;

public class OpusUtils {
    public static byte[] pcmToOpus(short[] pcm, int sampleRate, int channels) throws Exception {
        int frameSize = sampleRate / 50; // 20ms frames
        byte[] opusData = new byte[pcm.length * 2];
        int opusOffset = 0;
        System.out.println("[MEGAN][OPUS] Inicializando codificación PCM->Opus: sampleRate=" + sampleRate + ", channels=" + channels + ", frames=" + (pcm.length/(channels > 0 ? channels : 1)));
        try (OpusEncoder encoder = new OpusEncoder(sampleRate, channels, Application.AUDIO)) {
            for (int i = 0; i < pcm.length; i += frameSize * channels) {
                int len = Math.min(frameSize * channels, pcm.length - i);
                short[] frame = Arrays.copyOfRange(pcm, i, i + len);
                System.out.println("[MEGAN][OPUS] Codificando frame PCM->Opus: offset=" + i + ", len=" + len);
                byte[] encoded = encoder.encode(frame);
                System.arraycopy(encoded, 0, opusData, opusOffset, encoded.length);
                opusOffset += encoded.length;
            }
        }
        return Arrays.copyOf(opusData, opusOffset);
    }

    public static short[] opusToPcm(byte[] opus, int sampleRate, int channels) throws Exception {
        int frameSize = sampleRate / 50; // 20ms frames
        short[] pcm = new short[opus.length * 10];
        int pcmOffset = 0;
        int opusOffset = 0;
        try (OpusDecoder decoder = new OpusDecoder(sampleRate, channels)) {
            while (opusOffset < opus.length) {
                int len = Math.min(4000, opus.length - opusOffset);
                byte[] frame = Arrays.copyOfRange(opus, opusOffset, opusOffset + len);
                short[] decoded = decoder.decode(frame, false);
                System.arraycopy(decoded, 0, pcm, pcmOffset, decoded.length);
                pcmOffset += decoded.length;
                opusOffset += len;
            }
        }
        return Arrays.copyOf(pcm, pcmOffset);
    }
}
