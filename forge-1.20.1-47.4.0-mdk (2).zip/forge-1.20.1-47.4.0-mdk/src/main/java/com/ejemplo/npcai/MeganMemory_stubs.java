package com.ejemplo.npcai;

import net.minecraft.core.BlockPos;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.Gson;
import com.google.gson.JsonParser;

public class MeganMemory_stubs {
    // Métodos stub para compatibilidad con ChatListener y MeganEntity
    public void recordarDatoJugador(String uuid, String clave, String valor) {}
    public void recordarDatoNPC(String nombreNPC, String clave, String valor) {}
    public String buscarUUIDPorNombre(String nombre) { return nombre; }
    public String obtenerDatoJugador(String uuid, String clave) { return null; }
    public String obtenerDatoNPC(String nombreNPC, String clave) { return null; }
    public void guardarRecuerdoUbicacion(String uuid, BlockPos pos, String tipo, String descripcion, String emocion) {}
    public void olvidarRecuerdoUbicacion(BlockPos pos) {}
    public void cambiarEmocionUltimoRecuerdo(String uuid, String emocion) {}
    public String obtenerHistoriaLugar(BlockPos pos) { return ""; }
    public int obtenerContadorRelacion(String nombre, String clave) { return 0; }
    public void recordarContadorRelacion(String nombre, String clave, int valor) {}
    public String generarPensamientoPropio(BlockPos pos) { return ""; }
    public boolean hayRecuerdoEnUbicacion(BlockPos pos) { return false; }
    public boolean contextoCambio(String uuid, String tipo) { return false; }
    public String ajustarEmocion(String uuid, String tipo) { return "neutral"; }
}
