package com.ejemplo.npcai;

/**
 * Estructura simple para datos PCM WAV en memoria.
 */
public class WavPCM {
    public final short[] data;
    public final int sampleRate;
    public final int channels;

    public WavPCM(short[] data, int sampleRate, int channels) {
        this.data = data;
        this.sampleRate = sampleRate;
        this.channels = channels;
    }
}
