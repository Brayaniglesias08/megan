package com.ejemplo.npcai;

import java.nio.charset.StandardCharsets;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.AudioFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ElevenLabsTTS {
    private static final Logger LOGGER = LoggerFactory.getLogger(ElevenLabsTTS.class);
    // TODO: Cambia estos valores por los tuyos
    private static final String API_KEY = "sk_2abd51775b7a7297b82ed42a824de3e01fd369268aef40b5";
    // Puedes probar con la voz estándar 'Rachel' usando este VOICE_ID: 21m00Tcm4TlvDq8ikWAM
    private static final String VOICE_ID = "n4x17EKVqyxfey8QMqvy"; // Cambia aquí para probar otra voz

    /**
     * Solicita audio MP3 a ElevenLabs y lo devuelve como array de bytes.
     */
    public static byte[] solicitarAudioMP3(String texto) throws IOException {
        System.out.println("[DEPURACIÓN] Texto recibido para síntesis de voz ElevenLabs (TTS): " + texto);
        URL url = new URL("https://api.elevenlabs.io/v1/text-to-speech/" + VOICE_ID);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setConnectTimeout(10000);
        con.setReadTimeout(15000);
        con.setRequestMethod("POST");
        con.setRequestProperty("Accept", "audio/mpeg");
        con.setRequestProperty("Content-Type", "application/json");
        con.setRequestProperty("xi-api-key", API_KEY);
        con.setDoOutput(true);

        // Construir el JSON del body
        String body = "{\"text\":\"" + texto.replace("\"", "\\\"") + "\"}";
        try (OutputStream os = con.getOutputStream()) {
            os.write(body.getBytes(StandardCharsets.UTF_8));
        }
        int responseCode = con.getResponseCode();
        System.out.println("[DEPURACIÓN] Código de respuesta HTTP de ElevenLabs (TTS): " + responseCode);
        if (responseCode == 200) {
            byte[] audio = con.getInputStream().readAllBytes();
            System.out.println("[DEPURACIÓN] Audio recibido, tamaño: " + (audio != null ? audio.length : 0) + " bytes");
            return audio;
        } else {
            String errorMessage = con.getResponseMessage();
            System.err.println("[DEPURACIÓN] Error HTTP de ElevenLabs (TTS): " + responseCode + " - " + errorMessage);
            try {
                String errorBody = new String(con.getErrorStream().readAllBytes(), StandardCharsets.UTF_8);
                System.err.println("[DEPURACIÓN] Cuerpo del error de ElevenLabs (TTS): " + errorBody);
            } catch (Exception ex) {
                System.err.println("[DEPURACIÓN] No se pudo leer el cuerpo del error de ElevenLabs (TTS).");
            }
            throw new IOException("Error al generar audio: " + responseCode + " - " + errorMessage);
        }
    }

    /**
     * Solicita audio WAV (PCM 16-bit) a ElevenLabs para el texto dado.
     * @param texto Texto que quieres sintetizar.
     * @return Array de bytes con el audio WAV.
     */
    /**
     * Agrega una cabecera WAV estándar a datos PCM 16-bit, 44.1kHz, mono.
     * @param pcmBytes Datos PCM crudos
     * @return Array de bytes con formato WAV válido
     */
    public static byte[] pcmToWav(byte[] pcmBytes) throws IOException {
        int sampleRate = 44100;
        short numChannels = 1; // Mono
        short bitsPerSample = 16;
        int byteRate = sampleRate * numChannels * bitsPerSample / 8;
        int blockAlign = numChannels * bitsPerSample / 8;
        int dataSize = pcmBytes.length;
        int chunkSize = 36 + dataSize;

        ByteArrayOutputStream out = new ByteArrayOutputStream();
        // Escribe cabecera RIFF/WAVE
        out.write(new byte[]{'R','I','F','F'});
        out.write(intToLittleEndian(chunkSize));
        out.write(new byte[]{'W','A','V','E'});
        out.write(new byte[]{'f','m','t',' '});
        out.write(intToLittleEndian(16)); // Subchunk1Size for PCM
        out.write(shortToLittleEndian((short)1)); // AudioFormat = 1 (PCM)
        out.write(shortToLittleEndian(numChannels));
        out.write(intToLittleEndian(sampleRate));
        out.write(intToLittleEndian(byteRate));
        out.write(shortToLittleEndian((short)blockAlign));
        out.write(shortToLittleEndian(bitsPerSample));
        out.write(new byte[]{'d','a','t','a'});
        out.write(intToLittleEndian(dataSize));
        out.write(pcmBytes);
        return out.toByteArray();
    }

    // Utilidad para escribir enteros en little endian
    private static byte[] intToLittleEndian(int value) {
        return new byte[] {
            (byte)(value & 0xff),
            (byte)((value >> 8) & 0xff),
            (byte)((value >> 16) & 0xff),
            (byte)((value >> 24) & 0xff)
        };
    }
    // Utilidad para escribir shorts en little endian
    private static byte[] shortToLittleEndian(short value) {
        return new byte[] {
            (byte)(value & 0xff),
            (byte)((value >> 8) & 0xff)
        };
    }

    /**
     * Solicita audio WAV (PCM 16-bit) a ElevenLabs para el texto dado.
     * @param texto Texto que quieres sintetizar.
     * @return Array de bytes con el audio WAV.
     */
    public static byte[] obtenerAudioWav(String texto) throws IOException {
        LOGGER.info("[DEPURACIÓN] Texto recibido para síntesis de voz ElevenLabs (obtenerAudioWav): {}", texto);
        String endpoint = "https://api.elevenlabs.io/v1/text-to-speech/" + VOICE_ID + "/stream";
        URL url = new URL(endpoint);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();

        conn.setRequestMethod("POST");
        conn.setRequestProperty("xi-api-key", API_KEY);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", "audio/wav"); // Pedimos WAV explícitamente
        conn.setDoOutput(true);

        // Construye el JSON del cuerpo de la petición
        // Se agrega output_format para asegurar que el audio sea PCM 44.1kHz compatible con Java Sound API
        // Ahora pedimos un archivo WAV estándar para máxima compatibilidad con Java Sound API
        String json = "{" +
                "\"text\": \"" + texto.replace("\"", "\\\"") + "\"," +
                "\"model_id\": \"eleven_multilingual_v2\"," +
                "\"output_format\": \"wav\"," +
                "\"voice_settings\": { \"stability\": 0.5, \"similarity_boost\": 0.8 }" +
                "}";

        // Envía el JSON
        try (OutputStream os = conn.getOutputStream()) {
            byte[] input = json.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        int responseCode = conn.getResponseCode();
        LOGGER.info("[DEPURACIÓN] Código de respuesta HTTP de ElevenLabs (obtenerAudioWav): {}", responseCode);
        if (responseCode != 200) {
            String errorMessage = conn.getResponseMessage();
            LOGGER.error("[DEPURACIÓN] Error HTTP de ElevenLabs (obtenerAudioWav): {} - {}", responseCode, errorMessage);
            try {
                String errorBody = new String(conn.getErrorStream().readAllBytes(), java.nio.charset.StandardCharsets.UTF_8);
                LOGGER.error("[DEPURACIÓN] Cuerpo del error de ElevenLabs (obtenerAudioWav): {}", errorBody);
            } catch (Exception ex) {
                LOGGER.error("[DEPURACIÓN] No se pudo leer el cuerpo del error de ElevenLabs (obtenerAudioWav).");
            }
            throw new IOException("Error al generar audio: " + responseCode + " - " + errorMessage);
        }

        // Lee la respuesta MP3 y decodifica a PCM usando mp3spi/JLayer
        try (InputStream is = conn.getInputStream();
             ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[4096];
            int n;
            while ((n = is.read(buffer)) != -1) {
                baos.write(buffer, 0, n);
            }
            byte[] mp3Bytes = baos.toByteArray();
            LOGGER.info("[DEPURACIÓN] Audio MP3 recibido, tamaño: {} bytes", (mp3Bytes != null ? mp3Bytes.length : 0));
            if (mp3Bytes == null || mp3Bytes.length == 0) {
                // Si el audio es vacío, intenta leer la respuesta como texto para ver si hay un mensaje de error
                try {
                    conn.getInputStream().close(); // Cierra el stream binario
                } catch (Exception ignored) {}
                try {
                    String errorBody = new String(conn.getErrorStream() != null ? conn.getErrorStream().readAllBytes() : new byte[0], java.nio.charset.StandardCharsets.UTF_8);
                    LOGGER.error("[MEGAN][API] Respuesta vacía o de error de ElevenLabs: {}", errorBody);
                } catch (Exception ex) {
                    LOGGER.error("[MEGAN][API] No se pudo leer el cuerpo de error de ElevenLabs: {}", ex.getMessage());
                }
            }
            // Guarda el archivo MP3 recibido para depuración externa
            try {
                java.nio.file.Path path = java.nio.file.Paths.get("audio_recibido.mp3");
                java.nio.file.Files.write(path, mp3Bytes);
                LOGGER.info("[DEPURACIÓN] Archivo MP3 guardado en: {}", path.toAbsolutePath());
            } catch (Exception ex) {
                LOGGER.error("[DEPURACIÓN] No se pudo guardar el archivo MP3 recibido: {}", ex.getMessage());
            }
            // Decodifica el MP3 a PCM usando mp3spi/JLayer
            try (InputStream mp3InputStream = new ByteArrayInputStream(mp3Bytes)) {
                javax.sound.sampled.AudioInputStream mp3AudioStream = javax.sound.sampled.AudioSystem.getAudioInputStream(mp3InputStream);
                javax.sound.sampled.AudioFormat baseFormat = mp3AudioStream.getFormat();
                javax.sound.sampled.AudioFormat decodedFormat = new javax.sound.sampled.AudioFormat(
                    javax.sound.sampled.AudioFormat.Encoding.PCM_SIGNED,
                    baseFormat.getSampleRate(),
                    16,
                    baseFormat.getChannels(),
                    baseFormat.getChannels() * 2,
                    baseFormat.getSampleRate(),
                    false
                );
                javax.sound.sampled.AudioInputStream pcmStream = javax.sound.sampled.AudioSystem.getAudioInputStream(decodedFormat, mp3AudioStream);
                ByteArrayOutputStream pcmBaos = new ByteArrayOutputStream();
                byte[] pcmBuffer = new byte[4096];
                int pcmN;
                while ((pcmN = pcmStream.read(pcmBuffer)) != -1) {
                    pcmBaos.write(pcmBuffer, 0, pcmN);
                }
                byte[] pcmBytes = pcmBaos.toByteArray();
                LOGGER.info("[DEPURACIÓN] PCM decodificado, tamaño: {} bytes", pcmBytes.length);
                // Opcional: convertir a WAV estándar
                byte[] wavBytes = pcmToWav(pcmBytes);
                LOGGER.info("[DEPURACIÓN] WAV generado, tamaño: {} bytes", wavBytes.length);
                return wavBytes;
            } catch (Exception e) {
                LOGGER.error("[ERROR] Excepción en la decodificación MP3→PCM: ", e);
                e.printStackTrace();
                return new byte[0];
            }
        }
    }
}
