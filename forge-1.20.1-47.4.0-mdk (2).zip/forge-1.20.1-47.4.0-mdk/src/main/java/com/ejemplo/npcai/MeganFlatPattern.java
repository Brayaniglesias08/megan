package com.ejemplo.npcai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import com.ejemplo.npcai.MeganEntity;

/**
 * Patrón de minería tipo PLANO (flat) configurable (ancho x largo x altura)
 * Recorre una capa o varias capas planas, comenzando desde la posición base.
 */
public class MeganFlatPattern implements MeganMiningPattern {
    private final BlockPos startPos;
    private final int width;
    private final int length;
    private final int height; // número de capas a limpiar
    private int currentY;
    private int currentX;
    private int currentZ;
    private boolean finished;

    /**
     * Crea un patrón plano en la posición dada, con dimensiones configurables.
     * @param startPos esquina inferior-noroeste (mínimos X y Z, Y base)
     * @param width ancho del plano (en X)
     * @param length largo del plano (en Z)
     * @param height cantidad de capas a limpiar (en Y, hacia arriba)
     */
    public MeganFlatPattern(BlockPos startPos, int width, int length, int height) {
        this.startPos = startPos;
        this.width = width;
        this.length = length;
        this.height = height;
        this.currentY = 0;
        this.currentX = 0;
        this.currentZ = 0;
        this.finished = false;
    }

    @Override
    public BlockPos getNextBlockToMine(MeganEntity entity, Level level) {
        if (finished) return null;
        int baseY = startPos.getY();
        while (currentY < height) {
            while (currentX < width) {
                while (currentZ < length) {
                    BlockPos pos = new BlockPos(
                        startPos.getX() + currentX,
                        baseY + currentY,
                        startPos.getZ() + currentZ
                    );
                    currentZ++;
                    if (!level.getBlockState(pos).isAir()) {
                        return pos;
                    }
                }
                currentZ = 0;
                currentX++;
            }
            currentX = 0;
            currentY++;
        }
        finished = true;
        return null;
    }

    @Override
    public void reset(BlockPos startPos, net.minecraft.core.Direction direction) {
        this.currentY = 0;
        this.currentX = 0;
        this.currentZ = 0;
        this.finished = false;
        // Si necesitas actualizar startPos, quita el final del campo y descomenta:
        // this.startPos = startPos;
    }
}
