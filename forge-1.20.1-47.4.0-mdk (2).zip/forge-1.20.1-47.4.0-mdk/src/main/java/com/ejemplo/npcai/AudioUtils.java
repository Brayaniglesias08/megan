package com.ejemplo.npcai;

import java.io.*;

public class AudioUtils {
    /**
     * Convierte un archivo de audio (WAV o MP3) a OPUS usando ffmpeg.
     * @param inputBytes Los bytes del archivo de entrada.
     * @param inputFormat "wav" o "mp3"
     * @return Los bytes del archivo OPUS convertido.
     * @throws IOException Si hay un error en el proceso.
     */
    public static byte[] convertirAudioAOpus(byte[] inputBytes, String inputFormat) throws IOException {
        File tempIn = File.createTempFile("megan_audio_in", "." + inputFormat);
        File tempOut = File.createTempFile("megan_audio_out", ".opus");
        try (FileOutputStream fos = new FileOutputStream(tempIn)) {
            fos.write(inputBytes);
        }
        ProcessBuilder pb = new ProcessBuilder(
                "ffmpeg", "-y", "-i", tempIn.getAbsolutePath(),
                "-ar", "48000", "-ac", "1", "-c:a", "libopus", tempOut.getAbsolutePath()
        );
        pb.redirectErrorStream(true);
        Process process = pb.start();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Puedes imprimir logs si quieres depurar
            }
        }
        try {
            int exitCode = process.waitFor();
            if (exitCode != 0) {
                throw new IOException("ffmpeg falló con código: " + exitCode);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Conversión interrumpida", e);
        }
        // Leer el archivo OPUS resultante
        byte[] opusBytes;
        try (FileInputStream fis = new FileInputStream(tempOut)) {
            opusBytes = fis.readAllBytes();
        }
        tempIn.delete();
        tempOut.delete();
        return opusBytes;
    }

    /**
     * Convierte un archivo de audio (WAV o MP3) a OGG usando ffmpeg.
     * @param inputBytes Los bytes del archivo de entrada.
     * @param inputFormat "wav" o "mp3"
     * @return Los bytes del archivo OGG convertido.
     * @throws IOException Si hay un error en el proceso.
     */
    /**
     * Convierte un archivo de audio (WAV, MP3 u OGG) a WAV PCM usando ffmpeg.
     * @param inputBytes Los bytes del archivo de entrada.
     * @param inputFormat "wav", "mp3" u "ogg"
     * @return Los bytes del archivo WAV PCM convertido.
     * @throws IOException Si hay un error en el proceso.
     */
    public static byte[] convertirAudioAWav(byte[] inputBytes, String inputFormat) throws IOException {
        File tempIn = File.createTempFile("megan_audio_in", "." + inputFormat);
        File tempOut = File.createTempFile("megan_audio_out", ".wav");
        try (FileOutputStream fos = new FileOutputStream(tempIn)) {
            fos.write(inputBytes);
        }
        ProcessBuilder pb = new ProcessBuilder(
                "ffmpeg", "-y", "-i", tempIn.getAbsolutePath(),
                "-ar", "44100", "-ac", "1", "-c:a", "pcm_s16le", tempOut.getAbsolutePath()
        );
        pb.redirectErrorStream(true);
        Process process = pb.start();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Puedes imprimir logs si quieres depurar
            }
        }
        try {
            int exitCode = process.waitFor();
            if (exitCode != 0) {
                throw new IOException("ffmpeg falló con código: " + exitCode);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Conversión interrumpida", e);
        }
        byte[] wavBytes;
        try (FileInputStream fis = new FileInputStream(tempOut)) {
            wavBytes = fis.readAllBytes();
        }
        tempIn.delete();
        tempOut.delete();
        return wavBytes;
    }

    public static byte[] convertirAudioAOGG(byte[] inputBytes, String inputFormat) throws IOException {
        File tempIn = File.createTempFile("megan_audio_in", "." + inputFormat);
        File tempOut = File.createTempFile("megan_audio_out", ".ogg");
        try (FileOutputStream fos = new FileOutputStream(tempIn)) {
            fos.write(inputBytes);
        }
        ProcessBuilder pb = new ProcessBuilder(
                "ffmpeg", "-y", "-i", tempIn.getAbsolutePath(), "-acodec", "libvorbis", tempOut.getAbsolutePath()
        );
        pb.redirectErrorStream(true);
        Process process = pb.start();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                // Puedes imprimir logs si quieres depurar
            }
        }
        try {
            int exitCode = process.waitFor();
            if (exitCode != 0) {
                throw new IOException("ffmpeg falló con código: " + exitCode);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IOException("Conversión interrumpida", e);
        }
        // Leer el archivo OGG resultante
        byte[] oggBytes;
        try (FileInputStream fis = new FileInputStream(tempOut)) {
            oggBytes = fis.readAllBytes();
        }
        // Limpiar archivos temporales
        tempIn.delete();
        tempOut.delete();
        return oggBytes;
    }
}
