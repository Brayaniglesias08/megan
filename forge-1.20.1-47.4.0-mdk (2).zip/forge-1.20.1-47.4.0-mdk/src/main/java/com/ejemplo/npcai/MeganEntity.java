package com.ejemplo.npcai;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;

/**
 * Entidad básica de Megan. Lista para expansión IA/futuro.
 * Documentación en español para fácil mantenimiento.
 */
public class MeganEntity extends PathfinderMob {
    // Inventario de Megan (27 slots tipo cofre pequeño)
    private final net.minecraft.world.SimpleContainer inventory = new net.minecraft.world.SimpleContainer(27);
    public net.minecraft.world.SimpleContainer getInventory() {
        return inventory;
    }

    @Override
    public net.minecraft.world.InteractionResult mobInteract(net.minecraft.world.entity.player.Player player, net.minecraft.world.InteractionHand hand) {
        if (!this.level().isClientSide) {
            player.openMenu(new net.minecraft.world.MenuProvider() {
                @Override
                public net.minecraft.network.chat.Component getDisplayName() {
                    return net.minecraft.network.chat.Component.literal("Inventario de Megan");
                }
                @Override
                public net.minecraft.world.inventory.AbstractContainerMenu createMenu(int id, net.minecraft.world.entity.player.Inventory inv, net.minecraft.world.entity.player.Player player) {
                    return new MeganInventoryMenu(id, inv, MeganEntity.this.getInventory());
                }
            });
        }
        return net.minecraft.world.InteractionResult.sidedSuccess(this.level().isClientSide);
    }
    // --- Registro de atributos base para Megan ---
    public static net.minecraft.world.entity.ai.attributes.AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MAX_HEALTH, 20.0D)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.MOVEMENT_SPEED, 0.3D)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE, 4.0D)
                .add(net.minecraft.world.entity.ai.attributes.Attributes.FOLLOW_RANGE, 32.0D);
    }

    private boolean enModoSeguir = false;
    public boolean isEnModoSeguir() {
        return enModoSeguir;
    }
    public void setEnModoSeguir(boolean enModoSeguir) {
        this.enModoSeguir = enModoSeguir;
    }

    @Override
    protected void registerGoals() {
        super.registerGoals();
        // Ataca a todos los mobs hostiles excepto creepers
        this.targetSelector.addGoal(2, new net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal<>(
            this, net.minecraft.world.entity.Mob.class, 10, true, false,
            mob -> mob.getType() != net.minecraft.world.entity.EntityType.CREEPER && mob.getType().getCategory() == net.minecraft.world.entity.MobCategory.MONSTER
        ));
    
        super.registerGoals();
        MeganFollowPlayerGoal followGoal = new MeganFollowPlayerGoal(this, 1.1D, 2.5F);
        this.goalSelector.addGoal(1, followGoal);
        this.goalSelector.addGoal(2, new MeganAttackHostileGoal(this));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, ServerPlayer.class, 8.0F));
        this.goalSelector.addGoal(4, new RandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(5, new RandomLookAroundGoal(this));
        // El goal de recolección se añade dinámicamente en startCollectingAllResources/startCollectingResourceByName
    }



    /**
     * Devuelve true si hay al menos un slot vacío en el inventario de Megan.
     */
    public boolean hasInventorySpace() {
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            if (inventory.getItem(i).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    private net.minecraft.world.item.ItemStack storedSword = net.minecraft.world.item.ItemStack.EMPTY;

    public void addItemToInventory(net.minecraft.world.item.ItemStack stack) {
        MeganDebugLogger.log("addItemToInventory llamado con: " + stack.getDisplayName().getString());
        // Si es una espada de diamante, la guarda internamente
        if (stack.getItem() == net.minecraft.world.item.Items.DIAMOND_SWORD) {
            this.storedSword = stack.copy();
            MeganDebugLogger.log("Espada guardada internamente, no equipada todavía.");
        } else {
            inventory.addItem(stack);
            equipBestArmor();
            // Si está recolectando, equipa la mejor herramienta para el bloque objetivo actual
            if (collectGoal != null && collectGoal instanceof com.ejemplo.npcai.MeganCollectResourceGoal) {
                net.minecraft.world.level.block.Block bloqueActual = ((com.ejemplo.npcai.MeganCollectResourceGoal)collectGoal).getCurrentTargetBlock();
                if (bloqueActual != null) {
                    this.equipBestToolForBlock(bloqueActual);
                }
            }
        }
    }

    public void equipStoredSword() {
        MeganDebugLogger.log("equipStoredSword llamado");
        if (!this.storedSword.isEmpty()) {
            this.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, this.storedSword);
            System.out.println("[MEGAN] Espada equipada en mano principal.");
        }
    }

    public void unequipSword() {
        if (this.getMainHandItem().getItem() == net.minecraft.world.item.Items.DIAMOND_SWORD) {
            this.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, net.minecraft.world.item.ItemStack.EMPTY);
            System.out.println("[MEGAN] Espada guardada, mano vacía.");
        }
    }

    /**
     * Equipa automáticamente la mejor herramienta del inventario para el bloque objetivo.
     * Si no encuentra herramienta adecuada, deja la mano como está.
     */
    public void equipBestToolForBlock(net.minecraft.world.level.block.Block block) {
        net.minecraft.world.item.ItemStack bestTool = net.minecraft.world.item.ItemStack.EMPTY;
        int bestLevel = -1;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            net.minecraft.world.item.ItemStack stack = inventory.getItem(i);
            if (stack.isEmpty()) continue;
            System.out.println("[MEGAN][DEBUG][EQUIP] Revisando slot " + i + ": descriptionId=" + stack.getItem().getDescriptionId() + ", displayName=" + stack.getDisplayName().getString());
            // Pala para tierra, arena, grava
            if (com.ejemplo.npcai.ToolUtil.isShovel(stack) && (block == net.minecraft.world.level.block.Blocks.DIRT || block == net.minecraft.world.level.block.Blocks.GRASS_BLOCK || block == net.minecraft.world.level.block.Blocks.SAND || block == net.minecraft.world.level.block.Blocks.GRAVEL)) {
                System.out.println("[MEGAN][DEBUG][EQUIP] ¡Pala candidata encontrada!: " + stack.getDisplayName().getString());
                int lvl = com.ejemplo.npcai.ToolUtil.getToolLevel(stack);
                if (lvl > bestLevel) { bestTool = stack; bestLevel = lvl; }
            }
            // Pico para piedra, minerales
            else if (com.ejemplo.npcai.ToolUtil.isPickaxe(stack) && (block == net.minecraft.world.level.block.Blocks.STONE || block == net.minecraft.world.level.block.Blocks.IRON_ORE || block == net.minecraft.world.level.block.Blocks.DEEPSLATE_IRON_ORE || block == net.minecraft.world.level.block.Blocks.COAL_ORE || block == net.minecraft.world.level.block.Blocks.DEEPSLATE_COAL_ORE || block == net.minecraft.world.level.block.Blocks.DIAMOND_ORE || block == net.minecraft.world.level.block.Blocks.DEEPSLATE_DIAMOND_ORE || block == net.minecraft.world.level.block.Blocks.EMERALD_ORE || block == net.minecraft.world.level.block.Blocks.DEEPSLATE_EMERALD_ORE || block == net.minecraft.world.level.block.Blocks.REDSTONE_ORE || block == net.minecraft.world.level.block.Blocks.DEEPSLATE_REDSTONE_ORE || block == net.minecraft.world.level.block.Blocks.LAPIS_ORE || block == net.minecraft.world.level.block.Blocks.DEEPSLATE_LAPIS_ORE)) {
                int lvl = com.ejemplo.npcai.ToolUtil.getToolLevel(stack);
                if (lvl > bestLevel) { bestTool = stack; bestLevel = lvl; }
            }
            // Hacha para madera
            else if (com.ejemplo.npcai.ToolUtil.isAxe(stack) && (block == net.minecraft.world.level.block.Blocks.OAK_LOG || block == net.minecraft.world.level.block.Blocks.BIRCH_LOG || block == net.minecraft.world.level.block.Blocks.SPRUCE_LOG || block == net.minecraft.world.level.block.Blocks.JUNGLE_LOG || block == net.minecraft.world.level.block.Blocks.ACACIA_LOG || block == net.minecraft.world.level.block.Blocks.DARK_OAK_LOG)) {
                int lvl = com.ejemplo.npcai.ToolUtil.getToolLevel(stack);
                if (lvl > bestLevel) { bestTool = stack; bestLevel = lvl; }
            }
        }
        if (!bestTool.isEmpty()) {
            System.out.println("[MEGAN][DEBUG][EQUIP] Mejor herramienta seleccionada: " + bestTool.getDisplayName().getString());
        }
        if (!bestTool.isEmpty()) {
            this.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, bestTool);
            System.out.println("[MEGAN] Herramienta equipada para el bloque: " + block.getName().getString());
            System.out.println("[MEGAN][DEBUG][EQUIP] Mano principal después de equipar: descriptionId=" + this.getMainHandItem().getItem().getDescriptionId() + ", displayName=" + this.getMainHandItem().getDisplayName().getString());
        }
    }

    // Equipar automáticamente la mejor armadura de cada tipo
    public void equipBestArmor() {
        net.minecraft.world.item.ItemStack bestHelmet = null, bestChest = null, bestLegs = null, bestBoots = null;
        for (int i = 0; i < inventory.getContainerSize(); i++) {
            net.minecraft.world.item.ItemStack stack = inventory.getItem(i);
            if (stack.isEmpty()) continue;
            if (com.ejemplo.npcai.ToolUtil.isHelmet(stack)) {
                if (bestHelmet == null || com.ejemplo.npcai.ToolUtil.compareTools(stack, bestHelmet) < 0) bestHelmet = stack;
            } else if (com.ejemplo.npcai.ToolUtil.isChestplate(stack)) {
                if (bestChest == null || com.ejemplo.npcai.ToolUtil.compareTools(stack, bestChest) < 0) bestChest = stack;
            } else if (com.ejemplo.npcai.ToolUtil.isLeggings(stack)) {
                if (bestLegs == null || com.ejemplo.npcai.ToolUtil.compareTools(stack, bestLegs) < 0) bestLegs = stack;
            } else if (com.ejemplo.npcai.ToolUtil.isBoots(stack)) {
                if (bestBoots == null || com.ejemplo.npcai.ToolUtil.compareTools(stack, bestBoots) < 0) bestBoots = stack;
            }
        }
        this.setItemSlot(net.minecraft.world.entity.EquipmentSlot.HEAD, bestHelmet == null ? net.minecraft.world.item.ItemStack.EMPTY : bestHelmet);
        this.setItemSlot(net.minecraft.world.entity.EquipmentSlot.CHEST, bestChest == null ? net.minecraft.world.item.ItemStack.EMPTY : bestChest);
        this.setItemSlot(net.minecraft.world.entity.EquipmentSlot.LEGS, bestLegs == null ? net.minecraft.world.item.ItemStack.EMPTY : bestLegs);
        this.setItemSlot(net.minecraft.world.entity.EquipmentSlot.FEET, bestBoots == null ? net.minecraft.world.item.ItemStack.EMPTY : bestBoots);
    }

    private ServerPlayer objetivoJugador;
    public MeganCollectResourceGoal collectGoal;
    public MeganCollectItemGoal collectItemGoal;

    public ServerPlayer getObjetivoJugador() {
        return objetivoJugador;
    }

    public void setObjetivoJugador(ServerPlayer jugador) {
        this.objetivoJugador = jugador;
    }

    @Override
    public void setTarget(@javax.annotation.Nullable net.minecraft.world.entity.LivingEntity target) {
        super.setTarget(target);
        if (target != null && !this.storedSword.isEmpty()) {
            this.equipStoredSword();
            System.out.println("[MEGAN][AUTO-EQUIP] Espada equipada automáticamente al detectar objetivo.");
        }
        if (target != null && this.getMainHandItem() != null && !this.getMainHandItem().isEmpty() && this.getMainHandItem().getItem() != net.minecraft.world.item.Items.DIAMOND_SWORD && !this.storedSword.isEmpty()) {
            this.equipStoredSword();
            System.out.println("[MEGAN][AUTO-EQUIP] Cambiando de herramienta a espada para combate.");
        }
        if (target == null && collectGoal != null) {
            if (collectGoal instanceof com.ejemplo.npcai.MeganCollectResourceGoal) {
                net.minecraft.world.level.block.Block bloqueActual = ((com.ejemplo.npcai.MeganCollectResourceGoal)collectGoal).getCurrentTargetBlock();
                if (bloqueActual != null) {
                    this.equipBestToolForBlock(bloqueActual);
                }
            }
        }
    }

    public static final java.util.Set<net.minecraft.world.level.block.Block> ALL_RESOURCES = new java.util.HashSet<>(java.util.Arrays.asList(
            net.minecraft.world.level.block.Blocks.DIRT,
            net.minecraft.world.level.block.Blocks.GRASS_BLOCK,
            net.minecraft.world.level.block.Blocks.STONE,
            net.minecraft.world.level.block.Blocks.SAND,
            net.minecraft.world.level.block.Blocks.IRON_ORE,
            net.minecraft.world.level.block.Blocks.DEEPSLATE_IRON_ORE,
            net.minecraft.world.level.block.Blocks.COAL_ORE,
            net.minecraft.world.level.block.Blocks.DEEPSLATE_COAL_ORE,
            net.minecraft.world.level.block.Blocks.OAK_LOG,
            net.minecraft.world.level.block.Blocks.BIRCH_LOG,
            net.minecraft.world.level.block.Blocks.SPRUCE_LOG,
            net.minecraft.world.level.block.Blocks.JUNGLE_LOG,
            net.minecraft.world.level.block.Blocks.ACACIA_LOG,
            net.minecraft.world.level.block.Blocks.DARK_OAK_LOG,
            net.minecraft.world.level.block.Blocks.REDSTONE_ORE,
            net.minecraft.world.level.block.Blocks.DEEPSLATE_REDSTONE_ORE,
            net.minecraft.world.level.block.Blocks.LAPIS_ORE,
            net.minecraft.world.level.block.Blocks.DEEPSLATE_LAPIS_ORE,
            net.minecraft.world.level.block.Blocks.DIAMOND_ORE,
            net.minecraft.world.level.block.Blocks.DEEPSLATE_DIAMOND_ORE,
            net.minecraft.world.level.block.Blocks.EMERALD_ORE,
            net.minecraft.world.level.block.Blocks.DEEPSLATE_EMERALD_ORE
    ));
    public static final java.util.Map<String, java.util.Set<net.minecraft.world.level.block.Block>> NAMED_RESOURCES = new java.util.HashMap<>();
    static {
        NAMED_RESOURCES.put("tierra", java.util.Set.of(net.minecraft.world.level.block.Blocks.DIRT, net.minecraft.world.level.block.Blocks.GRASS_BLOCK));
        NAMED_RESOURCES.put("piedra", java.util.Set.of(net.minecraft.world.level.block.Blocks.STONE));
        NAMED_RESOURCES.put("arena", java.util.Set.of(net.minecraft.world.level.block.Blocks.SAND));
        NAMED_RESOURCES.put("hierro", java.util.Set.of(net.minecraft.world.level.block.Blocks.IRON_ORE, net.minecraft.world.level.block.Blocks.DEEPSLATE_IRON_ORE));
        NAMED_RESOURCES.put("carbón", java.util.Set.of(net.minecraft.world.level.block.Blocks.COAL_ORE, net.minecraft.world.level.block.Blocks.DEEPSLATE_COAL_ORE));
        NAMED_RESOURCES.put("madera", java.util.Set.of(
                net.minecraft.world.level.block.Blocks.OAK_LOG,
                net.minecraft.world.level.block.Blocks.BIRCH_LOG,
                net.minecraft.world.level.block.Blocks.SPRUCE_LOG,
                net.minecraft.world.level.block.Blocks.JUNGLE_LOG,
                net.minecraft.world.level.block.Blocks.ACACIA_LOG,
                net.minecraft.world.level.block.Blocks.DARK_OAK_LOG
        ));
        NAMED_RESOURCES.put("redstone", java.util.Set.of(net.minecraft.world.level.block.Blocks.REDSTONE_ORE, net.minecraft.world.level.block.Blocks.DEEPSLATE_REDSTONE_ORE));
        NAMED_RESOURCES.put("lapislázuli", java.util.Set.of(net.minecraft.world.level.block.Blocks.LAPIS_ORE, net.minecraft.world.level.block.Blocks.DEEPSLATE_LAPIS_ORE));
        NAMED_RESOURCES.put("diamante", java.util.Set.of(net.minecraft.world.level.block.Blocks.DIAMOND_ORE, net.minecraft.world.level.block.Blocks.DEEPSLATE_DIAMOND_ORE));
        NAMED_RESOURCES.put("esmeralda", java.util.Set.of(net.minecraft.world.level.block.Blocks.EMERALD_ORE, net.minecraft.world.level.block.Blocks.DEEPSLATE_EMERALD_ORE));
    }

    public void startCollectingAllResources() {
        if (collectGoal == null) {
            collectGoal = new MeganCollectResourceGoal(this, new java.util.HashSet<>(ALL_RESOURCES), 16, pos -> true);
            this.goalSelector.addGoal(2, collectGoal);
        } else {
            collectGoal.setTargetBlocks(new java.util.HashSet<>(ALL_RESOURCES));
        }
    }

    public void startCollectingResourceByName(String name) {
        java.util.Set<net.minecraft.world.level.block.Block> blocks = NAMED_RESOURCES.get(name);
        if (blocks != null) {
            if (collectGoal != null) {
                this.goalSelector.removeGoal(collectGoal);
                collectGoal = null;
            }
            collectGoal = new MeganCollectResourceGoal(this, new java.util.HashSet<>(blocks), 16, pos -> true);
            this.goalSelector.addGoal(2, collectGoal);
        }
    }

    public void stopCollecting() {
        if (collectGoal != null) {
            this.goalSelector.removeGoal(collectGoal);
            collectGoal = null;
        }
    }

    public MeganCollectItemGoal getCollectItemGoal() {
        return collectItemGoal;
    }

    // --- CAMPOS Y MÉTODOS AUXILIARES AVANZADOS ---
    public enum MeganStatus {
        MINAR, SEGUIR, ESPERAR, DEFENDER, LIMPIAR, PAUSADO, PRIORIZAR_DIAMANTE, SOLO_HIERRO
    }
    private MeganStatus meganStatus = MeganStatus.MINAR;
    private String prioritizedResource = null;
    public MeganStatus getMeganStatus() { return meganStatus; }
    public void setMeganStatus(MeganStatus status) { this.meganStatus = status; }
    public void setPrioritizedResource(String recurso) { this.prioritizedResource = recurso; }
    public String getPrioritizedResource() { return this.prioritizedResource; }

    private BlockPos chestPos;
    private boolean inventoryFullFlag = false;

    public boolean isInventoryFullFlag() {
        return this.inventoryFullFlag;
    }
    private ServerPlayer lastOwnerPlayer;
    public enum Reabastecimiento {
        ANTORCHA(Items.TORCH),
        PICO(Items.IRON_PICKAXE),
        PALA(Items.IRON_SHOVEL),
        COMIDA(Items.BREAD);
        private final Item item;
        Reabastecimiento(Item item) { this.item = item; }
        public boolean matches(ItemStack stack) { return stack.is(item); }
    }
    public boolean isInventoryFull() {
        for (int i = 0; i < this.getInventory().getContainerSize(); i++) {
            if (this.getInventory().getItem(i).isEmpty()) return false;
        }
        return true;
    }
    public BlockPos getChestPos() { return chestPos; }
    public void setChestPos(BlockPos pos) { this.chestPos = pos; }
    public void clearChestPos() { this.chestPos = null; }
    public ServerPlayer getOwnerPlayer() { return lastOwnerPlayer; }
    public void setOwnerPlayer(ServerPlayer player) { this.lastOwnerPlayer = player; }
    public void sendFeedbackToOwner(String msg) {
        if (lastOwnerPlayer != null) {
            lastOwnerPlayer.sendSystemMessage(net.minecraft.network.chat.Component.literal(msg));
        }
    }
    public boolean wantsToKeep(ItemStack stack) {
        return stack.is(Items.TORCH) || stack.getItem() instanceof net.minecraft.world.item.PickaxeItem || stack.getItem() instanceof net.minecraft.world.item.ShovelItem || stack.isEdible();
    }
    public boolean needsItem(Reabastecimiento tipo) {
        switch (tipo) {
            case ANTORCHA: return this.getInventory().countItem(Items.TORCH) < 16;
            case PICO: return !this.getInventory().hasAnyMatching(s -> s.getItem() instanceof net.minecraft.world.item.PickaxeItem);
            case PALA: return !this.getInventory().hasAnyMatching(s -> s.getItem() instanceof net.minecraft.world.item.ShovelItem);
            case COMIDA: return !this.getInventory().hasAnyMatching(ItemStack::isEdible);
        }
        return false;
    }
    public void depositItemsToPlayer(Player player) {
        var inv = this.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (!stack.isEmpty() && !wantsToKeep(stack)) {
                player.getInventory().add(stack.copy());
                inv.setItem(i, ItemStack.EMPTY);
            }
        }
    }
    public void resetInventoryFullFlag() { this.inventoryFullFlag = false; }
    public void setStateMining() { this.inventoryFullFlag = false; /* aquí puedes cambiar el goal a minería */ }

    public void markInventoryFull(ServerPlayer owner) {
        this.inventoryFullFlag = true;
        this.setOwnerPlayer(owner);
    }
    // --- FIN MÉTODOS AUXILIARES ---
    public void processPlayerMessage(String mensaje, net.minecraft.server.level.ServerPlayer jugador) {
        String msgNorm = mensaje.toLowerCase().replace("á","a").replace("é","e").replace("í","i").replace("ó","o").replace("ú","u");

        // --- Comandos avanzados ---
        if (msgNorm.contains("detente")) {
            setMeganStatus(MeganStatus.PAUSADO);
            if (jugador != null) jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Me detengo y espero nuevas órdenes!"));
            return;
        }
        if (msgNorm.contains("continua") || msgNorm.contains("reanuda")) {
            setMeganStatus(MeganStatus.MINAR);
            if (jugador != null) jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Reanudo mi trabajo de minería!"));
            return;
        }
        if (msgNorm.contains("sigueme")) {
            setMeganStatus(MeganStatus.SEGUIR);
            if (jugador != null) jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Te sigo!"));
            return;
        }
        if (msgNorm.contains("espera aqui")) {
            setMeganStatus(MeganStatus.ESPERAR);
            if (jugador != null) jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Espero aquí hasta nueva orden!"));
            return;
        }
        if (msgNorm.contains("defiende zona")) {
            setMeganStatus(MeganStatus.DEFENDER);
            if (jugador != null) jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Defenderé esta zona y atacaré mobs hostiles!"));
            return;
        }
        if (msgNorm.contains("limpia area")) {
            setMeganStatus(MeganStatus.LIMPIAR);
            if (jugador != null) jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Limpiaré árboles y obstáculos en esta área!"));
            return;
        }
        if (msgNorm.contains("prioriza diamante")) {
            setMeganStatus(MeganStatus.PRIORIZAR_DIAMANTE);
            setPrioritizedResource("diamond_ore");
            if (jugador != null) jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Priorizaré diamante sobre otros recursos!"));
            return;
        }
        if (msgNorm.contains("solo mina hierro")) {
            setMeganStatus(MeganStatus.SOLO_HIERRO);
            setPrioritizedResource("iron_ore");
            if (jugador != null) jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Solo minaré hierro y lo demás lo ignoraré!"));
            return;
        }

        // --- Patrón PLANO (flat configurable) ---
        if (msgNorm.matches(".*(haz|mina|construye|cava) (un )?plano( [0-9]+x[0-9]+x[0-9]+)?")) {
            int width = 8, length = 8, height = 1; // default
            java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("plano ([0-9]+)x([0-9]+)x([0-9]+)").matcher(msgNorm);
            if (matcher.find()) {
                width = Integer.parseInt(matcher.group(1));
                length = Integer.parseInt(matcher.group(2));
                height = Integer.parseInt(matcher.group(3));
            }
            if (collectGoal != null) {
                this.goalSelector.removeGoal(collectGoal);
                collectGoal = null;
            }
            // Usar el patrón PLANO
            collectGoal = new MeganCollectResourceGoal(this, new java.util.HashSet<>(ALL_RESOURCES), 16, pos -> true);
            collectGoal.setMiningPattern(new MeganFlatPattern(this.blockPosition(), width, length, height));
            this.goalSelector.addGoal(2, collectGoal);
            if (jugador != null) {
                jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Minando plano de tamaño " + width + "x" + length + "x" + height + "!"));
            }
            return;
        }
        // --- Patrón ROOM (sala configurable) ---
        if (msgNorm.matches(".*(haz|mina|construye|cava) (una )?(sala|room)( [0-9]+x[0-9]+x[0-9]+)?")) {
            int width = 8, length = 8, height = 3; // default
            java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("(sala|room) ([0-9]+)x([0-9]+)x([0-9]+)").matcher(msgNorm);
            if (matcher.find()) {
                width = Integer.parseInt(matcher.group(2));
                length = Integer.parseInt(matcher.group(3));
                height = Integer.parseInt(matcher.group(4));
            }
            if (collectGoal != null) {
                this.goalSelector.removeGoal(collectGoal);
                collectGoal = null;
            }
            // Usar el patrón ROOM
            collectGoal = new MeganCollectResourceGoal(this, new java.util.HashSet<>(ALL_RESOURCES), 16, pos -> true);
            collectGoal.setMiningPattern(new MeganRoomPattern(this.blockPosition(), width, length, height));
            this.goalSelector.addGoal(2, collectGoal);
            if (jugador != null) {
                jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Minando sala de tamaño " + width + "x" + length + "x" + height + "!"));
            }
            return;
        }
        // --- Patrón PIT (pozo configurable) ---
        if (msgNorm.matches(".*(haz|mina|construye|cava) (un )?pozo( [0-9]+x[0-9]+x[0-9]+)?")) {
            int width = 8, length = 8, depth = 8; // default
            java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("pozo ([0-9]+)x([0-9]+)x([0-9]+)").matcher(msgNorm);
            if (matcher.find()) {
                width = Integer.parseInt(matcher.group(1));
                length = Integer.parseInt(matcher.group(2));
                depth = Integer.parseInt(matcher.group(3));
            }
            if (collectGoal != null) {
                this.goalSelector.removeGoal(collectGoal);
                collectGoal = null;
            }
            // Usar el patrón PIT
            collectGoal = new MeganCollectResourceGoal(this, new java.util.HashSet<>(ALL_RESOURCES), 16, pos -> true);
            collectGoal.setMiningPattern(new MeganPitPattern(this.blockPosition(), width, length, depth));
            this.goalSelector.addGoal(2, collectGoal);
            if (jugador != null) {
                jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Minando pozo de tamaño " + width + "x" + length + "x" + depth + "!"));
            }
            return;
        }
        // --- Asignar base/cofre ---
        if (msgNorm.matches(".*(asigna base|usa este cofre|asigna cofre|set base|set chest).*") ) {
            this.setChestPos(this.blockPosition());
            if (jugador != null) {
                jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Base/cofre asignado en esta posición!"));
            }
            return;
        }

        // --- Equipar/Espada ---
        if ((msgNorm.contains("toma la espada") || msgNorm.contains("equipa la espada")) && !this.storedSword.isEmpty()) {
            this.equipStoredSword();
            if (jugador != null) {
                jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡He equipado la espada!"));
            }
            return;
        }
        if (msgNorm.contains("guarda la espada") && this.getMainHandItem().getItem() == net.minecraft.world.item.Items.DIAMOND_SWORD) {
            this.unequipSword();
            if (jugador != null) {
                jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡He guardado la espada!"));
            }
            return;
        }

        // --- Comandos de recolección de recursos o herramientas ---
        String[] verbos = {"toma", "agarra", "coge", "recoge", "ve por", "busca", "recolecta", "consigue", "trae"};
        boolean contieneVerbo = false;
        for (String verbo : verbos) {
            if (msgNorm.contains(verbo)) {
                contieneVerbo = true;
                break;
            }
        }
        if (contieneVerbo) {
            String recursoDetectado = null;
            for (String recurso : NAMED_RESOURCES.keySet()) {
                if (msgNorm.contains(recurso)) {
                    recursoDetectado = recurso;
                    break;
                }
            }
            if (recursoDetectado != null) {
                this.startCollectingResourceByName(recursoDetectado);
                if (jugador != null) {
                    jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Voy por " + recursoDetectado + "!"));
                }
                return;
            }
            String[] herramientas = {"espada", "pico", "hacha", "pala"};
            for (String herramienta : herramientas) {
                if (msgNorm.contains(herramienta)) {
                    if (collectItemGoal == null) {
                        collectItemGoal = new MeganCollectItemGoal(this, 1.1);
                        this.goalSelector.addGoal(3, collectItemGoal);
                    }
                    collectItemGoal.activate(herramienta);
                    if (jugador != null) {
                        jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("¡Voy por la " + herramienta + "!"));
                    }
                    return;
                }
            }
            if (jugador != null) {
                jugador.sendSystemMessage(net.minecraft.network.chat.Component.literal("No entiendo qué debo recoger. Por favor, especifica un recurso válido."));
            }
            return;
        }
    }

    public MeganEntity(EntityType<? extends PathfinderMob> type, Level world) {
        super(type, world);
    }

    public void goToPlayer(ServerPlayer player) {
        if (player == null) return;
        this.setObjetivoJugador(player);
    }

    @Override
    public boolean doHurtTarget(net.minecraft.world.entity.Entity target) {
        net.minecraft.world.item.ItemStack bestSword = net.minecraft.world.item.ItemStack.EMPTY;
        int bestLevel = -1;
        for (int i = 0; i < this.inventory.getContainerSize(); i++) {
            net.minecraft.world.item.ItemStack stack = this.inventory.getItem(i);
            if (stack.isEmpty()) continue;
            if (com.ejemplo.npcai.ToolUtil.isSword(stack)) {
                int lvl = com.ejemplo.npcai.ToolUtil.getToolLevel(stack);
                if (lvl > bestLevel) {
                    bestLevel = lvl;
                    bestSword = stack;
                }
            }
        }
        net.minecraft.world.item.ItemStack hand = this.getMainHandItem();
        if (!hand.isEmpty() && com.ejemplo.npcai.ToolUtil.isSword(hand)) {
            int lvl = com.ejemplo.npcai.ToolUtil.getToolLevel(hand);
            if (lvl > bestLevel) {
                bestLevel = lvl;
                bestSword = hand;
            }
        }
        if (!this.storedSword.isEmpty() && com.ejemplo.npcai.ToolUtil.isSword(this.storedSword)) {
            int lvl = com.ejemplo.npcai.ToolUtil.getToolLevel(this.storedSword);
            if (lvl > bestLevel) {
                bestLevel = lvl;
                bestSword = this.storedSword;
            }
        }
        if (!bestSword.isEmpty() && (this.getMainHandItem().isEmpty() || !com.ejemplo.npcai.ToolUtil.isSword(this.getMainHandItem()) || com.ejemplo.npcai.ToolUtil.getToolLevel(this.getMainHandItem()) < bestLevel)) {
            this.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, bestSword.copy());
        }
        net.minecraft.world.item.ItemStack weapon = this.getMainHandItem();
        float damage = 2.0F;
        if (!weapon.isEmpty()) {
            java.util.Collection<net.minecraft.world.entity.ai.attributes.AttributeModifier> modifiers =
                    weapon.getAttributeModifiers(net.minecraft.world.entity.EquipmentSlot.MAINHAND)
                            .get(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE);
            if (modifiers != null && !modifiers.isEmpty()) {
                for (net.minecraft.world.entity.ai.attributes.AttributeModifier mod : modifiers) {
                    damage += mod.getAmount();
                }
            }
        }
        net.minecraft.world.damagesource.DamageSources sources = this.level().damageSources();
        boolean result = target.hurt(sources.mobAttack(this), damage);
        if (result) {
            this.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
            this.level().broadcastEntityEvent(this, (byte) 4);
        }
        return result;
    }
}