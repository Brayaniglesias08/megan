package com.ejemplo.npcai;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;

import javax.sound.sampled.*;
import java.io.*;

@EventBusSubscriber(modid = "npcai", bus = Bus.FORGE, value = Dist.CLIENT)
public class MeganVoiceInput {
    private static AudioRecorder recorder = null;
    private static boolean isRecording = false;

    public static boolean isRecording() {
        return isRecording;
    }

    @SubscribeEvent
    public static void onKeyInput(InputEvent.Key keyEvent) {
        // Usa la tecla V (keycode 86) para grabar
        if (keyEvent.getKey() == 86) {
            if (keyEvent.getAction() == 1 && !isRecording) { // PRESSED
                startVoiceRecording();
            } else if (keyEvent.getAction() == 0 && isRecording) { // RELEASED
                stopVoiceRecording();
            }
        }
    }

    private static void startVoiceRecording() {
        try {
            recorder = new AudioRecorder();
            recorder.startRecording("voz.wav");
            isRecording = true;
            System.out.println("[Megan] Grabando audio...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void stopVoiceRecording() {
        try {
            recorder.stopRecording();
            isRecording = false;
            System.out.println("[Megan] Audio grabado. Enviando a Whisper...");
            String texto = WhisperClient.sendAudio(recorder.getWavFile());
            System.out.println("[Megan] Texto reconocido: " + texto);
            enviarMensajeAMegan(texto);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void enviarMensajeAMegan(String texto) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player != null && texto != null && !texto.trim().isEmpty()) {
            // Enviar mensaje como chat local (Forge 1.19.2)
            net.minecraft.network.chat.Component mensaje = net.minecraft.network.chat.Component.literal("Megan, " + texto);
            // Enviar mensaje como chat normal (Forge 1.19.2)
            // TODO: Revisar el constructor correcto de ServerboundChatPacket para Forge 1.20.1
// player.connection.send(new net.minecraft.network.protocol.game.ServerboundChatPacket(mensaje.getString(), java.time.Instant.now(), 0L, null, false, null));
        }
    }
}

// --- AudioRecorder y WhisperClient igual que en el ejemplo anterior ---
class AudioRecorder {
    private TargetDataLine line;
    private AudioFileFormat.Type fileType = AudioFileFormat.Type.WAVE;
    private File wavFile;

    public void startRecording(String filename) throws Exception {
        AudioFormat format = new AudioFormat(16000, 16, 1, true, false);
        DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
        line = (TargetDataLine) AudioSystem.getLine(info);
        line.open(format);
        line.start();
        wavFile = new File(filename);

        Thread thread = new Thread(() -> {
            try (AudioInputStream ais = new AudioInputStream(line)) {
                AudioSystem.write(ais, fileType, wavFile);
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
        thread.start();
    }

    public void stopRecording() {
        line.stop();
        line.close();
    }

    public File getWavFile() {
        return wavFile;
    }
}

class WhisperClient {
    public static String sendAudio(File audioFile) throws IOException {
        String boundary = Long.toHexString(System.currentTimeMillis());
        java.net.URL url = new java.net.URL("http://localhost:5000/transcribe");
        java.net.HttpURLConnection connection = (java.net.HttpURLConnection) url.openConnection();
        connection.setDoOutput(true);
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);

        try (OutputStream output = connection.getOutputStream();
             PrintWriter writer = new PrintWriter(new OutputStreamWriter(output, "UTF-8"), true)) {
            writer.append("--" + boundary).append("\r\n");
            writer.append("Content-Disposition: form-data; name=\"audio\"; filename=\"" + audioFile.getName() + "\"\r\n");
            writer.append("Content-Type: audio/wav\r\n\r\n").flush();
            try (FileInputStream inputStream = new FileInputStream(audioFile)) {
                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = inputStream.read(buffer)) != -1) {
                    output.write(buffer, 0, bytesRead);
                }
            }
            output.flush();
            writer.append("\r\n").flush();
            writer.append("--" + boundary + "--").append("\r\n").flush();
        }

        int responseCode = connection.getResponseCode();
        if (responseCode == java.net.HttpURLConnection.HTTP_OK) {
            try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                StringBuilder response = new StringBuilder();
                String inputLine;
                while ((inputLine = in.readLine()) != null) {
                    response.append(inputLine);
                }
                // Extrae el texto del JSON recibido
                String json = response.toString();
                int idx = json.indexOf(":");
                int end = json.lastIndexOf("}");
                if (idx != -1 && end != -1) {
                    return json.substring(idx + 2, end - 1);
                }
                return json;
            }
        } else {
            throw new IOException("Server returned non-OK status: " + responseCode);
        }
    }
}
