package com.ejemplo.npcai;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Mantiene una lista de sonidos que siguen a entidades y los actualiza cada tick del cliente.
 */
public class ClientAudioTracker {
    private static final List<SoundFollowEntity> activeSounds = new CopyOnWriteArrayList<>();

    public static void addSound(SoundFollowEntity sound) {
        if (sound != null) activeSounds.add(sound);
    }

    // Llama a esto en el evento de tick del cliente
    public static void onClientTick() {
        List<SoundFollowEntity> toRemove = new java.util.ArrayList<>();
        for (SoundFollowEntity sound : activeSounds) {
            sound.updatePosition();
            if (!sound.isPlaying() || sound.getEntity() == null || !sound.getEntity().isAlive()) {
                sound.cleanup();
                toRemove.add(sound);
            }
        }
        activeSounds.removeAll(toRemove);
    }
}
