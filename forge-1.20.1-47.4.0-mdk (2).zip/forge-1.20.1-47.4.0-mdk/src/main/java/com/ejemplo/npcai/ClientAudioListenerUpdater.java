package com.ejemplo.npcai;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import org.lwjgl.openal.AL10;

@Mod.EventBusSubscriber(modid = "meganai", value = Dist.CLIENT)
public class ClientAudioListenerUpdater {
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player != null && mc.level != null) {
            // Actualiza la posición del listener de OpenAL al jugador
            AL10.alListener3f(AL10.AL_POSITION, (float)player.getX(), (float)player.getY(), (float)player.getZ());
        }
    }
}
