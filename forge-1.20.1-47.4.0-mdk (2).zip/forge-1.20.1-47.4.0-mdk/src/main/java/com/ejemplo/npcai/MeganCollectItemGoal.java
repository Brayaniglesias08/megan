package com.ejemplo.npcai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.InteractionHand;

import java.util.EnumSet;
import java.util.List;

public class MeganCollectItemGoal extends Goal {
    private boolean yaNotificadoQueTienePala = false; // Evita spam de logs
    private final PathfinderMob megan;
    private ItemEntity targetItem;
    private final double speed;
    private final double pickupRadius = 10.0; // blocks // Rango amplio para recoger ítems lanzados desde lejos
    private final double scanRadius = 20.0; // blocks
    private boolean active = false;
    private String itemTypeFilter = null;

    public MeganCollectItemGoal(PathfinderMob megan, double speed) {
        this.megan = megan;
        this.speed = speed;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE));
    }

    /**
     * Activa el goal para recoger un tipo específico de ítem ("espada", "pico", "hacha", "pala").
     */
    public void activate(String itemType) {
        this.active = true;
        this.itemTypeFilter = itemType;
        this.yaNotificadoQueTienePala = false; // Reinicia flag al activar
    }
    public void deactivate() {
        this.active = false;
        this.itemTypeFilter = null;
    }

    @Override
    public boolean canUse() {
        if (!active || itemTypeFilter == null) return false;
        // Si el filtro es 'pala', solo buscar si NO tiene pala en mano ni en inventario
        if ("pala".equalsIgnoreCase(itemTypeFilter)) {
            if (com.ejemplo.npcai.ToolUtil.isShovel(megan.getMainHandItem())) {
                if (!yaNotificadoQueTienePala) {
                    System.out.println("[Depurar] Megan ya tiene pala en la mano, no busca más.");
                    yaNotificadoQueTienePala = true;
                }
                return false;
            }
            // Buscar en inventario si es MeganEntity
            if (megan instanceof com.ejemplo.npcai.MeganEntity meganEntity) {
                boolean tienePala = false;
                for (int i = 0; i < meganEntity.getInventory().getContainerSize(); i++) {
                    if (com.ejemplo.npcai.ToolUtil.isShovel(meganEntity.getInventory().getItem(i))) {
                        tienePala = true;
                        break;
                    }
                }
                if (tienePala) {
                    if (!yaNotificadoQueTienePala) {
                        System.out.println("[Depurar] Megan ya tiene pala en el inventario, no busca más.");
                        yaNotificadoQueTienePala = true;
                    }
                    return false;
                }
            }
        }
        System.out.println("[Depurar] MeganCollectItemGoal.canUse() llamado. Filtro: '" + itemTypeFilter + "'");
        List<ItemEntity> items = megan.level().getEntitiesOfClass(ItemEntity.class, megan.getBoundingBox().inflate(scanRadius),
                item -> item.isAlive() && !item.hasPickUpDelay() && !item.getItem().isEmpty() && matchesFilter(item.getItem())
        );

        double closestDist = Double.MAX_VALUE;
        ItemEntity closest = null;
        for (ItemEntity item : items) {
            double dist = megan.distanceToSqr(item);
            if (dist < closestDist) {
                closestDist = dist;
                closest = item;
            }
        }
        if (closest != null) {
            System.out.println("[Depurar] Target encontrado para recoger: '" + closest.getItem().getHoverName().getString() + "' en (" + closest.getX() + ", " + closest.getY() + ", " + closest.getZ() + ")");
            targetItem = closest;
            return true;
        }
        System.out.println("[Depurar] No se encontró ningún ítem válido para recoger.");
        targetItem = null;
        return false;
    }

    /**
     * Devuelve true si el ItemStack corresponde al filtro actual.
     */
    private boolean matchesFilter(ItemStack stack) {
        if (itemTypeFilter == null) return false;
        switch (itemTypeFilter) {
            case "espada":
                return com.ejemplo.npcai.ToolUtil.isSword(stack);
            case "pico":
                return com.ejemplo.npcai.ToolUtil.isPickaxe(stack);
            case "hacha":
                return com.ejemplo.npcai.ToolUtil.isAxe(stack);
            case "pala":
                return com.ejemplo.npcai.ToolUtil.isShovel(stack);
            default:
                return false;
        }
    }

    @Override
    public boolean canContinueToUse() {
        return targetItem != null && targetItem.isAlive() && megan.distanceToSqr(targetItem) < scanRadius * scanRadius;
    }

    @Override
    public void start() {
        // No-op
    }

    @Override
    public void stop() {
        targetItem = null;
    }

    @Override
    public void tick() {
        if (targetItem == null || !targetItem.isAlive()) return;
        System.out.println("[Depurar] Megan acercándose a recoger: '" + targetItem.getItem().getHoverName().getString() + "'");
        megan.getNavigation().moveTo(targetItem.getX(), targetItem.getY(), targetItem.getZ(), speed);
        if (megan.distanceToSqr(targetItem) < pickupRadius * pickupRadius) {
            System.out.println("[Depurar] Megan está lo suficientemente cerca para recoger: '" + targetItem.getItem().getHoverName().getString() + "'");
            if (megan instanceof MeganEntity meganEntity) {
                ItemStack stack = targetItem.getItem().copy();
                meganEntity.addItemToInventory(stack);
                targetItem.discard();
                meganEntity.setItemInHand(InteractionHand.MAIN_HAND, stack);
            }
        }
    }
}
