package com.ejemplo.npcai.net;

import java.util.*;
import com.ejemplo.npcai.OpenALStreamingPlayer;

public class MeganAudioClientHandler {
    private static final Map<Integer, List<byte[]>> streamChunks = new HashMap<>();
    private static final Map<Integer, MeganAudioPacket> streamMeta = new HashMap<>();

    public static void handleIncomingChunk(MeganAudioPacket pkt) {
        System.out.println("[MEGAN][AUDIO][CLIENTE] Recibido chunk streamId=" + pkt.streamId + ", chunkIndex=" + pkt.chunkIndex + "/" + pkt.totalChunks + ", tamaño=" + (pkt.opusData != null ? pkt.opusData.length : 0));
        streamChunks.computeIfAbsent(pkt.streamId, k -> new ArrayList<>()).add(pkt.opusData);
        streamMeta.put(pkt.streamId, pkt);
        if (streamChunks.get(pkt.streamId).size() == pkt.totalChunks) {
            int totalLen = 0;
            for (byte[] arr : streamChunks.get(pkt.streamId)) totalLen += arr.length;
            byte[] all = new byte[totalLen];
            int pos = 0;
            for (byte[] arr : streamChunks.get(pkt.streamId)) {
                System.arraycopy(arr, 0, all, pos, arr.length);
                pos += arr.length;
            }
            MeganAudioPacket meta = streamMeta.get(pkt.streamId);
            try {
                short[] pcm = OpusUtils.opusToPcm(all, meta.sampleRate, meta.channels);
                OpenALStreamingPlayer.playPCMStreamedWithDebug(
                    pcm, meta.sampleRate, meta.channels, meta.x, meta.y, meta.z, 100, 12
                );
            } catch (Exception e) {
                e.printStackTrace();
            }
            streamChunks.remove(pkt.streamId);
            streamMeta.remove(pkt.streamId);
        }
    }
}
