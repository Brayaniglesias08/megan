package com.ejemplo.npcai;

import net.minecraft.server.level.ServerPlayer;

/**
 * MeganVoiceManager: Sistema de gestión de voz para Megan (hook para ElevenLabs).
 * Arquitectura limpia y modular, lista para integración IA.
 */
public class MeganVoiceManager {
    private final MeganEntity megan;
    public MeganVoiceManager(MeganEntity megan) {
        this.megan = megan;
    }
    public void hablar(String texto, String emocion) {
        // Mapeo de emociones a voiceId y settings
        String voiceId = "n4x17EKVqyxfey8QMqvy"; // Voz base femenina
        org.json.JSONObject settings = new org.json.JSONObject();
        settings.put("stability", 0.5);
        settings.put("similarity_boost", 0.7);
        switch (emocion != null ? emocion : "") {
            case "feliz":
                settings.put("stability", 0.7);
                settings.put("similarity_boost", 0.8);
                break;
            case "triste":
                settings.put("stability", 0.3);
                settings.put("similarity_boost", 0.5);
                break;
            case "euforica":
                settings.put("stability", 0.8);
                settings.put("similarity_boost", 0.9);
                break;
            case "curiosa":
                settings.put("stability", 0.6);
                settings.put("similarity_boost", 0.8);
                break;
            case "valiente":
                settings.put("stability", 0.6);
                settings.put("similarity_boost", 0.7);
                break;
            case "reflexiva":
                settings.put("stability", 0.4);
                settings.put("similarity_boost", 0.6);
                break;
            case "divertida":
                settings.put("stability", 0.9);
                settings.put("similarity_boost", 0.95);
                break;
            case "cariñosa":
                settings.put("stability", 0.7);
                settings.put("similarity_boost", 0.95);
                break;
            case "neutral":
            default:
                // Defaults
                break;
        }
        ServerPlayer jugadorCerca = megan.level().players().stream()
                .filter(p -> p instanceof ServerPlayer)
                .map(p -> (ServerPlayer)p)
                .filter(p -> p.distanceTo(megan) < 16)
                .findFirst()
                .orElse(null);
        if (jugadorCerca != null) {
            ElevenLabsMP3Player.reproducir(texto, jugadorCerca);
        } else {
            for (net.minecraft.world.entity.player.Player p : megan.level().players()) {
                if (p instanceof ServerPlayer && p.distanceTo(megan) < 32) {
                    ElevenLabsMP3Player.reproducir(texto, (ServerPlayer)p);
                }
            }
        }
    }
}
