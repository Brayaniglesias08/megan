package com.ejemplo.npcai;

import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.event.server.ServerStoppingEvent;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Mod.EventBusSubscriber(modid = "meganai") // Usa solo este handler o ChatEventHandler, no ambos para evitar duplicidad
public class ChatVoiceHandler {

    // Grupo de hilos con 2 hilos en paralelo
    private static final ExecutorService executor = Executors.newFixedThreadPool(2);

    // Handler deshabilitado para evitar duplicidad de mensajes y audio.
// @SubscribeEvent
// public static void onChat(ServerChatEvent event) {
//     // Lógica deshabilitada.
// }

    // Método para cerrar el executor al detener el servidor
    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        shutdown();
    }

    public static void shutdown() {
        executor.shutdown();
        try {
            if (!executor.awaitTermination(5, java.util.concurrent.TimeUnit.SECONDS)) {
                executor.shutdownNow();
            }
        } catch (InterruptedException e) {
            executor.shutdownNow();
        }
    }
}