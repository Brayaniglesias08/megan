package com.ejemplo.npcai;

public class OpenALTest {
    public static void main(String[] args) {
        // Genera un tono PCM de prueba (440 Hz, 1 segundo, mono)
        int sampleRate = 48000;
        int duration = 1; // segundos
        short[] pcm = new short[sampleRate * duration];
        for (int i = 0; i < pcm.length; i++) {
            pcm[i] = (short) (Math.sin(2 * Math.PI * 440 * i / sampleRate) * Short.MAX_VALUE);
        }
        // Reproduce el tono en la posición (2, 0, 0) para probar audio posicional
        OpenALPositionalPlayer.playPCM(pcm, sampleRate, 1, 2f, 0f, 0f);
        // Espera un poco antes de limpiar recursos
        try { Thread.sleep(1200); } catch (InterruptedException ignored) {}
        OpenALPositionalPlayer.cleanup();
    }
}
