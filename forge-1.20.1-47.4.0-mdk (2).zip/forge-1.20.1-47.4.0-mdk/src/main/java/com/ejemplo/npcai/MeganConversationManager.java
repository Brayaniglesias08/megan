package com.ejemplo.npcai;

import java.util.*;

/**
 * Maneja el historial de conversación de Megan con cada jugador (en memoria).
 * Limita el historial a los últimos N turnos (pares usuario-Megan).
 */
public class MeganConversationManager {
    private static final int LIMITE_TURNOS = 5; // Cambia este valor si quieres más/menos contexto
    private static final Map<UUID, LinkedList<MensajeTurno>> historialPorJugador = new HashMap<>();

    public static class MensajeTurno {
        public final String rol; // "user" o "assistant"
        public final String contenido;
        public MensajeTurno(String rol, String contenido) {
            this.rol = rol;
            this.contenido = contenido;
        }
    }

    public static void agregarMensaje(UUID jugador, String rol, String contenido) {
        LinkedList<MensajeTurno> historial = historialPorJugador.computeIfAbsent(jugador, k -> new LinkedList<>());
        historial.add(new MensajeTurno(rol, contenido));
        // Limitar a los últimos LIMITE_TURNOS*2 mensajes (pares usuario-Megan)
        while (historial.size() > LIMITE_TURNOS * 2) {
            historial.removeFirst();
        }
    }

    public static List<MensajeTurno> obtenerHistorial(UUID jugador) {
        return historialPorJugador.getOrDefault(jugador, new LinkedList<>());
    }

    public static void limpiarHistorial(UUID jugador) {
        historialPorJugador.remove(jugador);
    }
}
