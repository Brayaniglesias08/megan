package com.ejemplo.npcai;

import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = "meganai")
public class CommonEvents {
    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        ComandoSpawnMegan.register(event.getDispatcher());
    }

    // Manejar mensajes de chat para comandos naturales a Megan
    @SubscribeEvent
    public static void onPlayerChat(ServerChatEvent event) {
        String mensaje = event.getMessage().getString();
        net.minecraft.server.level.ServerPlayer jugador = event.getPlayer();
        int count = 0;
        for (var megan : jugador.level().getEntitiesOfClass(com.ejemplo.npcai.MeganEntity.class, jugador.getBoundingBox().inflate(32))) {
            megan.processPlayerMessage(mensaje, jugador);
            count++;
        }
        if (count == 0) {
        }
    }
}
