package com.ejemplo.npcai;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.Clip;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.AudioFileFormat;
import javax.sound.sampled.Clip;


import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class PlayAudioPacket {
    private final byte[] audioData;
    private final double x, y, z;

    public PlayAudioPacket(byte[] audioData, double x, double y, double z) {
        this.audioData = audioData;
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public PlayAudioPacket(FriendlyByteBuf buf) {
        int length = buf.readInt();
        this.audioData = new byte[length];
        buf.readBytes(this.audioData);
        this.x = buf.readDouble();
        this.y = buf.readDouble();
        this.z = buf.readDouble();
    }

    public void toBytes(FriendlyByteBuf buf) {
        buf.writeInt(audioData.length);
        buf.writeBytes(audioData);
        buf.writeDouble(x);
        buf.writeDouble(y);
        buf.writeDouble(z);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            try {
                // Guardar WAV recibido para depuración
                try {
                    java.nio.file.Files.write(java.nio.file.Paths.get("C:/Users/Brayan Iglesias/Desktop/test_megan.wav"), audioData);
                } catch (Exception e) {
                }
                // Decodificar el WAV y reproducirlo usando OpenALPlayer
try (AudioInputStream ais = AudioSystem.getAudioInputStream(new ByteArrayInputStream(audioData))) {
                    AudioFormat format = ais.getFormat();
                    byte[] pcmBytes = ais.readAllBytes();
                    OpenALPlayer.play(pcmBytes, format, (float)x, (float)y, (float)z);
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        ctx.get().setPacketHandled(true);
    }

    private void playWavInMinecraft(File wavFile) {
        try {
            // Carga el archivo WAV y lo reproduce usando Java Sound
            AudioInputStream audioInputStream = javax.sound.sampled.AudioSystem.getAudioInputStream(wavFile);
            Clip clip = javax.sound.sampled.AudioSystem.getClip();
            clip.open(audioInputStream);
            clip.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Utilidad para convertir MP3 a WAV usando Java Sound
    private void convertMp3ToWav(File mp3, File wav) throws Exception {
        try (
            FileInputStream fis = new FileInputStream(mp3);
            BufferedInputStream bis = new BufferedInputStream(fis);
            AudioInputStream mp3Stream = javax.sound.sampled.AudioSystem.getAudioInputStream(bis)
        ) {
            AudioFormat baseFormat = mp3Stream.getFormat();
            AudioFormat decodedFormat = new AudioFormat(
                AudioFormat.Encoding.PCM_SIGNED,
                baseFormat.getSampleRate(),
                16,
                baseFormat.getChannels(),
                baseFormat.getChannels() * 2,
                baseFormat.getSampleRate(),
                false
            );
            AudioInputStream decodedAudioInputStream = javax.sound.sampled.AudioSystem.getAudioInputStream(decodedFormat, mp3Stream);
            javax.sound.sampled.AudioSystem.write(decodedAudioInputStream, AudioFileFormat.Type.WAVE, wav);
        }
    }

    public byte[] getAudioData() {
        return audioData;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getZ() {
        return z;
    }
}

