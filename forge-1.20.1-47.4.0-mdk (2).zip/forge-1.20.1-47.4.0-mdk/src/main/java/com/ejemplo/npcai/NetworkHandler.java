package com.ejemplo.npcai;

import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkEvent;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

import java.util.function.Supplier;

public class NetworkHandler {
    private static final String PROTOCOL_VERSION = "1";
    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation("megan:audio_channel"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    public static void registerMessages() {
        CHANNEL.registerMessage(0, AudioMessage.class, AudioMessage::encode, AudioMessage::decode, AudioMessage::handle);
        CHANNEL.registerMessage(1, AudioFragmentMessage.class, AudioFragmentMessage::encode, AudioFragmentMessage::decode, AudioFragmentMessage::handle);
    }

    public static class AudioMessage {
        private final byte[] audioData;

        public AudioMessage(byte[] audioData) {
            this.audioData = audioData;
        }

        public static void encode(AudioMessage msg, FriendlyByteBuf buf) {
            buf.writeByteArray(msg.audioData);
        }

        public static AudioMessage decode(FriendlyByteBuf buf) {
            return new AudioMessage(buf.readByteArray());
        }

        public static void handle(AudioMessage msg, Supplier<NetworkEvent.Context> ctx) {
            ctx.get().enqueueWork(() -> {
                try {
                    Minecraft minecraft = Minecraft.getInstance();
                    if (minecraft.player != null) {
                        // Reproducir el audio dinámico usando OpenALPlayer (audio posicional)
                        // Se ha eliminado la llamada a play(sound) y se utiliza correctamente OpenALPlayer para reproducir el audio dinámico
                        OpenALPlayer.playOgg(
                            msg.getAudioData(),
                            (float) minecraft.player.getX(),
                            (float) minecraft.player.getY(),
                            (float) minecraft.player.getZ()
                        );
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            });
            ctx.get().setPacketHandled(true);
        }

        public byte[] getAudioData() {
            return audioData;
        }
    }
}