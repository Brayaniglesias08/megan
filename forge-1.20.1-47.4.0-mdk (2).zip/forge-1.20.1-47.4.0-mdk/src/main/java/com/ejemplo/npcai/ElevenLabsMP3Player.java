package com.ejemplo.npcai;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.PacketDistributor;
import java.util.Comparator;

import java.io.*;

public class ElevenLabsMP3Player {

    public static void reproducir(String texto, ServerPlayer player) {
        // Solo permitir en el servidor
        if (player.getServer() == null) {
            System.err.println("[MEGAN][ERROR] ¡Intento de síntesis de voz en el cliente! Esto solo debe ocurrir en el servidor.");
            return;
        }
        try {
            // 1. Obtener los bytes de audio MP3 desde ElevenLabs
            byte[] audioData = ElevenLabsClient.generarAudio(texto);

            // 2. Guardar el MP3 temporalmente
            File mp3File = File.createTempFile("megan_voice", ".mp3");
            try (FileOutputStream fos = new FileOutputStream(mp3File)) {
                fos.write(audioData);
            }

            // 3. Convertir MP3 a OGG usando AudioConversionUtil
            File oggFile = File.createTempFile("megan_voice", ".ogg");
            AudioConversionUtil.convertToOgg(mp3File, oggFile);

            // 4. Leer el OGG como bytes
            byte[] oggBytes;
            try (FileInputStream fis = new FileInputStream(oggFile)) {
                oggBytes = fis.readAllBytes();
            }

            // 5. Enviar el OGG al cliente
            // Buscar a Megan cerca del jugador
            MeganEntity megan = player.level().getEntitiesOfClass(MeganEntity.class,
                player.getBoundingBox().inflate(64.0))
                .stream()
                .min(Comparator.comparingDouble(e -> e.distanceTo(player)))
                .orElse(null);
            double mx = player.getX(), my = player.getY(), mz = player.getZ();
            if (megan != null) {
                mx = megan.getX();
                my = megan.getY();
                mz = megan.getZ();
            }
            ModNetwork.INSTANCE.send(
                PacketDistributor.PLAYER.with(() -> player),
                new PlayAudioPacket(oggBytes, mx, my, mz)
            );

            // Limpieza de archivos temporales
            mp3File.delete();
            oggFile.delete();

            System.out.println("✅ Audio OGG enviado al cliente para reproducción posicional.");

        } catch (Exception e) {
            e.printStackTrace();
            player.sendSystemMessage(
                net.minecraft.network.chat.Component.literal("❌ Error al reproducir el audio: " + e.getMessage())
            );
        }
    }

    // Método opcional: Convertir MP3 a PCM si es necesario
    public static byte[] convertirMP3aPCM(byte[] mp3Data) throws Exception {
        // Usa JLayer para decodificar MP3 a PCM
        // Nota: Necesitas agregar lógica para convertir MP3 a PCM usando JLayer, ya que tienes la dependencia 'javazoom:jlayer:1.0.1'
        // Este es un ejemplo simplificado; necesitarías implementar la conversión real.
        return mp3Data; // Placeholder; reemplaza con la conversión real
    }
}