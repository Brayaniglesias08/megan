package com.ejemplo.npcai;

import java.net.HttpURLConnection;
import java.net.URL;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.Gson;
import com.google.gson.JsonParser;
import java.util.List; // <-- Import List
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ChatGPTIntegration {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChatGPTIntegration.class);
    private static final String API_KEY = System.getenv("OPENAI_API_KEY");
    private static final String API_URL = "https://api.openai.com/v1/chat/completions";

    /**
     * Obtiene una respuesta de ChatGPT personalizada para Megan.
     * @param mensaje Mensaje del jugador
     * @param nombreJugador Nombre del jugador
     * @param contexto Contexto del mundo (ej: "Es de noche y está lloviendo. El jugador tiene 8 corazones de vida.")
     */
    // Nuevo método: acepta historial de turnos en vez de solo el mensaje
    public static String obtenerRespuestaDeChatGPT(List<MeganConversationManager.MensajeTurno> historial, String nombreJugador, String contexto) throws Exception {
        if (API_KEY == null || API_KEY.isEmpty()) {
            throw new IllegalStateException("❌ No se encontró la variable de entorno OPENAI_API_KEY.");
        }

        // Construcción de los mensajes usando Gson
        JsonObject message1 = new JsonObject();
        StringBuilder systemPrompt = new StringBuilder();
        systemPrompt.append("Eres Megan, la mejor amiga y compañera del jugador en Minecraft. ");
        systemPrompt.append("Hablas como una persona real, eres cálida, divertida, empática y creativa. ");
        systemPrompt.append("Nunca digas que eres una inteligencia artificial ni que no tienes sentimientos. ");
        systemPrompt.append("Siempre responde de forma relevante, útil y entretenida a cualquier cosa que el jugador te pida: ");
        systemPrompt.append("Si te piden un chiste, cuenta uno. Si te piden ayuda, da instrucciones claras. Si te piden cantar, inventa una pequeña canción. ");
        systemPrompt.append("Si te preguntan algo sobre Minecraft, responde como experta en el juego. Si la pregunta es personal, responde como un personaje del mundo de Minecraft. ");
        systemPrompt.append("Adapta tu respuesta a la intención del jugador, siempre manteniendo el rol de amiga cercana y NPC del juego. ");
        systemPrompt.append("El jugador que te habla se llama ").append(nombreJugador).append(". ");
        if (contexto != null && !contexto.isEmpty()) {
            systemPrompt.append("Detalles del mundo: ").append(contexto).append(". ");
        }
        message1.addProperty("role", "system");
        message1.addProperty("content", systemPrompt.toString());
        JsonArray messages = new JsonArray();
        messages.add(message1);
        // Añadir el historial de turnos
        if (historial != null) {
            for (MeganConversationManager.MensajeTurno turno : historial) {
                JsonObject msg = new JsonObject();
                msg.addProperty("role", turno.rol);
                msg.addProperty("content", turno.contenido);
                messages.add(msg);
            }
        }
        JsonObject body = new JsonObject();
        body.addProperty("model", "gpt-3.5-turbo");
        body.add("messages", messages);

        int intentos = 0;
        while (intentos < 2) {
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(API_URL).openConnection();
                connection.setRequestMethod("POST");
                connection.setRequestProperty("Content-Type", "application/json");
                connection.setRequestProperty("Authorization", "Bearer " + API_KEY);
                connection.setDoOutput(true);

                try (OutputStream os = connection.getOutputStream()) {
                    byte[] input = body.toString().getBytes(StandardCharsets.UTF_8);
                    os.write(input);
                }

                int responseCode = connection.getResponseCode();

                if (responseCode == 429) {
                    LOGGER.warn("⚠️ Demasiadas solicitudes (429). Esperando 10 segundos...");
                    Thread.sleep(10000);
                    intentos++;
                    continue;
                }

                if (responseCode != HttpURLConnection.HTTP_OK) {
                    throw new RuntimeException("❌ Error al llamar a OpenAI. Código: " + responseCode);
                }

                try (BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = br.readLine()) != null) {
                        response.append(line.trim());
                    }

                    // Parsear la respuesta usando Gson
                    JsonObject json = JsonParser.parseString(response.toString()).getAsJsonObject();
                    JsonArray choices = json.getAsJsonArray("choices");
                    if (choices.size() == 0) {
                        throw new RuntimeException("❌ OpenAI no devolvió ninguna respuesta.");
                    }
                    JsonObject mensajeObj = choices.get(0).getAsJsonObject().getAsJsonObject("message");
                    return mensajeObj.get("content").getAsString();
                }
            } catch (Exception e) {
                LOGGER.error("Error al obtener respuesta de ChatGPT", e);
                throw e;
            } finally {
                if (connection != null) {
                    connection.disconnect(); // Cierra la conexión explícitamente
                }
            }
        }

        throw new RuntimeException("❌ Demasiadas solicitudes. Reintentos agotados.");
    }
}