package com.ejemplo.npcai;

import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.Container;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ChestBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.gameevent.GameEvent;

import java.util.EnumSet;

public class MeganDepositItemsGoal extends net.minecraft.world.entity.ai.goal.Goal {
    private final MeganEntity megan;
    private BlockPos chestPos;
    private Player owner;
    private Container chestContainer;
    private boolean isDepositing;
    private int timer;

    public MeganDepositItemsGoal(MeganEntity megan) {
        super();
        this.megan = megan;
        // this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); // Comentado: no existe Flag ni setFlags en Goal estándar
        this.isDepositing = false;
        this.timer = 0;
    }

    @Override
    public boolean canUse() {
        return megan.isInventoryFull() && (megan.getChestPos() != null || megan.getOwnerPlayer() != null);
    }

    @Override
    public void start() {
        this.chestPos = megan.getChestPos();
        this.owner = megan.getOwnerPlayer();
        this.isDepositing = false;
        this.timer = 0;
        if (chestPos != null) {
            this.chestContainer = getContainer(chestPos);
            if (chestContainer == null) {
                megan.sendFeedbackToOwner("No encuentro el cofre asignado. Regresando al jugador.");
                megan.clearChestPos();
                this.chestPos = null;
            }
        }
    }

    @Override
    public void tick() {
        if (chestPos != null && chestContainer != null) {
            megan.getNavigation().moveTo(chestPos.getX() + 0.5, chestPos.getY() + 1, chestPos.getZ() + 0.5, 1.1);
            if (chestPos.closerThan(megan.blockPosition(), 2.5)) {
                megan.getNavigation().stop();
                openChest(true);
                depositItems();
                reabastecerDeCofre();
                openChest(false);
                megan.sendFeedbackToOwner("¡Depósito completado! Regresando a minar.");
                megan.resetInventoryFullFlag();
                isDepositing = true;
                timer = 20;
            }
        } else if (owner != null) {
            // Regresar al jugador
            BlockPos ownerPos = owner.blockPosition();
            megan.getNavigation().moveTo(ownerPos.getX() + 0.5, ownerPos.getY(), ownerPos.getZ() + 0.5, 1.1);
            if (ownerPos.closerThan(megan.blockPosition(), 2.5)) {
                megan.getNavigation().stop();
                megan.sendFeedbackToOwner("¡Inventario lleno! Deposita los objetos al jugador.");
                megan.depositItemsToPlayer(owner);
                megan.resetInventoryFullFlag();
                isDepositing = true;
                timer = 20;
            }
        }
        if (isDepositing && timer > 0) {
            timer--;
            if (timer == 0) {
                megan.setStateMining();
            }
        }
    }

    private Container getContainer(BlockPos chestPos) {
        BlockEntity be = megan.level().getBlockEntity(chestPos);
        if (be instanceof ChestBlockEntity chest) {
            return chest;
        }
        return null;
    }

    private void openChest(boolean open) {
        if (chestPos == null) return;
        BlockState state = megan.level().getBlockState(chestPos);
        if (open) {
            megan.level().blockEvent(chestPos, state.getBlock(), 1, 1);
            megan.level().playSound(null, chestPos, SoundEvents.CHEST_OPEN, megan.getSoundSource(), 0.7F, 0.9F);
        } else {
            megan.level().blockEvent(chestPos, state.getBlock(), 1, 0);
            megan.level().playSound(null, chestPos, SoundEvents.CHEST_CLOSE, megan.getSoundSource(), 0.7F, 0.9F);
        }
        megan.level().gameEvent(megan, open ? GameEvent.BLOCK_OPEN : GameEvent.BLOCK_CLOSE, chestPos);
    }

    private void depositItems() {
        SimpleContainer inv = megan.getInventory();
        if (isContainerFull(chestContainer)) {
            megan.sendFeedbackToOwner("¡El cofre está lleno!");
            return;
        }
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack stack = inv.getItem(i);
            if (stack.isEmpty() || megan.wantsToKeep(stack)) continue;
            ItemStack remainder = depositStack(stack, chestContainer);
            inv.setItem(i, remainder);
        }
    }

    private boolean isContainerFull(Container container) {
        for (int i = 0; i < container.getContainerSize(); i++) {
            if (container.getItem(i).isEmpty()) return false;
        }
        return true;
    }

    private ItemStack depositStack(ItemStack stack, Container container) {
        for (int i = 0; i < container.getContainerSize(); i++) {
            ItemStack target = container.getItem(i);
            if (target.is(stack.getItem())) {
                int toDeposit = Math.min(stack.getCount(), target.getMaxStackSize() - target.getCount());
                target.grow(toDeposit);
                stack.shrink(toDeposit);
                container.setItem(i, target);
                if (stack.isEmpty()) return ItemStack.EMPTY;
            }
        }
        for (int i = 0; i < container.getContainerSize(); i++) {
            ItemStack target = container.getItem(i);
            if (target.isEmpty()) {
                container.setItem(i, stack);
                return ItemStack.EMPTY;
            }
        }
        return stack;
    }

    private void reabastecerDeCofre() {
        if (chestContainer == null) return;
        MeganEntity.Reabastecimiento[] items = MeganEntity.Reabastecimiento.values();
        for (MeganEntity.Reabastecimiento item : items) {
            if (megan.needsItem(item)) {
                for (int i = 0; i < chestContainer.getContainerSize(); i++) {
                    ItemStack stack = chestContainer.getItem(i);
                    if (item.matches(stack)) {
                        megan.getInventory().addItem(stack.copy());
                        stack.shrink(1);
                        break;
                    }
                }
            }
        }
    }
}
