package com.ejemplo.npcai;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber;
import net.minecraftforge.fml.common.Mod.EventBusSubscriber.Bus;

@EventBusSubscriber(modid = "npcai", bus = Bus.FORGE, value = Dist.CLIENT)
public class MeganVoiceOverlay {
    private static final ResourceLocation ICON_MIC = new ResourceLocation("npcai:textures/gui/mic_on.png");

    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        if (MeganVoiceInput.isRecording()) {
            Minecraft mc = Minecraft.getInstance();
            int x = 10;
            int y = 10;
            // Usa GuiGraphics en Forge 1.20.1
            net.minecraft.client.gui.GuiGraphics gfx = event.getGuiGraphics();
            // Dibuja el ícono del micrófono
            gfx.blit(ICON_MIC, x, y, 0, 0, 16, 16, 16, 16);
            // Dibuja el texto
            gfx.drawString(mc.font, "Grabando...", x + 20, y + 4, 0xFF00FF00, false);
        }
    }
}
