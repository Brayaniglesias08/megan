package com.ejemplo.npcai;

import com.mojang.brigadier.CommandDispatcher;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import java.util.List;

/**
 * Comando personalizado para llamar a Megan: /megan ven
 * Busca la MeganEntity más cercana y la pone en modo seguimiento hacia el jugador.
 */
public class ComandoMeganVen {
    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("megan")
            .then(Commands.literal("ven")
                .executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    List<MeganEntity> megans = new java.util.ArrayList<>();
                    for (var level : player.server.getAllLevels()) {
                        megans.addAll(level.getEntitiesOfClass(MeganEntity.class, level.getWorldBorder().getCollisionShape().bounds()));
                    }
                    if (megans.isEmpty()) {
                        ctx.getSource().sendFailure(net.minecraft.network.chat.Component.literal("No hay ninguna Megan para llamar."));
                        return 0;
                    }
                    MeganEntity megan = megans.get(0);
                    for (int i = 1; i < megans.size(); i++) {
                        megans.get(i).discard();
                        System.out.println("[NpcAIMod] Megan duplicada eliminada por /megan ven.");
                    }
                    megan.setEnModoSeguir(true);
                    megan.setObjetivoJugador(player);
                    ctx.getSource().sendSuccess(() -> net.minecraft.network.chat.Component.literal("¡Megan ahora viene hacia ti!"), false);
                    return 1;
                })
            )
            .then(Commands.literal("para")
                .executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    List<MeganEntity> megans = new java.util.ArrayList<>();
                    for (var level : player.server.getAllLevels()) {
                        megans.addAll(level.getEntitiesOfClass(MeganEntity.class, level.getWorldBorder().getCollisionShape().bounds()));
                    }
                    if (megans.isEmpty()) {
                        ctx.getSource().sendFailure(net.minecraft.network.chat.Component.literal("No hay ninguna Megan cerca."));
                        return 0;
                    }
                    MeganEntity megan = megans.get(0);
                    megan.setEnModoSeguir(false);
                    megan.setObjetivoJugador(null);
                    megan.getNavigation().stop();
                    ctx.getSource().sendSuccess(() -> net.minecraft.network.chat.Component.literal("¡Megan se detiene!"), false);
                    return 1;
                })
            )
            .then(Commands.literal("adios")
                .executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    List<MeganEntity> megans = new java.util.ArrayList<>();
                    for (var level : player.server.getAllLevels()) {
                        megans.addAll(level.getEntitiesOfClass(MeganEntity.class, level.getWorldBorder().getCollisionShape().bounds()));
                    }
                    if (megans.isEmpty()) {
                        ctx.getSource().sendFailure(net.minecraft.network.chat.Component.literal("No hay ninguna Megan cerca."));
                        return 0;
                    }
                    MeganEntity megan = megans.get(0);
                    megan.setEnModoSeguir(false);
                    megan.setObjetivoJugador(null);
                    megan.getNavigation().stop();
                    ctx.getSource().sendSuccess(() -> net.minecraft.network.chat.Component.literal("¡Megan se despide y se detiene!"), false);
                    return 1;
                })
            )
            .then(Commands.literal("chao")
                .executes(ctx -> {
                    ServerPlayer player = ctx.getSource().getPlayerOrException();
                    List<MeganEntity> megans = new java.util.ArrayList<>();
                    for (var level : player.server.getAllLevels()) {
                        megans.addAll(level.getEntitiesOfClass(MeganEntity.class, level.getWorldBorder().getCollisionShape().bounds()));
                    }
                    if (megans.isEmpty()) {
                        ctx.getSource().sendFailure(net.minecraft.network.chat.Component.literal("No hay ninguna Megan cerca."));
                        return 0;
                    }
                    MeganEntity megan = megans.get(0);
                    megan.setEnModoSeguir(false);
                    megan.setObjetivoJugador(null);
                    megan.getNavigation().stop();
                    ctx.getSource().sendSuccess(() -> net.minecraft.network.chat.Component.literal("¡Megan dice chao y se detiene!"), false);
                    return 1;
                })
            )
        );
    }
}
