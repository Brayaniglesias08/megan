package com.ejemplo.npcai;

import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.entity.animal.IronGolem;
import java.util.EnumSet;
import java.util.List;

public class MeganAttackHostileGoal extends Goal {
    private final PathfinderMob megan;
    private LivingEntity target;
    private int attackCooldown = 0;

    public MeganAttackHostileGoal(PathfinderMob megan) {
        this.megan = megan;
        this.setFlags(EnumSet.of(Goal.Flag.TARGET, Goal.Flag.MOVE));
    }

    @Override
    public boolean canUse() {
        // Buscar mobs hostiles cercanos
        List<LivingEntity> entities = megan.level().getEntitiesOfClass(LivingEntity.class, megan.getBoundingBox().inflate(12.0),
            e -> e instanceof Monster && !(e instanceof Villager) && !(e instanceof IronGolem) && e.isAlive() && !e.isAlliedTo(megan));
        if (!entities.isEmpty()) {
            target = entities.get(0);
            return true;
        }
        return false;
    }

    @Override
    public boolean canContinueToUse() {
        return target != null && target.isAlive() && megan.distanceTo(target) < 16.0;
    }

    @Override
    public void start() {
        attackCooldown = 0;
    }

    @Override
    public void stop() {
        target = null;
    }

    @Override
    public void tick() {
        if (target == null) return;
        megan.getLookControl().setLookAt(target, 30.0F, 30.0F);
        megan.getNavigation().moveTo(target, 1.2);
        if (megan.distanceTo(target) < 2.5 && attackCooldown <= 0) {
            // Equipar mejor espada antes de atacar
            if (megan instanceof com.ejemplo.npcai.MeganEntity meganEntity) {
                net.minecraft.world.item.ItemStack bestWeapon = null;
                String tipo = null;
                for (int i = 0; i < meganEntity.getInventory().getContainerSize(); i++) {
                    net.minecraft.world.item.ItemStack stack = meganEntity.getInventory().getItem(i);
                    if (!stack.isEmpty()) {
                        if (com.ejemplo.npcai.ToolUtil.isSword(stack)) {
                            if (bestWeapon == null || com.ejemplo.npcai.ToolUtil.compareTools(stack, bestWeapon) < 0) {
                                bestWeapon = stack;
                                tipo = "espada";
                            }
                        } else if (com.ejemplo.npcai.ToolUtil.isAxe(stack)) {
                            if (bestWeapon == null || (!tipo.equals("espada") && com.ejemplo.npcai.ToolUtil.compareTools(stack, bestWeapon) < 0)) {
                                bestWeapon = stack;
                                tipo = "hacha";
                            }
                        } else if (com.ejemplo.npcai.ToolUtil.isPickaxe(stack)) {
                            if (bestWeapon == null || ((!tipo.equals("espada") && !tipo.equals("hacha")) && com.ejemplo.npcai.ToolUtil.compareTools(stack, bestWeapon) < 0)) {
                                bestWeapon = stack;
                                tipo = "pico";
                            }
                        } else if (com.ejemplo.npcai.ToolUtil.isShovel(stack)) {
                            if (bestWeapon == null || ((!tipo.equals("espada") && !tipo.equals("hacha") && !tipo.equals("pico")) && com.ejemplo.npcai.ToolUtil.compareTools(stack, bestWeapon) < 0)) {
                                bestWeapon = stack;
                                tipo = "pala";
                            }
                        }
                    }
                }
                if (bestWeapon != null && !meganEntity.getMainHandItem().equals(bestWeapon)) {
                    meganEntity.setItemInHand(net.minecraft.world.InteractionHand.MAIN_HAND, bestWeapon);
                    System.out.println("[DEPURACIÓN][MEGAN] Equipando " + tipo + ": " + bestWeapon.getDisplayName().getString());
                }
            }
            megan.swing(net.minecraft.world.InteractionHand.MAIN_HAND, true);
            megan.level().broadcastEntityEvent(megan, (byte) 4);
            megan.doHurtTarget(target);
            attackCooldown = 20; // 1 segundo entre ataques
        }
        if (attackCooldown > 0) attackCooldown--;
    }
}
