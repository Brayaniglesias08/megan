package com.ejemplo.npcai;

import net.minecraft.world.entity.Entity;
import org.lwjgl.openal.AL10;

public class SoundFollowEntity {
    private final int sourceId;
    private final int bufferId;
    private final Entity entity;

    public SoundFollowEntity(int sourceId, int bufferId, Entity entity) {
        this.sourceId = sourceId;
        this.bufferId = bufferId;
        this.entity = entity;
    }

    public void updatePosition() {
        if (entity != null && entity.isAlive()) {
            AL10.alSource3f(sourceId, AL10.AL_POSITION, (float)entity.getX(), (float)entity.getY(), (float)entity.getZ());
        }
    }

    public boolean isPlaying() {
        int state = AL10.alGetSourcei(sourceId, AL10.AL_SOURCE_STATE);
        return state == AL10.AL_PLAYING;
    }

    public void cleanup() {
        AL10.alDeleteSources(sourceId);
        AL10.alDeleteBuffers(bufferId);
    }

    public Entity getEntity() {
        return entity;
    }
}
