package com.ejemplo.npcai;

import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.phys.Vec3;
import java.util.EnumSet;

/**
 * Goal personalizado para que Megan siga a un jugador objetivo.
 */
// ============================
// ¡NO MODIFICAR!
// Lógica crítica de seguimiento de Megan.
// Si necesitas cambiar el comportamiento, consulta primero con Brayan.
// DO NOT MODIFY!
// Critical logic for Megan's following behavior.
// If you need to change this, consult Brayan first.
// ============================
public class MeganFollowPlayerGoal extends Goal {
    private final MeganEntity megan;
    private ServerPlayer objetivo;
    private final double speed;
    private final float stopDistance;

    // --- Mejoras de robustez ---
    private int stuckTicks = 0;
    private double lastDist = -1;
    private static final int MAX_STUCK_TICKS = 40; // 2 segundos si tick es 20 TPS
    private static final float SAFE_DISTANCE = 1.2f; // Nunca acercarse más que esto

    public MeganFollowPlayerGoal(MeganEntity megan, double speed, float stopDistance) {
        this.megan = megan;
        this.speed = speed;
        this.stopDistance = stopDistance;
        this.setFlags(EnumSet.of(Goal.Flag.MOVE));
    }

    private static final org.slf4j.Logger LOGGER = org.slf4j.LoggerFactory.getLogger("MeganAI");
    /**
     * ============================
     * ¡NO MODIFICAR ESTE MÉTODO!
     * Lógica crítica de decisión de seguimiento de Megan.
     * Si necesitas cambiarlo, documenta el motivo y consulta primero con Brayan.
     * DO NOT MODIFY THIS METHOD!
     * Critical logic for Megan's follow decision.
     * If you must change it, document the reason and consult Brayan first.
     * ============================
     */
    @Override
    public boolean canUse() {
        boolean seguir = megan.isEnModoSeguir();
        objetivo = megan.getObjetivoJugador();
        boolean objetivoValido = (objetivo != null && objetivo.isAlive());

        return seguir && objetivoValido;
    }

    /**
     * ============================
     * ¡NO MODIFICAR ESTE MÉTODO!
     * Lógica crítica de inicio de seguimiento de Megan.
     * Si necesitas cambiarlo, documenta el motivo y consulta primero con Brayan.
     * DO NOT MODIFY THIS METHOD!
     * Critical logic for Megan's follow start.
     * If you must change it, document the reason and consult Brayan first.
     * ============================
     */
    @Override
    public void start() {
        objetivo = megan.getObjetivoJugador();

        stuckTicks = 0;
        lastDist = -1;
    }

    /**
     * ============================
     * ¡NO MODIFICAR ESTE MÉTODO!
     * Lógica crítica de detención de seguimiento de Megan.
     * Si necesitas cambiarlo, documenta el motivo y consulta primero con Brayan.
     * DO NOT MODIFY THIS METHOD!
     * Critical logic for Megan's follow stop.
     * If you must change it, document the reason and consult Brayan first.
     * ============================
     */
    @Override
    public void stop() {

        objetivo = null;
        megan.getNavigation().stop();
        stuckTicks = 0;
        lastDist = -1;
    }

    /**
     * ============================
     * ¡NO MODIFICAR ESTE MÉTODO!
     * Lógica crítica de actualización de seguimiento de Megan.
     * Si necesitas cambiarlo, documenta el motivo y consulta primero con Brayan.
     * DO NOT MODIFY THIS METHOD!
     * Critical logic for Megan's follow update.
     * If you must change it, document the reason and consult Brayan first.
     * ============================
     */
    @Override
    public void tick() {

        if (objetivo == null || !objetivo.isAlive()) {
            megan.getNavigation().stop();

            return;
        }
        double dist = megan.distanceTo(objetivo);
        // Log solo si cambia el estado
        if ((int)dist != (int)lastDist) {
            LOGGER.debug("[MEGAN][DEBUG][FollowGoal] tick: objetivo={}, distancia={}", objetivo.getName().getString(), dist);
        }

        // 1. Evitar empujar/bloquear al jugador
        if (dist < SAFE_DISTANCE) {
            megan.getNavigation().stop();
            // Retroceder un poco si está demasiado cerca, pero solo si el vector es válido
            Vec3 dir = megan.position().subtract(objetivo.position());
            if (dir.lengthSqr() > 1e-6) {
                dir = dir.normalize();
                Vec3 retroceso = megan.position().add(dir.scale(0.5));
                if (!Double.isNaN(retroceso.x) && !Double.isNaN(retroceso.y) && !Double.isNaN(retroceso.z)
                        && Double.isFinite(retroceso.x) && Double.isFinite(retroceso.y) && Double.isFinite(retroceso.z)) {
                    megan.getMoveControl().setWantedPosition(retroceso.x, retroceso.y, retroceso.z, 0.7);
                } else {

                }
            } else {

            }
            stuckTicks = 0;
            lastDist = dist;
            return;
        }

        // 2. Si está suficientemente cerca, detener navegación
        if (dist <= stopDistance) {
            megan.getNavigation().stop();
            stuckTicks = 0;
            lastDist = dist;
            return;
        }

        // 3. Si está lejos, seguir al jugador
        if (!megan.getNavigation().isInProgress()) {
            megan.getNavigation().moveTo(objetivo, speed);
        }

        // 4. Manejo de atascos
        if (lastDist >= 0) {
            if (Math.abs(dist - lastDist) < 0.05) {
                stuckTicks++;
                if (stuckTicks > MAX_STUCK_TICKS) {

                    megan.getNavigation().stop();
                    megan.getNavigation().moveTo(objetivo, speed);
                    stuckTicks = 0;
                }
            } else {
                stuckTicks = 0;
            }
        }
        lastDist = dist;
    }
}
