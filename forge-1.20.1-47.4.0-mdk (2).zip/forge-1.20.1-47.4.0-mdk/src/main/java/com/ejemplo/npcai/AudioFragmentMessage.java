package com.ejemplo.npcai;

import net.minecraft.client.Minecraft;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class AudioFragmentMessage {
    private int streamId;
    private int fragmentIndex;
    private int totalFragments;
    private byte[] fragmentData;
    private double mx, my, mz;

    public AudioFragmentMessage(int streamId, int fragmentIndex, int totalFragments, byte[] fragmentData, double mx, double my, double mz) {
        this.streamId = streamId;
        this.fragmentIndex = fragmentIndex;
        this.totalFragments = totalFragments;
        this.fragmentData = fragmentData;
        this.mx = mx;
        this.my = my;
        this.mz = mz;
    }

    public static void encode(AudioFragmentMessage msg, FriendlyByteBuf buf) {
        buf.writeInt(msg.streamId);
        buf.writeInt(msg.fragmentIndex);
        buf.writeInt(msg.totalFragments);
        buf.writeInt(msg.fragmentData.length);
        buf.writeByteArray(msg.fragmentData);
        buf.writeDouble(msg.mx);
        buf.writeDouble(msg.my);
        buf.writeDouble(msg.mz);
    }

    public static AudioFragmentMessage decode(FriendlyByteBuf buf) {
        int streamId = buf.readInt();
        int fragmentIndex = buf.readInt();
        int totalFragments = buf.readInt();
        int length = buf.readInt();
        byte[] fragmentData = buf.readByteArray(length);
        double mx = buf.readDouble();
        double my = buf.readDouble();
        double mz = buf.readDouble();
        return new AudioFragmentMessage(streamId, fragmentIndex, totalFragments, fragmentData, mx, my, mz);
    }

    public static void handle(AudioFragmentMessage msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            // Aquí se implementará la lógica de ensamblaje en el cliente
            AudioFragmentAssembler.receiveFragment(msg);
        });
        ctx.get().setPacketHandled(true);
    }

    public int getStreamId() { return streamId; }
    public int getFragmentIndex() { return fragmentIndex; }
    public int getTotalFragments() { return totalFragments; }
    public byte[] getFragmentData() { return fragmentData; }
    public double getMx() { return mx; }
    public double getMy() { return my; }
    public double getMz() { return mz; }
}
