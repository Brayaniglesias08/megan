package com.ejemplo.npcai;

import de.maxhenkel.opus4j.OpusDecoder;
import javax.sound.sampled.AudioFormat;
import java.nio.ByteBuffer;

/**
 * Decodifica audio Opus a PCM y lo reproduce usando OpenALPlayer.
 * Comentarios en español.
 */
public class OpusDecoderPlayer {
    /**
     * Decodifica un buffer Opus a PCM y lo reproduce usando OpenALPlayer.
     * @param opusData   Datos de audio en formato Opus
     * @param sampleRate Frecuencia de muestreo (ej. 24000)
     * @param channels   Número de canales (ej. 1 para mono)
     * @param x          Posición X para OpenAL
     * @param y          Posición Y para OpenAL
     * @param z          Posición Z para OpenAL
     */
    /**
     * Decodifica un buffer Opus a PCM y lo reproduce usando OpenALPlayer.
     * @param opusData   Datos de audio en formato Opus
     * @param sampleRate Frecuencia de muestreo (ej. 24000)
     * @param channels   Número de canales (ej. 1 para mono)
     * @param x          Posición X para OpenAL
     * @param y          Posición Y para OpenAL
     * @param z          Posición Z para OpenAL
     */
    /**
     * Decodifica un buffer Opus a PCM usando la API pública de opus4j y lo reproduce con OpenALPlayer.
     * @param opusData   Datos de audio en formato Opus
     * @param sampleRate Frecuencia de muestreo (ej. 24000)
     * @param channels   Número de canales (ej. 1 para mono)
     * @param x          Posición X para OpenAL
     * @param y          Posición Y para OpenAL
     * @param z          Posición Z para OpenAL
     */
    public static void playOpus(byte[] opusData, int sampleRate, int channels, float x, float y, float z) {
        OpusDecoder decoder = null;
        try {
            // Crea el decodificador Opus usando opus4j 2.x
            decoder = new OpusDecoder(sampleRate, channels);

            // Decodifica el buffer Opus a PCM (short[])
            short[] pcmShorts = decoder.decode(opusData);

            // Convierte el buffer short[] a byte[] (little endian)
            ByteBuffer pcmBuffer = ByteBuffer.allocate(pcmShorts.length * 2);
            for (short s : pcmShorts) {
                pcmBuffer.putShort(s);
            }
            byte[] pcmBytes = pcmBuffer.array();

            // Crea el formato de audio PCM correspondiente
            AudioFormat format = new AudioFormat(
                sampleRate,         // Frecuencia de muestreo
                16,                 // Bits por muestra
                channels,           // Número de canales
                true,               // PCM_SIGNED
                false               // little endian
            );

            // Reproduce el audio usando OpenALPlayer
            OpenALPlayer.play(pcmBytes, format, x, y, z);
        } catch (Exception e) {
            System.out.println("[DEPURACIÓN] Error al decodificar Opus: " + e.getMessage());
            e.printStackTrace();
        } finally {
            // Libera los recursos del decodificador
            if (decoder != null) {
                try { decoder.close(); } catch (Exception ignore) {}
            }
        }
    }
}
