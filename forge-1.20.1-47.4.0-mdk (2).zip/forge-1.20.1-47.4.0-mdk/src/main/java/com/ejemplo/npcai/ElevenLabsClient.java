package com.ejemplo.npcai;

import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import com.google.gson.JsonObject;
import com.google.gson.JsonArray;
import com.google.gson.Gson;
import com.google.gson.JsonParser;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ElevenLabsClient {

    private static final String API_KEY = "sk_83f9ac1f647a29389cf994a1cd1450eff185f4d8dc660d78"; // Actualizada por solicitud del usuario
    // VOICE_ID por defecto, pero ahora configurable por llamada
    private static final String DEFAULT_VOICE_ID = "n4x17EKVqyxfey8QMqvy";
    private static final int CONNECT_TIMEOUT = 10000; // 10 segundos
    private static final int READ_TIMEOUT = 15000; // 15 segundos

    public static void generarYReproducirAudio(String texto, ServerPlayer player) throws IOException {
        if (texto == null || texto.trim().isEmpty()) {
            throw new IllegalArgumentException("El texto no puede estar vacío o ser nulo.");
        }

        if (API_KEY == null || API_KEY.isEmpty()) {
            throw new IllegalStateException("La clave API de ElevenLabs no está configurada. Debes definir la variable de entorno ELEVENLABS_API_KEY antes de iniciar el servidor.");
        }

        byte[] audioData = generarAudio(texto);

        // --- Reproducir el audio Opus recibido usando OpusDecoderPlayer (24kHz, mono) ---
        // Ajusta sampleRate/canales si ElevenLabs responde diferente
        OpusDecoderPlayer.playOpus(audioData, 24000, 1, (float)player.getX(), (float)player.getY(), (float)player.getZ());
        enviarAudioACliente(player, audioData);
    }

    /**
     * Genera audio OGG/Opus usando ElevenLabs y lo retorna como byte[].
     * Este es el único punto de entrada recomendado para síntesis de voz.
     */
    public static byte[] generarAudio(String texto) throws IOException {
        try {
            byte[] audio = generarAudio(texto, DEFAULT_VOICE_ID, null);
            return audio;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    public static byte[] generarAudio(String texto, String voiceId, JsonObject voiceSettings) throws IOException {
        String vid = (voiceId != null && !voiceId.isEmpty()) ? voiceId : DEFAULT_VOICE_ID;
        URL url = new URL("https://api.elevenlabs.io/v1/text-to-speech/" + vid);
        HttpURLConnection con = (HttpURLConnection) url.openConnection();

        con.setConnectTimeout(CONNECT_TIMEOUT);
        con.setReadTimeout(READ_TIMEOUT);

        con.setRequestMethod("POST");

        // DEBUG: Imprimir URL y headers
        System.out.println("[DEPURACIÓN] URL de ElevenLabs: " + url.toString());
        System.out.println("[DEPURACIÓN] Header xi-api-key: " + API_KEY);
        System.out.println("[DEPURACIÓN] Header Content-Type: application/json");

        con.setRequestProperty("Content-Type", "application/json");
        con.setRequestProperty("xi-api-key", API_KEY);
        con.setDoOutput(true);

        // Construir el JSON para la solicitud usando Gson
        JsonObject body = new JsonObject();
        body.addProperty("text", texto);
        body.addProperty("model_id", "eleven_multilingual_v2");

        if (voiceSettings != null) {
            body.add("voice_settings", voiceSettings);
        } else {
            JsonObject settings = new JsonObject();
            settings.addProperty("stability", 0.5);
            settings.addProperty("similarity_boost", 0.75);
            body.add("voice_settings", settings);
        }

        // DEBUG: Imprimir body JSON antes de enviar
        Gson gson = new Gson();
        String json = gson.toJson(body);
        System.out.println("[DEPURACIÓN] Body JSON enviado: " + json);
        try (OutputStream os = con.getOutputStream()) {
            byte[] input = json.getBytes(StandardCharsets.UTF_8);
            os.write(input, 0, input.length);
        }

        int responseCode = con.getResponseCode();
        System.out.println("[DEPURACIÓN] Código de respuesta HTTP de ElevenLabs: " + responseCode);
        if (responseCode == 200) {
            byte[] audio = con.getInputStream().readAllBytes();
            System.out.println("[DEPURACIÓN] Audio recibido, tamaño: " + (audio != null ? audio.length : 0) + " bytes");
            return audio;
        } else {
            String errorMessage = con.getResponseMessage();
            System.err.println("[DEPURACIÓN] Error HTTP de ElevenLabs: " + responseCode + " - " + errorMessage);
            try {
                String errorBody = new String(con.getErrorStream().readAllBytes(), StandardCharsets.UTF_8);
                System.err.println("[DEPURACIÓN] Cuerpo del error de ElevenLabs: " + errorBody);
            } catch (Exception ex) {
                System.err.println("[DEPURACIÓN] No se pudo leer el cuerpo del error de ElevenLabs.");
            }
            if (responseCode == 401) {
                throw new IOException("Error de autenticación: clave API inválida.");
            } else if (responseCode == 429) {
                throw new IOException("Límite de cuota alcanzado en ElevenLabs.");
            } else {
                throw new IOException("Error al generar audio: " + responseCode + " - " + errorMessage);
            }
        }
    }

    private static void enviarAudioACliente(ServerPlayer player, byte[] audioData) {
        NetworkHandler.CHANNEL.sendTo(
                new NetworkHandler.AudioMessage(audioData),
                player.connection.connection,
                NetworkDirection.PLAY_TO_CLIENT
        );
    }
}