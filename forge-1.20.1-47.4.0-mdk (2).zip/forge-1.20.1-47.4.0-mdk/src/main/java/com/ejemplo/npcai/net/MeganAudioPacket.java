package com.ejemplo.npcai.net;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;
import java.util.function.Supplier;

public class MeganAudioPacket {
    public byte[] opusData;
    public int sampleRate;
    public int channels;
    public float x, y, z;
    public int chunkIndex;
    public int totalChunks;
    public int streamId;

    public MeganAudioPacket(byte[] opusData, int sampleRate, int channels, float x, float y, float z, int chunkIndex, int totalChunks, int streamId) {
        this.opusData = opusData;
        this.sampleRate = sampleRate;
        this.channels = channels;
        this.x = x;
        this.y = y;
        this.z = z;
        this.chunkIndex = chunkIndex;
        this.totalChunks = totalChunks;
        this.streamId = streamId;
    }

    public MeganAudioPacket(FriendlyByteBuf buf) {
        this.opusData = buf.readByteArray();
        this.sampleRate = buf.readInt();
        this.channels = buf.readInt();
        this.x = buf.readFloat();
        this.y = buf.readFloat();
        this.z = buf.readFloat();
        this.chunkIndex = buf.readInt();
        this.totalChunks = buf.readInt();
        this.streamId = buf.readInt();
    }

    public void toBytes(FriendlyByteBuf buf) {
        buf.writeByteArray(opusData);
        buf.writeInt(sampleRate);
        buf.writeInt(channels);
        buf.writeFloat(x);
        buf.writeFloat(y);
        buf.writeFloat(z);
        buf.writeInt(chunkIndex);
        buf.writeInt(totalChunks);
        buf.writeInt(streamId);
    }

    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            MeganAudioClientHandler.handleIncomingChunk(this);
        });
        ctx.get().setPacketHandled(true);
    }
}
